# Comprehensive Guide to Phylogenetic Tree Rerooting

## Table of Contents
1. [What is Tree Rerooting?](#what-is-tree-rerooting)
2. [The Fundamental Problem](#the-fundamental-problem)
3. [Jaccard Similarity Explained](#jaccard-similarity-explained)
4. [Step-by-Step Examples](#step-by-step-examples)
5. [Advanced Optimization Algorithms](#advanced-optimization-algorithms)
6. [Real-World Applications](#real-world-applications)

---

## What is Tree Rerooting?

### The Basic Concept

In phylogenetics, the **same evolutionary relationships** can be represented by trees with different root positions. Tree rerooting is the process of **changing where we place the root** of a phylogenetic tree to better match a reference tree or biological hypothesis.

### Visual Example

```
Original Tree:           Rerooted Tree:
    A                        C
   / \                      / \
  B   C          =>        A   D
     / \                  /
    D   E                B   E
```

**Same relationships, different root position!**

---

## The Fundamental Problem

### Problem Statement
Given two phylogenetic trees representing the same set of species, **where should we place the root of Tree 1 so that it becomes as similar as possible to Tree 2?**

### Why This Matters
- **Biological interpretation**: Root position affects how we interpret evolutionary events
- **Tree comparison**: Need consistent rooting to compare evolutionary hypotheses
- **Phylogenetic analysis**: Many analyses require properly rooted trees

---

## Jaccard Similarity Explained

### What is Jaccard Similarity?

Jaccard similarity measures how similar two sets are by comparing their **intersection** and **union**:

```
Jaccard Similarity = |A ∩ B| / |A ∪ B|
```

Where:
- `A ∩ B` = elements in both sets (intersection)
- `A ∪ B` = elements in either set (union)

### In Phylogenetic Context

Each node in a tree defines a **split** (or partition) that divides species into two groups:

```
Tree: ((A,B),(C,D))

Node splits:
- Root node: {A,B} vs {C,D}
- Left node: {A} vs {B}
- Right node: {C} vs {D}
```

---

## Step-by-Step Examples

### Example 1: Simple Jaccard Calculation

**Two sets of species:**
- Set A: {Human, Chimp, Mouse}
- Set B: {Human, Chimp, Dog}

**Calculate Jaccard Similarity:**
1. **Intersection**: {Human, Chimp} → Size = 2
2. **Union**: {Human, Chimp, Mouse, Dog} → Size = 4
3. **Jaccard**: 2/4 = 0.5

### Example 2: Tree Rerooting with Jaccard Similarity

Let's work through a concrete example with two trees:

**Tree A (to be rerooted):**
```
     Root
    /    \
   N1     E
  /  \
 A    N2
     /  \
    B    N3
        /  \
       C    D
```

**Tree B (reference):**
```
     Root
    /    \
   N1     N2
  /  \   /  \
 A    B C    N3
             /  \
            D    E
```

**Goal:** Find the best position to reroot Tree A to match Tree B.

### Step 1: Identify the Target Split

Tree B's root creates this split:
- **Group 1**: {A, B}
- **Group 2**: {C, D, E}

### Step 2: Evaluate Each Node in Tree A

Let's check each internal node in Tree A:

**Node N1 split:** {A} vs {B, C, D, E}
- Target: {A, B} vs {C, D, E}
- Intersection of {A} and {A, B}: {A} → Size = 1
- Union of {A} and {A, B}: {A, B} → Size = 2
- **Jaccard = 1/2 = 0.5**

**Node N2 split:** {A, B} vs {C, D, E}
- Target: {A, B} vs {C, D, E}
- Intersection: {A, B} → Size = 2
- Union: {A, B} → Size = 2
- **Jaccard = 2/2 = 1.0** ✨ **Perfect match!**

**Node N3 split:** {C, D} vs {A, B, E}
- Target: {A, B} vs {C, D, E}
- Intersection of {C, D} and {A, B}: {} → Size = 0
- Union: {A, B, C, D} → Size = 4
- **Jaccard = 0/4 = 0.0**

### Step 3: Select Best Match

Node N2 has the highest Jaccard similarity (1.0), so we reroot Tree A at Node N2.

### Step 4: Perform Rerooting

After rerooting Tree A at Node N2:
```
     N2 (new root)
    /            \
   A              N4
                 /  \
                B    N5
                    /  \
                   C    N6
                       /  \
                      D    E
```

Now Tree A has the same root split as Tree B: {A, B} vs {C, D, E}!

---

## Advanced Optimization Algorithms

### Global Optimization Approach

Instead of just matching the root split, the **global optimization** considers **ALL splits** in both trees:

1. **Extract all splits** from both trees
2. **Build correspondence map** between similar splits
3. **Try each possible root position** in Tree A
4. **Calculate global similarity score** for each position
5. **Select the root position** with highest global score

### Algorithm Workflow

```python
def find_optimal_root(tree_a, tree_b):
    # Step 1: Extract all splits
    splits_a = extract_all_splits(tree_a)
    splits_b = extract_all_splits(tree_b)

    # Step 2: Build similarity matrix
    similarity_matrix = calculate_pairwise_similarities(splits_a, splits_b)

    # Step 3: Try each root position
    best_score = 0.0
    best_root = None

    for candidate_node in tree_a.internal_nodes():
        # Temporarily reroot at this node
        temp_tree = reroot_at(tree_a, candidate_node)

        # Calculate global similarity
        score = global_similarity(temp_tree, tree_b, similarity_matrix)

        if score > best_score:
            best_score = score
            best_root = candidate_node

    return reroot_at(tree_a, best_root)
```

### Performance Optimizations

#### 1. Bitmask Operations
Instead of set operations, use bitwise operations for speed:

```python
# Instead of this (slow):
intersection = len(set_a & set_b)
union = len(set_a | set_b)

# Use this (fast):
intersection = bin(bitmask_a & bitmask_b).count('1')
union = bin(bitmask_a | bitmask_b).count('1')
```

#### 2. Early Termination
Stop searching when perfect match found:

```python
if jaccard_similarity >= 1.0:
    return best_node  # Perfect match found!
```

#### 3. Precomputed Data
Calculate expensive operations once:

```python
# Precompute target bitmask popcount
target_popcount = bin(target_partition.bitmask).count('1')

# Reuse for all comparisons
for node in tree.traverse():
    # Fast comparison using precomputed data
    ...
```

---

## Real-World Applications

### Example: Primate Phylogeny

**Scenario:** We have two primate phylogenies from different studies and want to compare them.

**Tree Study 1:**
```
((Human,Chimp),(Gorilla,(Orangutan,Gibbon)))
```

**Tree Study 2:**
```
(((Human,Chimp),Gorilla),(Orangutan,Gibbon))
```

**Rerooting Process:**

1. **Extract splits from Study 2 (reference)**:
   - Split 1: {Human, Chimp, Gorilla} vs {Orangutan, Gibbon}
   - Split 2: {Human, Chimp} vs {Gorilla}

2. **Find best matching nodes in Study 1**:
   - Check each internal node for Jaccard similarity
   - Find node that creates split: {Human, Chimp, Gorilla} vs {Orangutan, Gibbon}

3. **Reroot Study 1** at the best matching position

4. **Result**: Both trees now have consistent rooting for comparison

### Example: Gene Family Evolution

**Problem:** Different gene trees from the same family have different root positions, making it hard to study gene duplication events.

**Solution:** Use our rerooting algorithm to:
1. Select one tree as reference (e.g., species tree)
2. Reroot all other gene trees to match the reference
3. Now all trees have consistent interpretation of duplication timing

---

## Algorithm Comparison

| Algorithm               | Speed      | Accuracy    | Use Case                                |
| ----------------------- | ---------- | ----------- | --------------------------------------- |
| **Jaccard Similarity**  | ⚡ Fast     | ✅ Good      | Quick rerooting, real-time applications |
| **Global Optimization** | 🐌 Slower   | 🎯 Excellent | Research, detailed analysis             |
| **Simple Rerooting**    | ⚡⚡ Fastest | ⚠️ Basic     | Fallback, simple cases                  |

---

## Key Takeaways

1. **Tree rerooting** changes root position while preserving evolutionary relationships
2. **Jaccard similarity** measures how well two species groupings match
3. **Higher Jaccard score** = better match between tree structures
4. **Global optimization** considers all splits for more accurate results
5. **Performance optimizations** make algorithms practical for large trees

The rerooting algorithms in BranchArchitect provide both **fast approximations** (Jaccard) and **thorough optimization** (global) to handle different use cases in phylogenetic analysis.
