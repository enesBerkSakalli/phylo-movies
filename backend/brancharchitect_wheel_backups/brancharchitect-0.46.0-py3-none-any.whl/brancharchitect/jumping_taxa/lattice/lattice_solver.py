"""
Updated lattice algorithm functions with proper Pydantic validation.
"""

from brancharchitect.elements.partition_set import PartitionSet
from brancharchitect.tree import Node
from brancharchitect.jumping_taxa.lattice.lattice_edge import LatticeEdge
from brancharchitect.jumping_taxa.debug import jt_logger
from brancharchitect.jumping_taxa.lattice.lattice_solution import LatticeSolutions
from brancharchitect.jumping_taxa.lattice.mapping import (
    map_s_edges_to_original_by_index,
)
from typing import List, Tuple, Set

# Import lattice modules
from brancharchitect.jumping_taxa.lattice.lattice_construction import (
    construct_sub_lattices,
    build_partition_conflict_matrix,
    are_cover_lists_equivalent,
)
from brancharchitect.jumping_taxa.lattice.matrix_ops import (
    split_matrix,
    solve_matrix_puzzle,
    generalized_meet_product,
)
from brancharchitect.elements.partition import Partition


def process_single_lattice_edge(
    edge: LatticeEdge,
    solutions_manager: LatticeSolutions,
) -> bool:
    """
    Analyze a single LatticeEdge and store solutions in the solutions_manager.
    """
    if are_cover_lists_equivalent(edge.t1_common_covers, edge.t2_common_covers):
        jt_logger.info(
            f"Skipping {edge.split} at visit {edge.visits} as covers are equivalent."
        )
        return True

    candidate_matrix = build_partition_conflict_matrix(edge)
    if not candidate_matrix:
        return True

    matrices = split_matrix(candidate_matrix)
    jt_logger.section("Meet Result Computation")

    if len(matrices) > 1:
        # solutions is List[PartitionSet[Partition]] i.e. List[List[Partition]]
        solutions = solve_matrix_puzzle(matrix1=matrices[0], matrix2=matrices[1])
        case_label = "degenerate"
        if solutions:
            jt_logger.info(
                f"Adding solutions for {edge.split} at visit {edge.visits}, Case {case_label}"
            )
            jt_logger.info(f"Solutions: {solutions}")
            solutions_manager.add_solutions(
                edge.split, solutions, category=case_label, visit=edge.visits
            )
            return False
        return True

    matrix = matrices[0]
    jt_logger.matrix(matrix)
    # solutions is List[PartitionSet[Partition]] i.e. List[List[Partition]]
    solutions = generalized_meet_product(matrix=matrix)
    case_label = "non-degenerate"
    if solutions:
        jt_logger.info(
            f"Adding solutions for {edge.split} at visit {edge.visits}, Case {case_label}"
        )
        jt_logger.info(f"Solutions: {solutions}")
        # solutions_manager.add_solutions expects List[PartitionSet[Partition]]
        solutions_manager.add_solutions(
            edge.split, solutions, category=case_label, visit=edge.visits
        )
        return False
    return True


def process_iteration(
    sub_lattices: List[LatticeEdge], lattice_solutions_manager: LatticeSolutions
) -> None:
    """
    Process a set of sub-lattices to find solutions.
    """
    processing_stack = sub_lattices.copy()
    jt_logger.section("Processing Stack")
    for s_edge_obj_log in processing_stack:  # Renamed to avoid conflict
        jt_logger.info(f"Initial stack processing {s_edge_obj_log.split}")

    while processing_stack:
        s_edge_obj = processing_stack.pop()
        s_edge_obj.visits += 1
        jt_logger.info(
            f"s_edge {s_edge_obj.split} updated to visit {s_edge_obj.visits}"
        )

        done = process_single_lattice_edge(s_edge_obj, lattice_solutions_manager)

        if not done:
            # solutions_for_visit is List[PartitionSet[Partition]]
            solutions_for_visit = (
                lattice_solutions_manager.get_solutions_for_edge_visit(
                    s_edge_obj.split, s_edge_obj.visits
                )
            )

            if solutions_for_visit:
                s_edge_obj.remove_solutions_from_covers(solutions_for_visit)
                processing_stack.append(s_edge_obj)
            else:
                jt_logger.info(
                    f"No solutions for {s_edge_obj.split} at visit {s_edge_obj.visits} after processing; skipping re-add."
                )


@jt_logger.log_execution
def lattice_algorithm(
    input_tree1: Node, input_tree2: Node, leaf_order: List[str]
) -> Tuple[List[List[Partition]], List[Partition]]:
    """
    Execute the lattice algorithm to find jumping taxa between two trees.

    Args:
        input_tree1: First tree
        input_tree2: Second tree
        leaf_order: Order of leaf nodes

    Returns:
        A tuple containing:
        - List of "solution sets" (List[List[Partition]]), where each inner list (PartitionSet)
          represents a group of jumping taxa derived from one s-edge.
        - List of Partition objects representing the s-edges from which these solutions were derived.
    """
    try:
        jt_logger.log_newick_strings(input_tree1, input_tree2)
        lattice_solutions_manager = LatticeSolutions()
        current_s_edges: List[LatticeEdge] | None = construct_sub_lattices(
            input_tree1, input_tree2
        )

        jt_logger.section("Initial Sub-Lattices")
        if current_s_edges:
            process_iteration(current_s_edges, lattice_solutions_manager)

        # solution_sets_list will be List[List[Partition]]
        solution_sets_list: List[List[Partition]] = []
        s_edges_of_solutions_list: List[Partition] = []

        for (
            s_edge_partition,  # This is a Partition object
            visit,
        ), category_sols in lattice_solutions_manager.solutions_for_s_edge.items():
            case_label = next(iter(category_sols.keys())) if category_sols else None
            if case_label:
                # minimal_solutions_for_s_edge is List[PartitionSet[Partition]], i.e., List[List[Partition]]
                minimal_solutions_for_s_edge = (
                    lattice_solutions_manager.get_minimal_by_indices_sum(
                        s_edge_partition, visit
                    )
                )
                jt_logger.info(
                    f"Edge {s_edge_partition} at visit {visit} has {case_label} solutions: {minimal_solutions_for_s_edge}"
                )
                if minimal_solutions_for_s_edge:
                    # We take the first list of PartitionSets.
                    # Each PartitionSet (List[Partition]) in minimal_solutions_for_s_edge is a distinct solution group.
                    # The original code took minimal_solutions[0], implying one solution group per s-edge/visit.
                    selected_solution_set: List[Partition] = (
                        minimal_solutions_for_s_edge[0]
                    )  # This is a PartitionSet

                    solution_sets_list.append(
                        selected_solution_set
                    )  # Appending a List[Partition]
                    s_edges_of_solutions_list.append(s_edge_partition)
                    jt_logger.info(
                        f"Selected solution set for s_edge {s_edge_partition}: {selected_solution_set}"
                    )

        return solution_sets_list, s_edges_of_solutions_list

    except Exception as e:
        from brancharchitect.jumping_taxa.debug import log_stacktrace

        log_stacktrace(e)
        raise Exception(f"Error in lattice_algorithm: {str(e)}")


# Helper function to get current leaf indices
def _get_current_leaf_indices(tree_node: Node) -> Set[int]:
    leaf_indices: Set[int] = set()
    if not tree_node:
        return leaf_indices
    for leaf_node_obj in tree_node.get_leaves():  # Renamed for clarity
        indices_tuple = leaf_node_obj.split_indices.resolve_to_indices()
        if indices_tuple:
            leaf_indices.add(indices_tuple[0])
    return leaf_indices


def _initialize_iteration_variables(
    input_tree1: Node, input_tree2: Node
) -> Tuple[List[List[Partition]], List[Partition], List[Partition], Node, Node, int]:
    """
    Initialize variables for the iterate_lattice_algorithm function.

    Args:
        input_tree1: First input tree
        input_tree2: Second input tree

    Returns:
        Tuple containing:
        - accumulated_solution_sets: Empty list for storing solution sets
        - accumulated_mapped_s_edges: Empty list for storing mapped s-edges
        - all_original_partitions_list: Combined partitions from both input trees
        - current_t1: Deep copy of first tree
        - current_t2: Deep copy of second tree
        - iteration_count: Starting iteration count (0)
    """
    accumulated_solution_sets: List[List[Partition]] = []
    accumulated_mapped_s_edges: List[Partition] = []

    original_t1_partitions: PartitionSet[Partition] = input_tree1.to_splits(
        with_leaves=True
    )
    original_t2_partitions: PartitionSet[Partition] = input_tree2.to_splits(
        with_leaves=True
    )
    all_original_partitions_list: List[Partition] = list(
        original_t1_partitions.union(original_t2_partitions)
    )

    current_t1: Node = input_tree1.deep_copy()
    current_t2: Node = input_tree2.deep_copy()
    iteration_count = 0

    return (
        accumulated_solution_sets,
        accumulated_mapped_s_edges,
        all_original_partitions_list,
        current_t1,
        current_t2,
        iteration_count,
    )


def _accumulate_solutions_and_map_s_edges(
    solution_sets_this_iter: List[List[Partition]],
    s_edges_this_iter_unmapped: List[Partition],
    accumulated_solution_sets: List[List[Partition]],
    accumulated_mapped_s_edges: List[Partition],
    original_t1: Node,
    original_t2: Node,
    current_t1: Node,
    current_t2: Node,
    iteration_count: int,
) -> None:
    """
    Accumulate solutions and map s-edges to original partitions.

    Args:
        solution_sets_this_iter: Solution sets from current iteration
        s_edges_this_iter_unmapped: Unmapped s-edges from current iteration
        accumulated_solution_sets: List to accumulate solution sets (modified in-place)
        accumulated_mapped_s_edges: List to accumulate mapped s-edges (modified in-place)
        all_original_partitions_list: List of all original partitions for mapping
        current_t1: Current state of first tree
        current_t2: Current state of second tree
        iteration_count: Current iteration number
    """
    # Accumulate solution sets
    accumulated_solution_sets.extend(solution_sets_this_iter)

    # Map and accumulate s-edges if available
    if s_edges_this_iter_unmapped:
        mapped_s_edges = map_s_edges_to_original_by_index(
            s_edges_from_iteration=s_edges_this_iter_unmapped,
            original_t1=original_t1,
            original_t2=original_t2,
            current_t1=current_t1,
            current_t2=current_t2,
            iteration_count=iteration_count,
        )
        for mapped_edge in mapped_s_edges:
            if mapped_edge not in accumulated_mapped_s_edges:
                accumulated_mapped_s_edges.append(mapped_edge)


def _check_loop_termination_conditions(
    current_t1: Node,
    current_t2: Node,
    iteration_count: int,
    max_iterations: int,
    source_fn_name: str = "iterate_lattice_algorithm",
) -> bool:
    """
    Check if the main iteration loop should terminate.

    Args:
        current_t1: Current state of first tree
        current_t2: Current state of second tree
        iteration_count: Current iteration number
        max_iterations: Maximum allowed iterations
        source_fn_name: Name of calling function for logging context

    Returns:
        True if loop should terminate, False otherwise
    """
    # Check for maximum iterations exceeded
    if iteration_count > max_iterations:
        jt_logger.error(
            f"{source_fn_name}: Exceeded maximum iterations ({max_iterations}). Breaking loop."
        )
        return True

    # Log current iteration
    jt_logger.section(f"{source_fn_name}: Iteration {iteration_count}")

    # Check for unique splits between trees
    t1_unique_splits = current_t1.to_splits() - current_t2.to_splits()
    t2_unique_splits = current_t2.to_splits() - current_t1.to_splits()

    if not t1_unique_splits and not t2_unique_splits:
        jt_logger.info(
            f"Iter {iteration_count}: No unique splits. Loop will terminate."
        )
        return True

    return False


def _identify_and_delete_jumping_taxa(
    solution_sets_this_iter: List[List[Partition]],
    current_t1: Node,
    current_t2: Node,
    iteration_count: int,
    source_fn_name: str = "iterate_lattice_algorithm",
) -> Tuple[bool, Set[int]]:
    """
    Identify jumping taxa from solutions and delete them from trees.

    Args:
        solution_sets_this_iter: Solution sets from current iteration
        current_t1: Current state of first tree (modified in-place)
        current_t2: Current state of second tree (modified in-place)
        iteration_count: Current iteration number
        source_fn_name: Name of calling function for logging context

    Returns:
        Tuple containing:
        - should_break_loop: Boolean indicating if loop should break
        - taxa_indices_to_delete: Set of taxa indices that were deleted
    """
    # Collect taxa indices from all solution partitions
    taxa_indices_to_delete = set()
    for (
        solution_set
    ) in solution_sets_this_iter:  # solution_set is List[Partition] (a PartitionSet)
        for sol_partition in solution_set:  # sol_partition is a Partition
            taxa_indices_to_delete.update(sol_partition.resolve_to_indices())

    # Check if there are any taxa to delete
    if not taxa_indices_to_delete:
        jt_logger.warning(
            f"Iter {iteration_count}: Solutions found, but no taxa indices to delete. Breaking."
        )
        return True, taxa_indices_to_delete  # Break loop

    # Log and perform deletion
    jt_logger.info(
        f"Iter {iteration_count}: Deleting taxa indices: {list(taxa_indices_to_delete)}"
    )
    current_t1.delete_taxa(list(taxa_indices_to_delete))
    current_t2.delete_taxa(list(taxa_indices_to_delete))

    # Check if trees have enough leaves to continue
    if len(current_t1.get_leaves()) < 2 or len(current_t2.get_leaves()) < 2:
        jt_logger.info(
            f"Iter {iteration_count}: One or both trees have too few leaves. Stopping."
        )
        return True, taxa_indices_to_delete  # Break loop

    return False, taxa_indices_to_delete  # Continue loop


def iterate_lattice_algorithm(
    input_tree1: Node, input_tree2: Node, leaf_order: List[str] = []
) -> Tuple[List[Partition], List[Partition]]:
    """
    Iteratively apply the lattice algorithm.
    Returns:
        - Flattened list of all solution Partitions found across iterations.
        - List of original s-edge Partitions corresponding to these solutions, after mapping.
    """
    # Initialize iteration variables using helper function
    (
        accumulated_solution_sets,
        accumulated_mapped_s_edges,
        all_original_partitions_list,
        current_t1,
        current_t2,
        iteration_count,
    ) = _initialize_iteration_variables(input_tree1, input_tree2)

    max_iterations = 100

    while current_t1.to_splits() != current_t2.to_splits():
        iteration_count += 1

        # Check termination conditions using helper function
        if _check_loop_termination_conditions(
            current_t1, current_t2, iteration_count, max_iterations
        ):
            break

        # Run lattice algorithm for current iteration
        solution_sets_this_iter, s_edges_this_iter_unmapped = lattice_algorithm(
            current_t1, current_t2, leaf_order
        )

        if not solution_sets_this_iter:
            jt_logger.info(
                f"Iter {iteration_count}: No solutions found by lattice_algorithm. Stopping."
            )
            break

        # Accumulate solutions and map s-edges using helper function
        _accumulate_solutions_and_map_s_edges(
            solution_sets_this_iter,
            s_edges_this_iter_unmapped,
            accumulated_solution_sets,
            accumulated_mapped_s_edges,
            original_t1=input_tree1,
            original_t2=input_tree2,
            current_t1=current_t1,
            current_t2=current_t2,
            iteration_count=iteration_count,
        )

        # Identify and delete jumping taxa using helper function
        should_break_loop, _ = _identify_and_delete_jumping_taxa(
            solution_sets_this_iter, current_t1, current_t2, iteration_count
        )

        if should_break_loop:
            break

        current_t1, current_t2 = current_t1.deep_copy(), current_t2.deep_copy()

    # Flatten the accumulated solution sets for the final return value
    final_flattened_solutions: List[Partition] = []
    for solution_set in accumulated_solution_sets:  # solution_set is List[Partition]
        final_flattened_solutions.extend(solution_set)

    if (
        current_t1.to_splits() != current_t2.to_splits()
        and iteration_count <= max_iterations
    ):
        jt_logger.warning(
            "iterate_lattice_algorithm terminated: No further solutions, but trees still differ."
        )
    elif iteration_count > max_iterations:
        jt_logger.warning(
            "iterate_lattice_algorithm terminated: Exceeded max iterations."
        )
    else:
        jt_logger.info(
            "iterate_lattice_algorithm completed: Trees reconciled or loop condition met."
        )
    accumulated_mapped_s_edges = sorted(
        accumulated_mapped_s_edges,
        key=lambda x: len(x),
        reverse=True,
    )  # Sort by split indices for consistency

    for edge in accumulated_mapped_s_edges:
        input_tree1.assign_s_edge_block(edge)
        input_tree2.assign_s_edge_block(edge)
    return final_flattened_solutions, accumulated_mapped_s_edges


def adapter_iterate_lattice_algorithm(
    input_tree1: Node, input_tree2: Node, leaf_order: List[str]
) -> List[Tuple[int, ...]]:
    """
    Adapter for iterate_lattice_algorithm. Translates List[Partition] solutions to List[Tuple[int, ...]].
    """
    # solution_partitions is List[Partition]
    solution_partitions, s_edges = iterate_lattice_algorithm(
        input_tree1, input_tree2, leaf_order
    )

    translated_solutions: List[Tuple[int, ...]] = []
    for sol_partition in solution_partitions:  # sol_partition is a Partition
        if isinstance(sol_partition, Partition):
            indices_tuple = sol_partition.resolve_to_indices()
            translated_solutions.append(
                tuple(sorted(indices_tuple))
            )  # Sort for consistent output
        else:
            jt_logger.warning(
                f"Adapter: Unexpected item in solution list: {type(sol_partition)}"
            )
            # Handle unexpected types if necessary, e.g., if it's already a tuple of ints
            if isinstance(sol_partition, tuple) and all(
                isinstance(i, int) for i in sol_partition
            ):
                translated_solutions.append(tuple(sorted(sol_partition)))

    return translated_solutions
