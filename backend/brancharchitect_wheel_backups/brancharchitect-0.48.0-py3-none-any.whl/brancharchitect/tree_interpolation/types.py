"""
Data types and classes for tree interpolation.

This module contains the data structures used throughout the tree interpolation
process, including result containers and intermediate data representations.
"""

from __future__ import annotations

from typing import Dict, List, Optional

from brancharchitect.elements.partition import Partition
from brancharchitect.tree import Node
from brancharchitect.tree_interpolation.ordering import (
    compute_lattice_edge_depths,
)


class TreePairResult:
    """Results from processing a single tree pair."""

    def __init__(
        self,
        trees: List[Node],
        names: List[str],
        mapping_one: Dict[Partition, Partition],
        mapping_two: Dict[Partition, Partition],
        s_edge_tracking: Optional[List[Optional[Partition]]] = None,
        lattice_edge_solutions: Optional[Dict[Partition, List[List[Partition]]]] = None,
    ):
        self.trees: List[Node] = trees
        self.names: List[str] = names
        self.mapping_one: Dict[Partition, Partition] = mapping_one
        self.mapping_two: Dict[Partition, Partition] = mapping_two
        self.s_edge_tracking: List[Optional[Partition]] = s_edge_tracking or []
        self.lattice_edge_solutions: Dict[Partition, List[List[Partition]]] = (
            lattice_edge_solutions or {}
        )


class LatticeEdgeData:
    """Structured data for lattice edge processing."""

    def __init__(
        self, edges: List[Partition], solutions: Dict[Partition, List[List[Partition]]]
    ):
        self.edges: List[Partition] = edges
        self.solutions: Dict[Partition, List[List[Partition]]] = solutions
        self.target_depths: Dict[Partition, float] = {}
        self.reference_depths: Dict[Partition, float] = {}

    def compute_depths(self, target: Node, reference: Node) -> None:
        """Compute and store depth mappings for both trees."""
        # Import here to avoid circular dependency

        self.target_depths = compute_lattice_edge_depths(self.edges, target)
        self.reference_depths = compute_lattice_edge_depths(self.edges, reference)

        print("Computed target depths:", self.target_depths)
        print("Computed reference depths:", self.reference_depths)

    def get_sorted_edges(
        self, use_reference: bool = False, ascending: bool = False
    ) -> List[Partition]:
        """Get sorted edges by depth."""
        depths = self.reference_depths if use_reference else self.target_depths
        return sorted(self.edges, key=lambda p: depths[p], reverse=not ascending)


class InterpolationTrees:
    """Container for interpolation tree sequences."""

    def __init__(self, down: List[Node], up: List[Node]):
        self.down = down
        self.up = up


class ConsensusResult:
    """Container for consensus processing results."""

    def __init__(
        self,
        trees: List[Node],
        mapping_one: Dict[Partition, Partition],
        mapping_two: Dict[Partition, Partition],
    ):
        self.trees = trees
        self.mapping_one: Dict[Partition, Partition] = mapping_one
        self.mapping_two: Dict[Partition, Partition] = mapping_two
