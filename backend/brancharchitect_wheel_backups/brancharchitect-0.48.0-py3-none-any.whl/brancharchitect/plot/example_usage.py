"""
Example usage of the unified plotting functions with safe display.
"""

# Example 1: Basic usage with automatic display
from brancharchitect.plot.plot_wrapper import plot_trees_with_display, quick_plot_trees
from brancharchitect.plot.display_utils import safe_display_image, safe_display_pdf

# For paper plots with automatic file handling
def example_paper_plot(trees):
    """Example of plotting trees with paper style."""
    # This will automatically generate a PNG and display it
    plot_trees_with_display(
        trees,
        output_format="png",
        display=True,
        style_opts={
            "color_mode": "quanta",
            "leaf_font_size": 14,
        },
        layout_opts={
            "type": "phylogram",
            "h_spacing": 30,
        }
    )


# Example 2: Plotting with custom output path
def example_custom_output(trees):
    """Example with custom output path."""
    plot_trees_with_display(
        trees,
        output_path="my_tree_plot.pdf",
        output_format="pdf",
        display=True,
        display_options={
            "width": 1000,
            "height": 600,
            "method": "png"  # Display PDF as PNG
        }
    )


# Example 3: Using the circular bezier plot
from brancharchitect.plot.plot_wrapper import plot_tree_row_with_display

def example_bezier_plot(trees):
    """Example of circular bezier plot with safe display."""
    plot_tree_row_with_display(
        trees,
        size=300,  # Larger trees
        output_format="png",
        display=True,
        display_options={"width": 1200}
    )


# Example 4: Direct display of existing files
def example_display_existing():
    """Example of displaying existing plot files."""
    # For image files
    safe_display_image(
        "my_plot.png",
        width=800,
        retry_count=5,  # Try 5 times
        retry_delay=1.0  # Wait 1 second between retries
    )
    
    # For PDF files
    safe_display_pdf(
        "my_plot.pdf", 
        width=900,
        height=600,
        display_method="auto"  # Try iframe first, then PNG
    )


# Example 5: Quick plotting for exploration
def example_quick_plot(tree):
    """Quick plot with minimal code."""
    quick_plot_trees(
        tree,
        title="My Phylogenetic Tree",
        width=1000
    )


# Example 6: Batch plotting without display
def example_batch_plot(tree_list):
    """Example of batch plotting to files."""
    for i, tree in enumerate(tree_list):
        plot_trees_with_display(
            [tree],
            output_path=f"tree_{i:03d}.png",
            output_format="png",
            display=False  # Don't display, just save
        )
    print(f"Saved {len(tree_list)} tree plots")


# Example 7: Safe display in a loop
def example_safe_display_loop():
    """Example of safely displaying multiple files."""
    from brancharchitect.plot.display_utils import display_plot_output
    
    for i in range(5):
        filename = f"plot_{i}.png"
        # This will handle missing files gracefully
        display_plot_output(
            filename,
            display_options={"width": 600},
            retry_count=3
        )