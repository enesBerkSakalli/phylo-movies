"""Jumping taxa analysis operations."""

from typing import List, Tuple, Dict, Optional
import logging

from brancharchitect.tree import Node
from brancharchitect.elements.partition import Partition
from brancharchitect.elements.partition_set import PartitionSet
from brancharchitect.jumping_taxa.lattice.lattice_solver import (
    iterate_lattice_algorithm,
)


class JumpingTaxaAnalyzer:
    """Handles jumping taxa calculations and analysis."""

    def __init__(self, logger: "Optional[logging.Logger]" = None):
        self.logger = logger or logging.getLogger(__name__)

    def calculate_jumping_taxa(
        self, trees: List[Node]
    ) -> Tuple[
        List[List[List[int]]],
        List[List[Partition]],
        List[Dict[str, List[Tuple[int, ...]]]],
    ]:
        """Calculate jumping taxa between consecutive trees."""
        jumping_taxa_lists: List[List[List[int]]] = []
        s_edges_lists: List[List[Partition]] = []
        covers_lists: List[Dict[str, List[Tuple[int, ...]]]] = []

        if len(trees) < 2:
            return [[]], [], []

        try:
            for i in range(len(trees) - 1):
                raw_jumping_taxa, s_edges, covers = self.analyze_tree_pair_with_covers(
                    trees[i], trees[i + 1]
                )
                jumping_taxa_lists.append([list(t) for t in raw_jumping_taxa])
                s_edges_lists.append(s_edges)
                covers_lists.append(covers)
            return (
                jumping_taxa_lists,
                s_edges_lists,
                covers_lists,
            )
        except Exception as e:
            self.logger.error(f"Jumping taxa calculation failed: {e}")
            return [[]], [], []

    def analyze_tree_pair_with_covers(
        self,
        input_tree1: Node,
        input_tree2: Node,
        leaf_order: Optional[List[str]] = None,
    ) -> Tuple[
        List[List[Partition]], List[Partition], Dict[str, List[Tuple[int, ...]]]
    ]:
        """
        Adapter for iterate_lattice_algorithm. Translates List[Partition] solutions to List[Tuple[int, ...]].
        """
        if leaf_order is None:
            leaf_order = []

        # Get s-edge solutions dictionary from lattice algorithm
        s_edge_solutions = iterate_lattice_algorithm(
            input_tree1, input_tree2, leaf_order
        )
        s_edges = list(s_edge_solutions.keys())
        # Flatten all solutions from all s_edges
        solutions = [sol for solution_sets in s_edge_solutions.values() for sol in solution_sets]

        splits_1: PartitionSet[Partition] = input_tree1.to_splits()
        splits_2: PartitionSet[Partition] = input_tree2.to_splits()

        # unique_covers_t1 and t2 are PartitionSet[Partition]
        unique_covers_t1: PartitionSet[Partition] = splits_1 - splits_2
        unique_covers_t2: PartitionSet[Partition] = splits_2 - splits_1

        unique_covers_atoms_t1: PartitionSet[Partition] = unique_covers_t1.atom()
        unique_covers_atoms_t2: PartitionSet[Partition] = unique_covers_t2.atom()

        unique_translated_atoms_t1: List[Tuple[int, ...]] = []
        unique_translated_atoms_t2: List[Tuple[int, ...]] = []

        for cover in unique_covers_atoms_t1:
            indices_tuple = cover.resolve_to_indices()
            unique_translated_atoms_t1.append(indices_tuple)

        for cover in unique_covers_atoms_t2:
            indices_tuple = cover.resolve_to_indices()
            unique_translated_atoms_t2.append(indices_tuple)

        return (
            solutions,
            s_edges,
            {
                "t1": unique_translated_atoms_t1,
                "t2": unique_translated_atoms_t2,
            },
        )
