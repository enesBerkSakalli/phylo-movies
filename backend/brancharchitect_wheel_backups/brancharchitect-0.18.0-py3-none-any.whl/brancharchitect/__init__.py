# mypy: ignore-errors
"""Core BranchArchitect package."""
