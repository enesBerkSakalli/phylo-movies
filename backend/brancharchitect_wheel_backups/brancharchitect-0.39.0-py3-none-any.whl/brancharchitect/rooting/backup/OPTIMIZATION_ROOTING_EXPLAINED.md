# Understanding the Optimization Rooting Algorithm

## High-Level Overview

The **optimization rooting** module implements sophisticated algorithms to find the **best root position** for a phylogenetic tree by comparing it to a reference tree. It's essentially asking: "Where should I place the root of Tree A so that it becomes as similar as possible to Tree B?"

## The Core Problem

In phylogenetics, the same evolutionary relationships can be represented by trees with different root positions. The challenge is finding the optimal root position that maximizes similarity between two trees.

## What the Algorithm Actually Does

### 1. **JACCARD SIMILARITY APPROACH** 🎯

**Goal**: Find the node in Tree A whose partition (split) is most similar to Tree B's root partition.

**How it works**:
```
Tree A: (((A,B),(C,D)),E)     Tree B: ((A,B),((C,D),E))
         ^                             ^
     Find this node               Reference root partition
```

**Steps**:
1. **Extract target partition** from Tree B's root
2. **Search all nodes** in Tree A
3. **Calculate Jaccard similarity** between each node's partition and the target
4. **Select the best match** and reroot Tree A there

**Jaccard Similarity**: `|intersection| / |union|`
- If Tree B root splits taxa as `{A,B} vs {C,D,E}`
- And Tree A node splits taxa as `{A,B,C} vs {D,E}`
- Intersection: `{A,B}`, Union: `{A,B,C,D,E}`
- Similarity: `2/5 = 0.4`

### 2. **GLOBAL OPTIMIZATION APPROACH** 🌍

**Goal**: Consider ALL splits in both trees to find the globally optimal root position.

**The Multi-Step Process**:

#### Step 1: Build Split Correspondence Map
```python
Tree A splits: {A,B}, {C,D}, {A,B,C}
Tree B splits: {A,B}, {D,E}, {A,B,D}
                ↓
Correspondence: {A,B}→{A,B}, {C,D}→{D,E}, etc.
```

#### Step 2: Evaluate Each Potential Root
For each possible root position in Tree A:
1. **Temporarily reroot** the tree there
2. **Extract all splits** from the rerooted tree
3. **Calculate global similarity** to Tree B's splits
4. **Score this root position**

#### Step 3: Select Best Root
- Choose the root position with the **highest global similarity score**
- Prefer **internal nodes** over leaf nodes
- Have **fallback strategies** if optimization fails

## Key Algorithms Explained

### A. `find_best_matching_node_jaccard()`
```
INPUT:  Target partition from Tree B
OUTPUT: Node in Tree A with highest Jaccard similarity

FOR each node in Tree A:
    similarity = jaccard(node.partition, target_partition)
    IF similarity > best_similarity:
        best_node = node
RETURN best_node
```

### B. `find_optimal_root_candidates()`
```
INPUT:  Tree A, Reference splits from Tree B, Similarity matrix
OUTPUT: List of (node, score) ranked by quality

FOR each potential root node in Tree A:
    temp_tree = reroot_at(node)
    temp_splits = extract_splits(temp_tree)
    score = global_similarity(temp_splits, reference_splits)
    candidates.add((node, score))

RETURN sorted(candidates, by=score, descending=True)
```

### C. `reroot_to_compared_tree()` - The Main Function
```
INPUT:  Tree A (to reroot), Tree B (reference)
OUTPUT: Tree A rerooted optimally

1. Find optimal root candidates using global similarity
2. Select best non-leaf candidate
3. Reroot Tree A at that position
4. Validate the result
5. Fallback to simple rerooting if anything fails
```

## Why This Is Complex

### 1. **Computational Complexity**
- Must evaluate **every possible root position**
- Each evaluation requires **rerooting and split extraction**
- **O(n²)** or **O(n³)** complexity depending on tree size

### 2. **Multiple Similarity Metrics**
- **Jaccard similarity**: Fast, local optimization
- **Global similarity**: Considers all splits, more accurate but slower
- **Weighted similarity**: Gives more importance to balanced splits

### 3. **Robust Fallback Strategies**
- If global optimization fails → use Jaccard similarity
- If Jaccard fails → use simple rerooting
- If no good candidates → use first available internal node

## Real-World Example

```
Tree A: (((Human,Chimp),(Mouse,Rat)),Fish)
Tree B: ((Human,Chimp),((Mouse,Rat),Fish))

Algorithm asks: "Where should I root Tree A to match Tree B?"

1. Try rooting at Human-Chimp ancestor
2. Try rooting at Mouse-Rat ancestor
3. Try rooting at various internal nodes
4. Calculate similarity for each option
5. Choose the best one

Result: Root Tree A at the ancestor of (Human,Chimp,Mouse,Rat)
```

## Performance Optimizations

### 1. **Bitmask Operations**
```python
# Fast bitwise operations instead of set operations
intersection = bin(bitmask1 & bitmask2).count('1')
union = bin(bitmask1 | bitmask2).count('1')
```

### 2. **Precomputed Data**
- Similarity matrices calculated once
- Split extractions cached
- Early termination for perfect matches

### 3. **Smart Candidate Selection**
- Prefer internal nodes (better biological meaning)
- Skip obviously poor candidates
- Limit search space with thresholds

## Summary

This algorithm is solving a **complex optimization problem**: finding the root position that maximizes similarity between two phylogenetic trees. It uses sophisticated techniques including:

- **Local optimization** (Jaccard similarity)
- **Global optimization** (considering all splits)
- **Robust error handling** (multiple fallback strategies)
- **Performance optimizations** (bitmasks, caching)

The complexity comes from the fact that rerooting changes the entire structure of the tree, so you need to evaluate many possibilities to find the truly optimal solution.
