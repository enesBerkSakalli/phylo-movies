from brancharchitect.tree import Node
from typing import Optional, Set
from brancharchitect.partition_set import Partition
from typing import Dict, List

__all__ = [
    "interpolate_tree",
    "interpolate_adjacent_tree_pairs",
    "assign_tree_metadata",
]


def get_common_splits(tree1, tree2):
    """Return the set of Partition objects (splits) common to both trees, using to_splits()."""
    splits1 = set(tree1.to_splits())
    splits2 = set(tree2.to_splits())
    return splits1 & splits2


def assign_tree_metadata(
    node: Node,
    common_splits: Optional[Set[Partition]] = None,
    tree1_splits: Optional[Set[Partition]] = None,
    tree2_splits: Optional[Set[Partition]] = None,
) -> None:
    """
    Annotate the tree in-place with metadata for each node for correspondence-aware D3 animation and serialization.

    Args:
        node (Node): Root node of the tree to annotate.
        common_splits (Optional[Set[Partition]]): Set of Partition objects representing splits common to both trees.
        tree1_splits (Optional[Set[Partition]]): Set of splits from tree 1.
        tree2_splits (Optional[Set[Partition]]): Set of splits from tree 2.
    """
    splits: Set[Partition] = _collect_splits(node)
    split_to_corrid = _assign_correspondence_ids(splits)
    _annotate_tree(
        node,
        split_to_corrid,
        common_splits=common_splits,
        tree1_splits=tree1_splits,
        tree2_splits=tree2_splits,
    )


def _collect_splits(node: "Node") -> Set["Partition"]:
    """Collect all splits in the tree as Partition objects using to_splits (with_leaves=True)."""
    return node.to_splits(with_leaves=True)


def _assign_correspondence_ids(splits: Set["Partition"]) -> dict:
    """Assign deterministic integer correspondenceIds to each split."""
    sorted_splits = sorted(splits, key=lambda p: p.indices)
    return {split: i for i, split in enumerate(sorted_splits)}


def _annotate_tree(
    node: "Node",
    split_to_corrid: Dict[Partition, int],
    common_splits: Optional[Set[Partition]] = None,
    tree1_splits: Optional[Set[Partition]] = None,
    tree2_splits: Optional[Set[Partition]] = None,
    parent_id: Optional[int] = None,
    depth: int = 0,
    ancestor_ids: Optional[List[int]] = None,
    ancestor_splits: Optional[List[Partition]] = None,
    ancestor_depths: Optional[List[int]] = None,
) -> None:
    """
    Recursively annotate the tree in-place with correspondence-aware metadata.
    """
    # Ensure split_indices is a Partition
    if not isinstance(node.split_indices, Partition):
        raise TypeError(f"Expected Partition, got {type(node.split_indices)}")

    split: Partition = node.split_indices

    # Safe lookup with error handling
    if split not in split_to_corrid:
        raise ValueError(f"Split {split} not found in correspondence mapping")

    node.correspondenceId = split_to_corrid[split]
    node.parentId = parent_id
    node.depth = depth

    # Set common cluster status
    if common_splits is not None:
        node.isCommonCluster = split in common_splits
    else:
        node.isCommonCluster = None

    # Set tree-specific uniqueness flags
    if (
        tree1_splits is not None
        and tree2_splits is not None
        and common_splits is not None
    ):
        is_in_tree1 = split in tree1_splits
        is_in_tree2 = split in tree2_splits
        is_common = split in common_splits

        node.isUniqueToT1 = is_in_tree1 and not is_common
        node.isUniqueToT2 = is_in_tree2 and not is_common
    else:
        node.isUniqueToT1 = None
        node.isUniqueToT2 = None

    # Build ancestor chains
    ancestor_ids = (ancestor_ids or []) + [node.correspondenceId]
    ancestor_splits = (ancestor_splits or []) + [split]
    ancestor_depths = (ancestor_depths or []) + [depth]
    node.ancestorClusterIds = ancestor_ids

    # Find nearest ancestor (including self) whose split is in common_splits
    nearest_id: Optional[int] = None
    nearest_depth: Optional[int] = None

    if common_splits is not None:
        # Search from current node up to root
        for anc_split, anc_id, anc_depth in zip(
            reversed(ancestor_splits), reversed(ancestor_ids), reversed(ancestor_depths)
        ):
            if anc_split in common_splits:
                nearest_id = anc_id
                nearest_depth = anc_depth
                break

    # Fallback to self if no common ancestor found
    if nearest_id is None:
        nearest_id = node.correspondenceId
        nearest_depth = node.depth

    node.nearestCommonClusterId = nearest_id
    node.nearestCommonClusterDepth = nearest_depth

    # Recursively process children
    for child in node.children:
        _annotate_tree(
            child,
            split_to_corrid,
            common_splits=common_splits,
            tree1_splits=tree1_splits,
            tree2_splits=tree2_splits,
            parent_id=node.correspondenceId,
            depth=depth + 1,
            ancestor_ids=ancestor_ids,
            ancestor_splits=ancestor_splits,
            ancestor_depths=ancestor_depths,
        )


def interpolate_tree(tree_one: Node, tree_two: Node):
    split_dict1 = tree_one.to_weighted_splits()
    split_dict2 = tree_two.to_weighted_splits()

    it1 = calculate_intermediate_tree(tree_one, split_dict2)
    it2 = calculate_intermediate_tree(tree_two, split_dict1)

    c1 = calculate_consensus_tree(it1, split_dict2)
    c2 = calculate_consensus_tree(it2, split_dict1)

    # Compute splits for annotation
    common_splits = get_common_splits(tree_one, tree_two)
    tree1_splits = set(tree_one.to_splits())
    tree2_splits = set(tree_two.to_splits())

    # Annotate all trees with comprehensive metadata
    assign_tree_metadata(it1, common_splits=common_splits, tree1_splits=tree1_splits, tree2_splits=tree2_splits)
    assign_tree_metadata(c1, common_splits=common_splits, tree1_splits=tree1_splits, tree2_splits=tree2_splits)
    assign_tree_metadata(c2, common_splits=common_splits, tree1_splits=tree1_splits, tree2_splits=tree2_splits)
    assign_tree_metadata(it2, common_splits=common_splits, tree1_splits=tree1_splits, tree2_splits=tree2_splits)

    return (it1, c1, c2, it2)


def interpolate_adjacent_tree_pairs(tree_list: list[Node]) -> list[Node]:
    results = []
    for i in range(len(tree_list) - 1):
        tree_one = tree_list[i]
        tree_two = tree_list[i + 1]

        # Interpolate trees and get intermediate and consensus trees
        trees = interpolate_tree(tree_one, tree_two)

        results.append(tree_one)
        results.extend(trees)

    results.append(tree_list[-1])
    return results


### Private API ###
def calculate_intermediate_tree(tree, split_dict):
    it = tree.deep_copy()
    _calculate_intermediate_tree(it, split_dict)
    return it


def _calculate_intermediate_tree(node: Node, split_dict):
    if node.split_indices not in split_dict:
        node.length = 0
    else:
        node.length = (split_dict[node.split_indices] + node.length) / 2
    for child in node.children:
        _calculate_intermediate_tree(child, split_dict)


def calculate_consensus_tree(tree: Node, split_dict):
    consensus_tree = tree.deep_copy()
    return _calculate_consensus_tree(consensus_tree, split_dict)


def _calculate_consensus_tree(node: Node, split_dict):
    # If the node is a leaf, return it unchanged.
    if not node.children:
        return node

    new_children = []
    for child in node.children:
        # Recursively process the child
        processed_child = _calculate_consensus_tree(child, split_dict)
        # If the processed child is internal (has children)
        if processed_child.children:
            # If its split is in the consensus splits, keep the whole node.
            if processed_child.split_indices in split_dict:
                new_children.append(processed_child)
            else:
                # Otherwise, collapse it by promoting its children.
                for grandchild in processed_child.children:
                    new_children.append(grandchild)
        else:
            # Leaf nodes are always kept.
            new_children.append(processed_child)
    node.children = new_children
    return node
