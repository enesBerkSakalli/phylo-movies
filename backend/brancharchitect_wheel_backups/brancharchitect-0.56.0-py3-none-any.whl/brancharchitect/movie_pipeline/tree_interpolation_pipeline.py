"""Tree processing pipeline."""

from typing import List, Optional, Dict
import logging
import time
import numpy as np
from brancharchitect.elements.partition import Partition
from brancharchitect.movie_pipeline.types import (
    TreeList,
    TreePairSolution,
    ProcessingResult,
    PipelineConfig,
    InterpolationData,
    DistanceMetrics,
)
from brancharchitect.rooting.rooting import midpoint_root
from brancharchitect.leaforder.tree_order_optimiser import TreeOrderOptimizer
from brancharchitect.distances.distances import (
    calculate_along_trajectory,
    calculate_matrix_distance,
    relative_robinson_foulds_distance,
    weighted_robinson_foulds_distance,
)
from brancharchitect.tree_interpolation.interpolation import (
    interpolate_adjacent_blocked_tree_pairs,
)


class TreeInterpolationPipeline:
    """Pipeline for processing and interpolating trees."""

    def __init__(
        self,
        config: Optional[PipelineConfig] = None,
        logger: Optional[logging.Logger] = None,
    ):
        self.config = config or PipelineConfig()
        self.logger = logger or logging.getLogger(self.config.logger_name)

    def process_trees(self, trees: TreeList) -> ProcessingResult:
        """Run the full pipeline on a list of trees."""
        start_time = time.time()

        # Validate input
        self._validate_input(trees)

        # Root trees if enabled
        processed_trees = (
            self._root_trees(trees) if self.config.enable_rooting else trees
        )

        # Handle edge cases
        if not processed_trees:
            return self._create_empty_result()
        if len(processed_trees) == 1:
            return self._create_single_tree_result(processed_trees)

        # Main processing pipeline
        processed_trees = self._optimize_tree_order(processed_trees)
        interpolation_data = self._process_tree_pairs(processed_trees)

        self.logger.info("Calculating distance metrics...")
        distances = self._calculate_distances(processed_trees)

        # Build final result
        processing_time = time.time() - start_time

        self.logger.info(
            f"Processed {len(processed_trees)} trees in {processing_time:.2f} seconds"
        )

        return self._build_result(
            interpolation_data, distances, processed_trees, processing_time
        )

    # --- Private helpers ---

    def _process_tree_pairs(self, trees: TreeList) -> InterpolationData:
        """Interpolate all consecutive tree pairs."""
        (
            interpolated_trees,
            tree_names,
            mapping_one,
            mapping_two,
            s_edge_tracking,
            s_edge_lengths,
            lattice_solutions_list,
        ) = interpolate_adjacent_blocked_tree_pairs(trees)

        # Create tree pair solutions with mappings and lattice results
        tree_pair_solutions: List[TreePairSolution] = (
            self._create_solutions_with_mappings(
                trees,
                s_edge_tracking,
                mapping_one,
                mapping_two,
                lattice_solutions_list,
                s_edge_lengths,
            )
        )

        return InterpolationData(
            interpolated_trees=interpolated_trees,
            tree_names=tree_names,
            tree_pair_solutions=tree_pair_solutions,
        )

    def _root_trees(self, trees: TreeList) -> TreeList:
        """Midpoint root all trees."""
        return [midpoint_root(tree) for tree in trees]

    def _optimize_tree_order(self, trees: TreeList) -> TreeList:
        """Optimize tree order for visualization."""
        if len(trees) <= 1:
            return trees

        optimizer = TreeOrderOptimizer(trees)
        optimizer.optimize(
            n_iterations=self.config.optimization_iterations,
            bidirectional=self.config.bidirectional_optimization,
        )
        return trees

    def _calculate_distances(self, trees: TreeList) -> DistanceMetrics:
        """Compute distance metrics between trees."""
        if len(trees) < 2:
            return DistanceMetrics(
                rfd_list=[0.0], wrfd_list=[0.0], distance_matrix=np.zeros((1, 1))
            )

        # Calculate distances along trajectory
        rfd_list: List[float] = calculate_along_trajectory(
            trees, relative_robinson_foulds_distance
        )
        wrfd_list: List[float] = calculate_along_trajectory(
            trees, weighted_robinson_foulds_distance
        )

        distance_matrix = (
            calculate_matrix_distance(trees, relative_robinson_foulds_distance)
            if self.config.enable_distance_matrix
            else np.zeros((len(trees), len(trees)))
        )

        # Ensure distance_matrix is always a NumPy ndarray
        if not isinstance(distance_matrix, np.ndarray):
            distance_matrix = np.array(distance_matrix, dtype=float)

        return DistanceMetrics(
            rfd_list=rfd_list, wrfd_list=wrfd_list, distance_matrix=distance_matrix
        )

    def _create_solutions_with_mappings(
        self,
        trees: TreeList,
        s_edge_tracking: List[Optional[Partition]],
        mapping_one: List[Dict[Partition, Partition]],
        mapping_two: List[Dict[Partition, Partition]],
        lattice_solutions_list: List[Dict[Partition, List[List[Partition]]]],
        s_edge_lengths: List[int],
    ) -> List["TreePairSolution"]:
        """Build tree pair solutions with mappings and lattice results."""
        tree_pair_solutions: List[TreePairSolution] = []
        s_edge_idx = 0
        for i in range(len(trees) - 1):
            # Get mappings for this tree pair
            pair_mapping_one = mapping_one[i] if i < len(mapping_one) else {}
            pair_mapping_two = mapping_two[i] if i < len(mapping_two) else {}

            # Get lattice edge solutions for this pair (CRITICAL - was missing!)
            pair_lattice_solutions = (
                lattice_solutions_list[i] if i < len(lattice_solutions_list) else {}
            )

            # Use s_edge_lengths for correct slicing
            num_steps = s_edge_lengths[i] if i < len(s_edge_lengths) else 0
            pair_s_edge_sequence = s_edge_tracking[s_edge_idx : s_edge_idx + num_steps]
            s_edge_idx += num_steps

            solution = TreePairSolution(
                lattice_edge_solutions=pair_lattice_solutions,
                tree_indices=(i, i + 1),
                mapping_one=pair_mapping_one,
                mapping_two=pair_mapping_two,
                s_edge_sequence=pair_s_edge_sequence,
            )

            tree_pair_solutions.append(solution)

        return tree_pair_solutions

    # --- Result builders and validation ---

    def _build_result(
        self,
        interpolation_data: InterpolationData,
        distances: DistanceMetrics,
        processed_trees: TreeList,
        processing_time: float,
    ) -> ProcessingResult:
        """Build the final result object."""
        return ProcessingResult(
            interpolated_trees=interpolation_data.interpolated_trees,
            tree_names=interpolation_data.tree_names,
            tree_pair_solutions=interpolation_data.tree_pair_solutions,
            rfd_list=distances.rfd_list,
            wrfd_list=distances.wrfd_list,
            distance_matrix=distances.distance_matrix,
            original_tree_count=len(processed_trees),
            interpolated_tree_count=len(interpolation_data.interpolated_trees),
            processing_time=processing_time,
        )

    def _validate_input(self, trees: TreeList) -> None:
        """Raise if input trees are invalid."""
        if not trees:
            raise ValueError("Trees list cannot be empty.")
        if not all(hasattr(tree, "to_splits") for tree in trees):
            raise ValueError("All elements must be valid Node objects.")
        if len(trees) > 1:
            first_taxa = set(trees[0].get_current_order())
            for i, tree in enumerate(trees[1:], 1):
                tree_taxa = set(tree.get_current_order())
                if tree_taxa != first_taxa:
                    raise ValueError(
                        f"Tree at index {i} has different taxa than the first tree. "
                        f"Expected {len(first_taxa)} taxa, got {len(tree_taxa)}."
                    )

    def _create_empty_result(self) -> ProcessingResult:
        """Result for empty tree list."""
        return ProcessingResult(
            interpolated_trees=[],
            tree_names=[],
            tree_pair_solutions=[],
            rfd_list=[0.0],
            wrfd_list=[0.0],
            distance_matrix=np.zeros((1, 1)),
            original_tree_count=0,
            interpolated_tree_count=0,
            processing_time=0.0,
        )

    def _create_single_tree_result(self, trees: TreeList) -> ProcessingResult:
        """Result for single tree."""
        return ProcessingResult(
            interpolated_trees=trees,
            tree_names=["T0"],
            tree_pair_solutions=[],
            rfd_list=[0.0],
            wrfd_list=[0.0],
            distance_matrix=np.zeros((1, 1)),
            original_tree_count=1,
            interpolated_tree_count=1,
            processing_time=0.0,
        )
