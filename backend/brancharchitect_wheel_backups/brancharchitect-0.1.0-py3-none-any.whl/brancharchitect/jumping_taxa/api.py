from brancharchitect.tree import Node
import logging


def call_jumping_taxa(tree1: Node, tree2: Node, algorithm="rule"):
    """
    Example: calls an algorithm from brancharchitect.jumping_taxa and
    logs debug-level info to see how solutions come about.
    """

    # 1) Configure logging globally or just for this call.
    #    This ensures that debug messages from 'algorithm_five' show up.
    logging.basicConfig(
        level=logging.DEBUG,  # Set to DEBUG to see all logs
        format="%(levelname)s:%(name)s:%(message)s",
    )

    # 2) Import the modules that contain your algorithms.
    #    (You only need to do this once at the top of the file, but here’s an example inline)
    import brancharchitect.jumping_taxa.algorithm_five
    import brancharchitect.jumping_taxa.algo_new
    import brancharchitect.jumping_taxa.bruteforce_algorithm

    # 3) Prepare a lookup of available algorithms
    ALGORITHMS = {
        "rule": brancharchitect.jumping_taxa.algorithm_five.algorithm_five,
        "set": brancharchitect.jumping_taxa.algo_new.algorithm,
        "bruteforce": brancharchitect.jumping_taxa.bruteforce_algorithm.algorithm,
    }

    # 4) Sanity checks
    if tree1._order != tree2._order:
        raise ValueError("Trees have incompatible leaf order")
    if algorithm not in ALGORITHMS:
        raise ValueError(
            f"algorithm {algorithm} not supported, only supported values are {list(ALGORITHMS.keys())}"
        )

    # 5) Interpolate the two trees
    # it1, c1, c2, it2 = interpolate_tree(tree1, tree2)

    # 6) Choose the desired algorithm
    f = ALGORITHMS[algorithm]

    # 7) Call the algorithm (Algorithm 5 or otherwise).
    #    Because we set logging to DEBUG above, all .debug() calls inside
    #    'algorithm_five' will now be printed here.
    jumping_taxa = f(tree1, tree2, tree1._order)

    # 8) Print or process the result
    print("Raw jumping_taxa (indices):", jumping_taxa)

    # 9) Decode the indices to actual leaf labels (if needed)
    jumping_taxa = [tuple(tree1._order[i] for i in idx) for idx in jumping_taxa]
    print("Decoded jumping_taxa (leaf labels):", jumping_taxa)

    return jumping_taxa
