from typing import Set, NewType, Tuple, List, FrozenSet
from dataclasses import dataclass
from tabulate import tabulate

# Change from Set[int] to Tuple[int, ...] for immutability
SplitIndices = NewType("SplitIndices", Tuple[int, ...])

# Simple ANSI color codes (works in most modern terminals).
RED = "\033[31m"
GREEN = "\033[32m"
BLUE = "\033[34m"
RESET = "\033[0m"


@dataclass(frozen=True)
class IndexedSplit:
    indices: SplitIndices
    order: Tuple[str]

    def __post_init__(self):
        if not isinstance(self.indices, tuple):
            object.__setattr__(self, "indices", tuple(self.indices))
        if not all(
            isinstance(i, int) and 0 <= i < len(self.order) for i in self.indices
        ):
            raise ValueError("Invalid indices for the given order")

    @property
    def taxa(self) -> FrozenSet[str]:
        return frozenset(self.order[i] for i in self.indices)

    def complementary_indices(self) -> SplitIndices:
        full_set = set(range(len(self.order)))
        complement = full_set - set(self.indices)
        return SplitIndices(tuple(sorted(complement)))

    def __eq__(self, other) -> bool:
        if not isinstance(other, IndexedSplit):
            return NotImplemented
        return self.indices == other.indices and self.order == other.order

    def __hash__(self) -> int:
        return hash((self.indices, tuple(self.order)))

    def __str__(self) -> str:
        taxa_str = ", ".join(self.order[i] for i in self.indices)
        return f"Split({taxa_str})"

    def __repr__(self) -> str:
        return f"IndexedSplit(indices={self.indices}, order={self.order})"


class IndexedSplitSet:
    def __init__(
        self,
        splits: Set[IndexedSplit] = None,
        order: List[str] = None,
        name: str = "IndexedSplitSet",
    ):
        self.splits = splits
        self.order = order
        self.name = name

    @classmethod
    def from_node(cls, node) -> "IndexedSplitSet":
        # Extract all proper splits from the node
        node_splits = node.to_splits()
        # Convert each SplitIndices into an IndexedSplit
        indexed_splits = {IndexedSplit(s, tuple(node._order)) for s in node_splits}
        return cls(indexed_splits, tuple(node._order))

    def _validate_splits(self) -> None:
        for split in self.splits:
            if split.order != self.order:
                raise ValueError(f"Split {split} has different order than SplitSet")

    def unique_splits(self, other: "IndexedSplitSet") -> "IndexedSplitSet":
        if self.order != other.order:
            raise ValueError("Cannot compare splits with different orders")

        unique = self.splits - other.splits
        return IndexedSplitSet(unique, self.order, name="UniqueSplits")

    def common_splits(self, other: "IndexedSplitSet") -> "IndexedSplitSet":
        if self.order != other.order:
            raise ValueError("Cannot compare splits with different orders")
        common = self.splits & other.splits
        return IndexedSplitSet(common, self.order, name="CommonSplits")

    def minimal_splits(self) -> "IndexedSplitSet":
        minimal = set()
        for split in self.splits:
            is_minimal = True
            for other in self.splits:
                if other != split and other.taxa < split.taxa:
                    is_minimal = False
                    break
            if is_minimal:
                minimal.add(split)
        return IndexedSplitSet(minimal, self.order, name="MinimalSplits")

    def maximal_splits(self) -> "IndexedSplitSet":
        maximal = set()
        for split in self.splits:
            is_maximal = True
            for other in self.splits:
                if other != split and other.taxa > split.taxa:
                    is_maximal = False
                    break
            if is_maximal:
                maximal.add(split)
        return IndexedSplitSet(maximal, self.order, name="MaximalSplits")

    def vertical_print(self, as_taxa: bool = True):
        splits_list = list(self.splits)
        splits_list.sort(key=lambda s: sorted(s.taxa))

        if as_taxa:
            taxa_order = sorted({t for s in splits_list for t in s.taxa})
            matrix = []
            for taxon in taxa_order:
                row = [taxon if taxon in s.taxa else "" for s in splits_list]
                matrix.append(row)
            header = [f"Split {i+1}" for i in range(len(splits_list))]
        else:
            all_indices = sorted({i for s in splits_list for i in s.indices})
            matrix = []
            for idx in all_indices:
                row = [str(idx) if idx in s.indices else "" for s in splits_list]
                matrix.append(row)
            header = [f"Split {i+1}" for i in range(len(splits_list))]

        print(" | ".join(header))
        print("-" * (len(header) * 10))
        for row in matrix:
            print(" | ".join(element.ljust(8) for element in row))

    def vertical_print_with_tabulate(self, as_taxa: bool = True):
        from tabulate import tabulate

        splits_list = list(self.splits)
        splits_list.sort(key=lambda s: sorted(s.taxa))

        if as_taxa:
            taxa_order = sorted({t for s in splits_list for t in s.taxa})
            matrix = []
            header = [f"Split {i+1}" for i in range(len(splits_list))]
            for taxon in taxa_order:
                row = [taxon if taxon in s.taxa else "" for s in splits_list]
                matrix.append(row)
            print(tabulate(matrix, headers=header, tablefmt="fancy_grid"))
        else:
            all_indices = sorted({i for s in splits_list for i in s.indices})
            matrix = []
            header = [f"Split {i+1}" for i in range(len(splits_list))]
            for idx in all_indices:
                row = [str(idx) if idx in s.indices else "" for s in splits_list]
                matrix.append(row)
            print(tabulate(matrix, headers=header, tablefmt="fancy_grid"))

    def vertical_print_combined(self):
        splits_list = list(self.splits)
        splits_list.sort(key=lambda s: sorted(s.taxa))

        for i, split in enumerate(splits_list, start=1):
            indices_str = ",".join(map(str, split.indices))
            taxa_str = ",".join(sorted(split.taxa))
            print(f"Split {i}: Indices=[{indices_str}] | Taxa=[{taxa_str}]")

    def __str__(self) -> str:
        splits_str = "\n".join(
            str(split) for split in sorted(self.splits, key=lambda x: x.indices)
        )
        return f"{self.name}:\n{splits_str}"

    def __repr__(self) -> str:
        return f"IndexedSplitSet(splits={self.splits}, order={self.order}, name='{self.name}')"

    def compare_vertical_print_with_tabulate(
        self,
        other: "IndexedSplitSet",
        as_taxa: bool = True,
        color: bool = True,
        tablefmt: str = "fancy_grid",
    ):
        """
        Compare this IndexedSplitSet with 'other' and display all splits in
        a vertical matrix (similar to 'vertical_print_with_tabulate'), but
        color-code columns by whether each split is:
          - Common to both sets (GREEN)
          - Unique to self (RED)
          - Unique to other (BLUE)
        Args:
            other (IndexedSplitSet): Another set of splits to compare.
            as_taxa (bool): If True, rows represent taxa; otherwise, rows are indices.
            color (bool): If True, apply ANSI color codes to highlight differences.
            tablefmt (str): Table format for tabulate (e.g., "fancy_grid", "plain", etc.).
        """
        # Ensure both sets share the same .order
        if tuple(self.order) != tuple(other.order):
            raise ValueError(
                "Cannot compare IndexedSplitSets with different orders.\n"
                f"Self order={self.order}\n"
                f"Other order={other.order}"
            )
        # 1) Identify splits: common, unique to self, unique to other
        common_splits = self.common_splits(other).splits
        unique_self = self.unique_splits(other).splits
        unique_other = other.unique_splits(self).splits
        # Merge them into one list so each column can be a single split
        all_splits = list(common_splits) + list(unique_self) + list(unique_other)
        # Sort them in a stable way, for consistent column ordering
        # You could also sort by indices, e.g.: key=lambda s: s.indices
        all_splits.sort(key=lambda s: sorted(s.taxa))
        # 2) Build column headers & pick a color for each column
        headers = []
        col_colors = []
        for i, sp in enumerate(all_splits, start=1):
            if sp in common_splits:
                headers.append(f"Split {i} (common)")
                col_colors.append(GREEN)
            elif sp in unique_self:
                headers.append(f"Split {i} (unique in self)")
                col_colors.append(RED)
            else:
                headers.append(f"Split {i} (unique in other)")
                col_colors.append(BLUE)
        # 3) Determine row labels (taxa vs. indices)
        if as_taxa:
            row_labels = sorted({taxon for sp in all_splits for taxon in sp.taxa})
        else:
            row_labels = sorted({idx for sp in all_splits for idx in sp.indices})
        # 4) Build the matrix (row x column)
        matrix = []
        for row_label in row_labels:
            row = []
            for col_idx, sp in enumerate(all_splits):
                if as_taxa:
                    # Does this taxon appear in the column's split?
                    cell_str = str(row_label) if row_label in sp.taxa else ""
                else:
                    # Indices-based
                    cell_str = str(row_label) if row_label in sp.indices else ""
                # Optionally colorize if non-empty
                if color and cell_str:
                    cell_str = f"{col_colors[col_idx]}{cell_str}{RESET}"
                row.append(cell_str)
            matrix.append(row)
        # 5) Print via tabulate
        # 'showindex=row_labels' puts row_labels in first column
        print(
            tabulate(matrix, headers=headers, tablefmt=tablefmt, showindex=row_labels)
        )
