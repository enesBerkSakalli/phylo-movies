from brancharchitect.partition_set import PartitionSet

PMatrix = list[list[PartitionSet]]
