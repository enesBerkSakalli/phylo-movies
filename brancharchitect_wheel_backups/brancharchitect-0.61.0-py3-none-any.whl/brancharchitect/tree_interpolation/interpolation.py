"""
Tree interpolation module for creating smooth animations between phylogenetic trees.

This module provides the main public API for tree interpolation, creating
intermediate states that allow continuous morphing from one tree topology to another.
"""

from __future__ import annotations

import logging
from typing import List, Optional, Dict

from brancharchitect.elements.partition import Partition
from brancharchitect.tree_interpolation.core import (
    calculate_consensus_tree,
    calculate_intermediate_tree,
)
from brancharchitect.tree import Node
from brancharchitect.tree_interpolation.types import (
    TreePairInterpolation,
    LatticeEdgeData,
    TreeInterpolationSequence,
)
from brancharchitect.tree_interpolation.helpers import (
    generate_s_edge_interpolation_sequence,
)

logger: logging.Logger = logging.getLogger(__name__)

__all__: List[str] = [
    "interpolate_tree",
    "interpolate_adjacent_tree_pairs",
    "build_sequential_lattice_interpolations",
]


def _calculate_s_edge_distances(
    target: Node,
    reference: Node,
    lattice_edge_solutions: Dict[Partition, List[List[Partition]]],
) -> Dict[Partition, Dict[str, float]]:
    """
    Calculate distances from jumping taxa components to their corresponding s-edges.

    For each s-edge in the lattice solutions, computes both topological (unweighted)
    and branch length weighted distances from all jumping taxa (components) to the
    s-edge node in both target and reference trees.

    Args:
        target: Target tree for interpolation
        reference: Reference tree for interpolation
        lattice_edge_solutions: Dictionary mapping s-edges to their solution sets

    Returns:
        Dictionary mapping each s-edge to distance metrics:
        - "target_topological": Average topological distance in target tree (edge count)
        - "target_weighted": Average branch length weighted distance in target tree
        - "reference_topological": Average topological distance in reference tree (edge count)
        - "reference_weighted": Average branch length weighted distance in reference tree
        - "total_topological": Sum of target and reference topological distances
        - "total_weighted": Sum of target and reference weighted distances
        - "component_count": Number of jumping taxa for this s-edge
    """
    s_edge_distances: Dict[Partition, Dict[str, float]] = {}

    for s_edge, solution_sets in lattice_edge_solutions.items():
        target_topological_distances: List[float] = []
        target_weighted_distances: List[float] = []
        reference_topological_distances: List[float] = []
        reference_weighted_distances: List[float] = []
        total_components = 0

        # Process all solution sets for this s-edge
        for solution_set in solution_sets:
            for component in solution_set:
                total_components += 1

                # Calculate distances from component to s-edge in target tree
                target_path = target.find_path_between_splits(component, s_edge)
                if target_path:
                    # Topological distance: number of edges in path
                    target_topo_dist = (
                        len(target_path) - 1
                    )  # -1 because path includes both endpoints
                    target_topological_distances.append(target_topo_dist)

                    # Weighted distance: sum of branch lengths in path
                    target_weighted_dist = sum(
                        node.length if node.length is not None else 0.0
                        for node in target_path[
                            1:
                        ]  # Skip first node (component node itself)
                    )
                    target_weighted_distances.append(target_weighted_dist)
                else:
                    target_topological_distances.append(0.0)
                    target_weighted_distances.append(0.0)

                # Calculate distances from component to s-edge in reference tree
                reference_path = reference.find_path_between_splits(component, s_edge)
                if reference_path:
                    # Topological distance: number of edges in path
                    reference_topo_dist = len(reference_path) - 1
                    reference_topological_distances.append(reference_topo_dist)

                    # Weighted distance: sum of branch lengths in path
                    reference_weighted_dist = sum(
                        node.length if node.length is not None else 0.0
                        for node in reference_path[
                            1:
                        ]  # Skip first node (component node itself)
                    )
                    reference_weighted_distances.append(reference_weighted_dist)
                else:
                    reference_topological_distances.append(0.0)
                    reference_weighted_distances.append(0.0)

        # Calculate average distances
        if total_components > 0:
            avg_target_topo = sum(target_topological_distances) / len(
                target_topological_distances
            )
            avg_target_weighted = sum(target_weighted_distances) / len(
                target_weighted_distances
            )
            avg_reference_topo = sum(reference_topological_distances) / len(
                reference_topological_distances
            )
            avg_reference_weighted = sum(reference_weighted_distances) / len(
                reference_weighted_distances
            )
        else:
            avg_target_topo = 0.0
            avg_target_weighted = 0.0
            avg_reference_topo = 0.0
            avg_reference_weighted = 0.0

        s_edge_distances[s_edge] = {
            "target_topological": avg_target_topo,
            "target_weighted": avg_target_weighted,
            "reference_topological": avg_reference_topo,
            "reference_weighted": avg_reference_weighted,
            "total_topological": avg_target_topo + avg_reference_topo,
            "total_weighted": avg_target_weighted + avg_reference_weighted,
            "component_count": float(total_components),
        }

    return s_edge_distances


# Public API
def interpolate_tree(target: Node, reference: Node) -> tuple[Node, Node, Node, Node]:
    """
    Interpolate between two trees to create intermediate and consensus trees.

    Returns a tuple of 4 trees:
    1. Intermediate tree from target (branch lengths averaged toward reference)
    2. Consensus from target (keeping only splits that are also in reference)
    3. Consensus from reference (keeping only splits that are also in target)
    4. Intermediate tree from reference (branch lengths averaged toward target)
    """
    target_splits: Dict[Partition, float] = target.to_weighted_splits()
    reference_splits: Dict[Partition, float] = reference.to_weighted_splits()

    intermediate_from_target: Node = calculate_intermediate_tree(
        target, reference_splits
    )
    intermediate_from_reference = calculate_intermediate_tree(reference, target_splits)

    consensus_from_target: Node = calculate_consensus_tree(
        intermediate_from_target, reference_splits
    )
    consensus_from_reference: Node = calculate_consensus_tree(
        intermediate_from_reference, target_splits
    )

    return (
        intermediate_from_target,
        consensus_from_target,
        consensus_from_reference,
        intermediate_from_reference,
    )


def interpolate_adjacent_tree_pairs(tree_list: List[Node]) -> List[Node]:
    """Interpolate between all adjacent pairs in a list of trees."""
    if len(tree_list) < 2:
        raise ValueError("Need at least 2 trees for interpolation")

    logger.info(f"Interpolating {len(tree_list)} trees with adjacent pairs method")
    results: List[Node] = []
    for i in range(len(tree_list) - 1):
        target = tree_list[i]
        reference = tree_list[i + 1]

        trees = interpolate_tree(target, reference)
        results.append(target)
        results.extend(trees)

    results.append(tree_list[-1])
    return results


def build_lattice_interpolation_sequence(
    target: Node, reference: Node, tree_index: int
) -> TreePairInterpolation:
    """
    Build a detailed interpolation sequence between two trees using lattice-based s-edge processing.

    This function creates a comprehensive interpolation from target to reference tree by:
    1. Computing lattice edges using the jumping taxa algorithm
    2. Processing each s-edge through a 5-step interpolation sequence:
       - Down phase: Apply reference weights to target topology
       - Collapse: Remove zero-length branches
       - Reorder: Match reference tree's node ordering
       - Pre-snap: Show reference topology with target weights
       - Snap: Apply full reference weights (final state)
    3. Generating proper names and tracking for each interpolated tree
    4. Using classical interpolation fallback when s-edge processing fails

    Args:
        target: The starting tree for interpolation
        reference: The destination tree providing topology and weights
        tree_index: Index used for generating tree names (e.g., T0, T1, etc.)

    Returns:
        TreePairInterpolation containing:
        - trees: List of interpolated trees (starting tree + 5 trees per s-edge)
        - names: Descriptive names for each tree (IT_down, C_, IT_ref, etc.)
        - s_edge_tracking: Which s-edge was applied for each tree (None for fallbacks)
        - lattice_edge_solutions: Raw lattice algorithm results
        - mapping_one: Target tree solution-to-atom mappings
        - mapping_two: Reference tree solution-to-atom mappings

    Note:
        When s-edge processing fails, the function automatically falls back to
        classical interpolation and marks affected trees with "_classical_" in names.
    """
    # Import here to avoid circular import
    from brancharchitect.jumping_taxa.lattice.lattice_solver import (
        iterate_lattice_algorithm,
    )

    lattice_edge_solutions: Dict[Partition, List[List[Partition]]] = (
        iterate_lattice_algorithm(target, reference)
    )
    lattice_edges: List[Partition] = list(lattice_edge_solutions.keys())
    lattice_edge_data = LatticeEdgeData(lattice_edges, lattice_edge_solutions)
    lattice_edge_data.compute_depths(target, reference)

    interpolation_trees = [target.deep_copy()]

    # Create progressive sequences with averaged branch lengths
    reference_weights = reference.to_weighted_splits()
    target_s_edges: List[Partition] = lattice_edge_data.get_sorted_edges(
        use_reference=False, ascending=True
    )

    sequence_trees, failed_s_edges = generate_s_edge_interpolation_sequence(
        target, reference, reference_weights, target_s_edges
    )
    interpolation_trees.extend(sequence_trees)

    # Generate names and tracking using fallback-aware functions
    from brancharchitect.tree_interpolation.helpers import (
        generate_simple_tree_names_with_fallback,
        generate_simple_s_edge_tracking_with_fallback,
    )

    tree_names = generate_simple_tree_names_with_fallback(
        tree_index, target_s_edges, failed_s_edges
    )
    s_edge_tracking = generate_simple_s_edge_tracking_with_fallback(
        target_s_edges, failed_s_edges
    )

    # Generate solution to atom mappings
    from brancharchitect.jumping_taxa.lattice.mapping import map_solutions_to_atoms

    target_unique_splits = target.to_splits()
    reference_unique_splits = reference.to_splits()

    mapping_one, mapping_two = map_solutions_to_atoms(
        lattice_edge_solutions,
        target_unique_splits,
        reference_unique_splits,
    )

    # Calculate s-edge distances
    s_edge_distances = _calculate_s_edge_distances(
        target, reference, lattice_edge_solutions
    )

    return TreePairInterpolation(
        trees=interpolation_trees,
        names=tree_names,
        mapping_one=mapping_one,
        mapping_two=mapping_two,
        s_edge_tracking=s_edge_tracking,
        lattice_edge_solutions=lattice_edge_solutions,
        s_edge_distances=s_edge_distances,
    )


def build_sequential_lattice_interpolations(
    tree_list: List[Node],
) -> TreeInterpolationSequence:
    """
    Build sequential lattice-based interpolations between all adjacent pairs in a tree list.

    Processes each adjacent pair of trees in the input list to create comprehensive
    interpolation sequences using the lattice-based s-edge algorithm. For each pair:
    1. Computes lattice edges using jumping taxa algorithm
    2. Generates 5-step interpolation sequences per s-edge
    3. Creates solution-to-atom mappings
    4. Handles classical interpolation fallbacks when needed

    Args:
        tree_list: List of trees to interpolate between (minimum 2 trees required)

    Returns:
        TreeInterpolationSequence containing all interpolation data in a structured format:
        - interpolated_trees: All interpolated trees from all pairs
        - interpolation_sequence_labels: Descriptive labels for each tree (IT_down, C_, IT_ref, etc.)
        - mapping_one: Target tree solution-to-atom mappings for each pair
        - mapping_two: Reference tree solution-to-atom mappings for each pair
        - s_edge_tracking: Which s-edge was applied for each tree (None for fallbacks)
        - s_edge_lengths: Number of interpolation steps per pair
        - lattice_solutions_list: Raw lattice algorithm results for each pair
        - s_edge_distances_list: Distance metrics for each s-edge in each pair

    Raises:
        ValueError: If tree_list contains fewer than 2 trees
    """
    if len(tree_list) < 2:
        raise ValueError("Need at least 2 trees for interpolation")

    logger.info(
        f"Building sequential lattice interpolations for {len(tree_list)} trees"
    )
    results: List[Node] = []
    consecutive_tree_names: List[str] = []
    solution_to_atom_mapping_list_one: List[Dict[Partition, Partition]] = []
    solution_to_atom_mapping_list_two: List[Dict[Partition, Partition]] = []
    all_s_edge_tracking: List[Optional[Partition]] = []
    s_edge_lengths: List[int] = []
    lattice_solutions_list: List[Dict[Partition, List[List[Partition]]]] = []
    s_edge_distances_list: List[Dict[Partition, Dict[str, float]]] = []

    for i in range(len(tree_list) - 1):
        target: Node = tree_list[i].deep_copy()
        reference: Node = tree_list[i + 1].deep_copy()
        # Process single tree pair
        pair_result: TreePairInterpolation = build_lattice_interpolation_sequence(
            target, reference, i
        )

        # Collect results
        results.extend(pair_result.trees)
        consecutive_tree_names.extend(pair_result.names)
        solution_to_atom_mapping_list_one.append(pair_result.mapping_one)
        solution_to_atom_mapping_list_two.append(pair_result.mapping_two)
        all_s_edge_tracking.extend(pair_result.s_edge_tracking)
        s_edge_lengths.append(len(pair_result.s_edge_tracking))
        lattice_solutions_list.append(pair_result.lattice_edge_solutions)
        s_edge_distances_list.append(pair_result.s_edge_distances)

    # Add final tree
    results.append(tree_list[-1])
    consecutive_tree_names.append(f"T{len(tree_list) - 1}")
    all_s_edge_tracking.append(None)  # Final tree has no s_edge applied

    return TreeInterpolationSequence(
        interpolated_trees=results,
        interpolation_sequence_labels=consecutive_tree_names,
        mapping_one=solution_to_atom_mapping_list_one,
        mapping_two=solution_to_atom_mapping_list_two,
        s_edge_tracking=all_s_edge_tracking,
        s_edge_lengths=s_edge_lengths,
        lattice_solutions_list=lattice_solutions_list,
        s_edge_distances_list=s_edge_distances_list,
    )
