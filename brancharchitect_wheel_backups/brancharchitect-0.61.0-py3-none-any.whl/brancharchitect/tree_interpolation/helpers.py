"""
Helper and processing functions for tree interpolation.

This module contains utility functions for processing split data,
extracting data, and managing the interpolation workflow.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional
from brancharchitect.tree import Node
from brancharchitect.elements.partition import Partition
from brancharchitect.tree_interpolation.types import (
    LatticeEdgeData,
)
from brancharchitect.tree_interpolation.core import (
    calculate_intermediate,
    collapse_zero_length_branches_for_node,
    classical_interpolation,
)

logger: logging.Logger = logging.getLogger(__name__)


def _get_subset_splits(
    edge: Partition, current_splits: Dict[Partition, float]
) -> List[Partition]:
    """Find all splits that are subsets of a given edge."""
    return [split for split in current_splits if split.taxa.issubset(edge.taxa)]


def _filter_splits_by_subset(
    splits_dict: Dict[Partition, float],
    subset_splits: List[Partition],
) -> Dict[Partition, float]:
    """Filter a splits dictionary to only include specified subset splits.

    Args:
        splits_dict: The dictionary of splits with their weights
        subset_splits: List of splits to filter by

    Returns:
        A new dictionary containing only the splits that are in subset_splits
    """
    filtered_splits = {
        split: splits_dict[split] for split in subset_splits if split in splits_dict
    }
    return filtered_splits


def _reorder_consensus_tree_by_edge(
    consensus_tree: Node,
    target_tree: Node,
    edge: Partition,
) -> Node:
    """
    Create a reordered copy of the consensus tree based on target tree ordering.

    Args:
        consensus_tree: The consensus tree to reorder
        target_tree: The tree providing the target ordering
        edge: The partition/edge identifying the node to reorder

    Returns:
        A new tree with the specified node reordered according to the target
    """
    # Create a deep copy to avoid modifying the original
    reordered_tree = consensus_tree.deep_copy()

    # Find the corresponding nodes in both trees
    target_node = target_tree.find_node_by_split(edge)
    node_to_reorder = reordered_tree.find_node_by_split(edge)

    if target_node is not None and node_to_reorder is not None:
        # Get the order from the target and apply it
        new_order: List[str] = list(target_node.get_current_order())
        node_to_reorder.reorder_taxa(new_order)

    return reordered_tree


def _create_down_phase_tree(
    base_tree: Node,
    s_edge: Partition,
    s_edge_subset_ref_weights: Dict[Partition, float],
    reference_weights: Dict[Partition, float],
) -> Node:
    """
    Create an intermediate tree for the down phase by applying reference weights.

    Args:
        base_tree: The tree to start from
        s_edge: The s-edge being processed
        s_edge_subset_ref_weights: Reference weights to apply within the s-edge
        reference_weights: Full reference weights for context

    Returns:
        A new tree with adjusted weights for the down phase, or unchanged tree if s-edge not found
    """
    intermediate_tree_down = base_tree.deep_copy()

    intermediate_edge_node = intermediate_tree_down.find_node_by_split(s_edge)

    if intermediate_edge_node is None:
        logger.warning(
            f"S-edge {s_edge} not found in down phase tree, skipping weight adjustment"
        )
        return intermediate_tree_down

    # Apply reference weights to s_edge branches, keep target weights elsewhere
    calculate_intermediate(
        intermediate_edge_node, s_edge_subset_ref_weights, reference_weights
    )

    return intermediate_tree_down


def _create_collapsed_consensus_tree(
    down_phase_tree: Node,
    s_edge: Partition,
) -> Node:
    """
    Create a collapsed consensus tree by removing zero-length branches.

    Args:
        down_phase_tree: The tree from the down phase
        s_edge: The s-edge being processed

    Returns:
        A new tree with zero-length branches collapsed, or unchanged tree if s-edge not found
    """
    collapsed_tree = down_phase_tree.deep_copy()
    consensus_edge_node = collapsed_tree.find_node_by_split(s_edge)

    if consensus_edge_node is None:
        logger.warning(
            f"S-edge {s_edge} not found in collapsed tree, skipping branch collapse"
        )
        return collapsed_tree

    collapse_zero_length_branches_for_node(consensus_edge_node)

    return collapsed_tree


def _create_subtree_grafted_tree(
    reordered_tree: Node,
    reference_tree: Node,
    s_edge: Partition,
) -> Node:
    """
    Create a tree with reference subtree grafted at the s-edge position.

    Args:
        reordered_tree: The tree to graft into
        reference_tree: The tree to take the subtree from
        s_edge: The s-edge identifying the subtree to replace

    Returns:
        A new tree with the reference subtree grafted in, or the reference
        subtree itself if we're replacing the root
    """
    grafted_tree = reordered_tree.deep_copy()
    ref_subtree_to_insert = reference_tree.find_node_by_split(s_edge)
    s_edge_to_replace = grafted_tree.find_node_by_split(s_edge)

    # Replace target subtree with reference subtree (graft effect)
    if s_edge_to_replace and ref_subtree_to_insert and s_edge_to_replace.parent:
        s_edge_to_replace.parent.replace_child(
            s_edge_to_replace, ref_subtree_to_insert.deep_copy()
        )
        return grafted_tree
    else:
        # Handle root replacement case - return the reference subtree
        return (
            ref_subtree_to_insert.deep_copy() if ref_subtree_to_insert else grafted_tree
        )


def _create_pre_snap_tree(
    grafted_tree: Node,
    s_edge: Partition,
    s_edge_subset_target_weights: Dict[Partition, float],
    reference_weights: Dict[Partition, float],
) -> Node:
    """
    Create a pre-snap tree showing reference topology with target weights.

    Args:
        grafted_tree: The tree with reference topology (from grafting step)
        s_edge: The s-edge being processed
        s_edge_subset_target_weights: Target weights to apply within the s-edge
        reference_weights: Full reference weights for context

    Returns:
        A new tree with reference topology but target weights in the s-edge region, or unchanged tree if s-edge not found
    """
    pre_snap_tree = grafted_tree.deep_copy()
    edge_node = pre_snap_tree.find_node_by_split(s_edge)

    if edge_node is None:
        logger.warning(
            f"S-edge {s_edge} not found in pre-snap tree, skipping weight adjustment"
        )
        return pre_snap_tree

    # Apply target weights to show the contrast before full reference weights
    calculate_intermediate(edge_node, s_edge_subset_target_weights, reference_weights)

    return pre_snap_tree


def replace_weights_in_subset(
    current_weights: Dict[Partition, float],
    new_subset_weights: Dict[Partition, float],
    old_splits_to_delete: List[Partition],
) -> Dict[Partition, float]:
    """
    Replaces weights in a dictionary by deleting old splits and adding new ones.

    It first removes all splits specified in `old_splits_to_delete`
    and then adds all weights from `new_subset_weights`. This is not an
    in-place operation; it returns a new dictionary.

    Args:
        current_weights: The main dictionary of weights to be updated.
        new_subset_weights: A dictionary of new weights to add.
        old_splits_to_delete: A list of Partition keys to delete from
                                     current_weights.

    Returns:
        A new dictionary with the subset of weights replaced.
    """
    updated_weights = current_weights.copy()

    # Delete the old splits corresponding to the old topology
    for split in old_splits_to_delete:
        updated_weights.pop(split, None)  # Use pop with a default to avoid errors

    # Add the new splits corresponding to the new topology
    updated_weights.update(new_subset_weights)

    return updated_weights


def _create_classical_interpolation_fallback(
    current_state: Node,
    reference_tree: Node,
    reference_weights: Dict[Partition, float],
    s_edge: Partition,
    num_steps: int = 5,
) -> List[Node]:
    """
    Create a classical interpolation fallback when s-edge processing fails.

    Uses classical_interpolation to bridge from current state to reference tree.

    Args:
        current_state: The last successful interpolation state
        reference_tree: The target reference tree
        reference_weights: The reference tree weights
        s_edge: The s-edge that caused the failure (for logging)
        num_steps: Number of interpolation steps to generate

    Returns:
        A list of trees using classical interpolation
    """
    logger.info(f"Creating classical interpolation fallback for s-edge {s_edge}")

    try:
        # Calculate split data for classical interpolation
        current_splits = current_state.to_weighted_splits()
        split_data = (current_splits, reference_weights)

        # Use classical interpolation between current state and reference
        fallback_trees = classical_interpolation(
            current_state, reference_tree, split_data
        )
        return fallback_trees
    except Exception as e:
        logger.warning(f"Classical interpolation fallback failed: {e}")
        # Last resort: just return copies of current state
        return [current_state.deep_copy() for _ in range(num_steps)]


def generate_s_edge_interpolation_sequence(
    target_tree: Node,
    reference_tree: Node,
    reference_weights: Dict[Partition, float],
    target_s_edges: List[Partition],
) -> tuple[List[Node], List[Partition]]:
    """
    Create an interpolation sequence from target to reference tree.

    For each s-edge, this function generates a sequence of five trees showing
    a detailed transition that interpolates from the target tree's topology
    toward the reference tree's topology.

    Args:
        target_tree: The starting tree for interpolation.
        reference_tree: The destination tree for topology and ordering.
        reference_weights: Branch weights from the reference tree.
        target_s_edges: S-edges to process in order.

    Returns:
        A tuple containing:
        - A list of trees showing the interpolation sequence from target to reference
        - A list of s-edges that failed and used classical interpolation fallback
    """
    if not target_s_edges:
        logger.info("target_s_edges is empty, returning an empty list of trees.")
        return [], []

    interpolation_sequence: List[Node] = []
    failed_s_edges: List[Partition] = []
    target_weights = target_tree.to_weighted_splits()
    logger.info(f"Creating interpolation sequence for {len(target_s_edges)} s-edges.")
    interpolation_state: Node = target_tree.deep_copy()

    for i, s_edge in enumerate(target_s_edges):
        current_base_tree = interpolation_state.deep_copy()
        current_base_tree.initialize_split_indices(current_base_tree.taxa_encoding)
        s_edge_in_current_state = current_base_tree.find_node_by_split(s_edge)
        s_edge_in_reference = reference_tree.find_node_by_split(s_edge)

        if s_edge_in_current_state and s_edge_in_reference:
            #
            # For each s_edge, we create a 5-step interpolation subsequence:
            # Step 1: Weight adjustment - blend reference weights into target topology
            # Step 2: Collapse - remove zero-length branches to simplify
            # Step 3: Reorder - match reference tree's node ordering
            # Step 4: Pre-snap - show reference topology with target weights (contrast)
            # Step 5: Snap - apply full reference weights to complete the transition
            #
            # NOTE: Steps 4 and 5 are computed out of order (5 then 4) because
            # step 4 needs the reference topology created in step 5, but they are
            # appended to the sequence in the correct visual order (4 then 5)

            # Step 1: Weight adjustment - Apply reference weights to s_edge subset while keeping other target weights
            # Extract reference weights for only the branches within this s_edge

            reference_subset_splits = _get_subset_splits(s_edge, reference_weights)

            s_edge_subset_ref_weights = _filter_splits_by_subset(
                reference_weights, reference_subset_splits
            )

            intermediate_tree_down = _create_down_phase_tree(
                current_base_tree, s_edge, s_edge_subset_ref_weights, reference_weights
            )
            interpolation_sequence.append(intermediate_tree_down)

            # Step 2: Collapse - Remove zero-length branches to create consensus
            # This simplifies the topology by removing branches that have been zeroed out
            interp_step2_collapsed = _create_collapsed_consensus_tree(
                intermediate_tree_down, s_edge
            )
            interpolation_sequence.append(interp_step2_collapsed)

            # Step 3: Reorder - Match reference tree's node ordering
            # This prepares for the snap by ensuring child nodes are in the same order
            interp_step3_reordered_to_ref = _reorder_consensus_tree_by_edge(
                interp_step2_collapsed, reference_tree, s_edge
            )
            interpolation_sequence.append(interp_step3_reordered_to_ref)

            # Step 5: Snap to reference - Replace s_edge subtree with reference subtree
            # This is the key topology change: we swap in the reference tree's structure
            interpolation_state = _create_subtree_grafted_tree(
                interp_step3_reordered_to_ref, reference_tree, s_edge
            )

            # Step 4: Pre-snap preparation - Adjust weights before final snap
            # This step shows the new reference topology but with the old target weights
            # applied only to the subset of branches being changed in this step.

            # Get weights from the current state of the tree *before* this snap.
            current_weights = current_base_tree.to_weighted_splits()

            # Filter to get the weights for the specific subset of branches being transformed.
            s_edge_subset_target_weights = _filter_splits_by_subset(
                current_weights, reference_subset_splits
            )

            interp_step4_pre_snap = _create_pre_snap_tree(
                interpolation_state,
                s_edge,
                s_edge_subset_target_weights,  # Use the filtered target weights
                reference_weights,
            )

            interpolation_sequence.append(interp_step4_pre_snap)
            interpolation_sequence.append(interpolation_state)

            logger.debug(
                f"Step {i + 1}/{len(target_s_edges)}: Generated 5 trees for s-edge {s_edge}"
            )

        else:
            logger.warning(
                f"s-edge {s_edge} not found in both trees. Using classical interpolation fallback."
            )
            # Track this s-edge as failed
            failed_s_edges.append(s_edge)
            # Fallback: Use classical interpolation between current state and reference
            fallback_trees = _create_classical_interpolation_fallback(
                interpolation_state, reference_tree, reference_weights, s_edge
            )
            interpolation_sequence.extend(fallback_trees)

    return interpolation_sequence, failed_s_edges


def generate_tree_names(
    tree_index: int, num_down: int, num_consensus: int, num_up: int
) -> List[str]:
    """Generate names for a single interpolation sequence."""
    names: list[str] = []
    # Starting tree
    names.append(f"T{tree_index}")
    # Down phase trees
    names.extend([f"IT{tree_index}_down_{i + 1}" for i in range(num_down)])
    # Consensus phase trees
    names.extend([f"C{tree_index}_{i + 1}" for i in range(num_consensus)])
    # Up phase trees
    names.extend([f"IT{tree_index}_up_{i + 1}" for i in range(num_up)])
    return names


def generate_simple_tree_names(tree_index: int, num_s_edges: int) -> List[str]:
    """Generate names for s-edge based interpolation sequence."""
    names = [f"T{tree_index}"]  # Starting tree
    for i in range(num_s_edges):
        names.extend(
            [
                f"IT{tree_index}_down_{i + 1}",  # Step 1: Down phase
                f"C{tree_index}_{i + 1}",  # Step 2: Collapse (consensus)
                f"C{tree_index}_{i + 1}_reorder",  # Step 3: Reorder
                f"IT{tree_index}_up_{i + 1}",  # Step 4: Pre-snap (up phase)
                f"IT{tree_index}_ref_{i + 1}",  # Step 5: Snap (reference state)
            ]
        )
    return names


def generate_s_edge_tracking(
    lattice_edge_data: LatticeEdgeData, num_down: int, num_consensus: int, num_up: int
) -> List[Optional[Partition]]:
    """
    Generate s_edge tracking list that corresponds to each interpolated tree.

    Returns a list where each element corresponds to the s_edge (lattice edge)
    that was applied to generate that tree, or None for starting/ending trees.
    """
    # Get the edge sequences used in each phase
    sorted_target_desc: List[Partition] = lattice_edge_data.get_sorted_edges(
        use_reference=False, ascending=True
    )
    sorted_reference_desc: List[Partition] = lattice_edge_data.get_sorted_edges(
        use_reference=True, ascending=True
    )
    sorted_edges_asc: List[Partition] = lattice_edge_data.get_sorted_edges(
        use_reference=True, ascending=True
    )

    s_edge_tracking: List[Optional[Partition]] = []

    # Starting tree (no s_edge applied)
    s_edge_tracking.append(None)

    # Down phase - each tree is generated by applying one edge from sorted_target_desc
    for i in range(num_down):
        if i < len(sorted_target_desc):
            s_edge_tracking.append(sorted_target_desc[i])
        else:
            s_edge_tracking.append(None)

    # Consensus phase - each tree is generated by applying one edge from sorted_edges_asc
    for i in range(num_consensus):
        if i < len(sorted_edges_asc):
            s_edge_tracking.append(sorted_edges_asc[i])
        else:
            s_edge_tracking.append(None)

    # Up phase - each tree is generated by applying one edge from sorted_reference_desc (reversed)
    sorted_reference_desc_reversed = sorted_reference_desc[::-1]
    for i in range(num_up):
        if i < len(sorted_reference_desc_reversed):
            s_edge_tracking.append(sorted_reference_desc_reversed[i])
        else:
            s_edge_tracking.append(None)

    return s_edge_tracking


def generate_simple_tree_names_with_fallback(
    tree_index: int, target_s_edges: List[Partition], failed_s_edges: List[Partition]
) -> List[str]:
    """Generate names for s-edge based interpolation sequence, marking classical fallbacks."""
    names = [f"T{tree_index}"]  # Starting tree
    failed_set = set(failed_s_edges)

    for i, s_edge in enumerate(target_s_edges):
        if s_edge in failed_set:
            # Classical interpolation fallback
            names.extend(
                [
                    f"IT{tree_index}_classical_{i + 1}_1",  # Classical step 1
                    f"IT{tree_index}_classical_{i + 1}_2",  # Classical step 2
                    f"IT{tree_index}_classical_{i + 1}_3",  # Classical step 3
                    f"IT{tree_index}_classical_{i + 1}_4",  # Classical step 4
                    f"IT{tree_index}_classical_{i + 1}_5",  # Classical step 5
                ]
            )
        else:
            # Normal s-edge interpolation
            names.extend(
                [
                    f"IT{tree_index}_down_{i + 1}",  # Step 1: Down phase
                    f"C{tree_index}_{i + 1}",  # Step 2: Collapse (consensus)
                    f"C{tree_index}_{i + 1}_reorder",  # Step 3: Reorder
                    f"IT{tree_index}_up_{i + 1}",  # Step 4: Pre-snap (up phase)
                    f"IT{tree_index}_ref_{i + 1}",  # Step 5: Snap (reference state)
                ]
            )
    return names


def generate_simple_s_edge_tracking_with_fallback(
    target_s_edges: List[Partition], failed_s_edges: List[Partition]
) -> List[Optional[Partition]]:
    """Generate s_edge tracking for s-edge based interpolation sequence, marking classical fallbacks."""
    tracking = [None]  # Starting tree T{index} - no s-edge applied
    failed_set = set(failed_s_edges)

    for s_edge in target_s_edges:
        if s_edge in failed_set:
            # Mark as None for classical interpolation fallback
            tracking.extend(
                [None] * 5
            )  # Classical interpolation doesn't use specific s-edge
        else:
            # Normal s-edge tracking
            tracking.extend([s_edge] * 5)  # Each s-edge generates 5 trees
    return tracking
