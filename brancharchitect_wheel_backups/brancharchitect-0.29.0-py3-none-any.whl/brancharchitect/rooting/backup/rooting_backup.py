"""
Robust rerooting implementation for phylogenetic trees.

This module provides a unified interface to various rerooting strategies by
importing and exposing functions from specialized modules:
- Core rerooting operations (core_rooting.py)
- Advanced optimization algorithms (optimization_rooting.py)

Author: BranchArchitect Team
"""

# Import all public functions from specialized modules
from ..core_rooting import (
    # Helper functions
    _flip_upward,
    # Core rerooting operations
    find_best_matching_node,
    simple_reroot,
    reroot_at_node,
    # Midpoint rooting
    find_farthest_leaves,
    path_between,
    midpoint_root,
)

from ..optimization_rooting import (
    # Node matching and correspondence
    find_best_matching_node_jaccard,
    # Jaccard similarity-based matching
    reroot_by_jaccard_similarity,
    # Enhanced global optimization
    build_global_correspondence_map,
    find_optimal_root_candidates,
    reroot_to_compared_tree,
)

# For backward compatibility, maintain the original imports
from typing import Optional, Dict, Tuple, List, Any
from collections import deque
from brancharchitect.elements.partition_set import PartitionSet
from brancharchitect.tree import Node
from brancharchitect.elements.partition import Partition


# =============================================================================
# HELPER FUNCTIONS FOR TREE STRUCTURE MANIPULATION
# =============================================================================


def _collect_path_to_root(start_node: Node) -> List[Node]:
    """
    Collect all nodes from start_node up to the current root.

    Args:
        start_node: The node to start collecting from

    Returns:
        List of nodes from start_node to root (inclusive)
    """
    path: List[Node] = []
    node: Node = start_node
    while node is not None:
        path.append(node)
        node = node.parent
    return path


def _update_node_relationships(
    node: Node, prev: Optional[Node], prev_length: float
) -> Tuple[Node, float]:
    """
    Update a single node's parent/child relationships during rerooting.

    Args:
        node: The node to update
        prev: The previous node in the path (becomes new parent, None for root)
        prev_length: The branch length to assign to this node

    Returns:
        Tuple of (node, old_length) for use in next iteration
    """
    parent: Node | None = node.parent
    old_length: float = node.length or 0.0

    # Save the original children (before any modification)
    orig_children = list(node.children)

    # Remove prev from children (if present)
    children_to_keep: List[Node] = [ch for ch in orig_children if ch is not prev]

    # If parent exists, remove node from parent's children
    if parent is not None and node in parent.children:
        parent.children.remove(node)

    # Set node's parent to prev (None for new root)
    node.parent = prev
    node.length = prev_length

    # For all but the new root, add parent as a child
    new_children: List[Node] = children_to_keep
    if parent is not None:
        new_children.append(parent)
    node.children = new_children

    return node, old_length


# =============================================================================
# CORE REROOTING OPERATIONS
# =============================================================================


def find_best_matching_node(target_partition: Partition, root: Node) -> Optional[Node]:
    """
    Returns the node in root whose Partition has the largest overlap with target_partition.
    Uses bitmask operations for efficient set intersection and early termination for perfect matches.

    Optimized: Use split-to-node mapping for O(1) lookup if possible, otherwise fall back to overlap search.
    Handles both Partition and tuple/set input, and uses bitmask logic if available.
    """
    # Try fast path: use split-to-node mapping if possible
    root.build_split_index()
    split_to_node: Dict[Partition, Node] = (
        root._split_index if root._split_index is not None else {}
    )

    # If the exact split exists, return immediately
    node = split_to_node.get(target_partition)
    if node is not None:
        return node

    # Fallback: search for the node with the largest overlap
    best_node = None
    best_overlap = 0

    # Use bitmask if available
    if hasattr(target_partition, "bitmask"):
        target_bitmask = target_partition.bitmask
        target_size = bin(target_bitmask).count("1")
    else:
        target_indices = (
            set(target_partition.indices)
            if hasattr(target_partition, "indices")
            else set(target_partition)
        )
        target_size = len(target_indices)

    for node in root.traverse():
        partition_b = node.split_indices
        if hasattr(target_partition, "bitmask") and hasattr(partition_b, "bitmask"):
            overlap = bin(target_partition.bitmask & partition_b.bitmask).count("1")
        else:
            node_indices = (
                set(partition_b.indices)
                if hasattr(partition_b, "indices")
                else set(partition_b)
            )
            overlap: int = len(target_indices & node_indices)

        if overlap > best_overlap:
            best_overlap = overlap
            best_node = node
            if overlap == target_size:
                return best_node
    return best_node


def reroot_to_best_match(reference_node: Node, target_tree_root: Node) -> Node:
    """
    Reroots the target tree at the node whose clade/partition best matches the reference_node's clade.
    Returns the new root of the rerooted tree.
    """
    target_partition: Partition = reference_node.split_indices
    best_node: Node | None = find_best_matching_node(target_partition, target_tree_root)
    if best_node is None:
        raise ValueError("No matching node found for rerooting.")
    rerooted_tree: Node = reroot_at_node(best_node)
    rerooted_tree.invalidate_caches()
    rerooted_tree.build_split_index()
    rerooted_tree._initialize_split_indices(rerooted_tree.taxa_encoding)
    return rerooted_tree


def build_correspondence_map(
    tree_a_root: Node, tree_b_root: Node
) -> Dict[Node, Optional[Node]]:
    """
    Build a correspondence map from each node in tree A to its best matching node in tree B (by clade overlap).
    For leaves, prioritize exact matches (same taxon name).
    Returns a dict: {node_a: best_node_b}
    """
    # Build fast lookup for leaves by name in tree_b_root
    leaf_name_to_node: Dict[str, Node] = {
        n.name: n for n in tree_b_root.traverse() if n.is_leaf() and n.name is not None
    }
    # Build split-to-node mapping for internal nodes in tree_b_root
    tree_b_root.build_split_index()
    split_to_node: Dict[Partition, Node] = (
        tree_b_root._split_index if tree_b_root._split_index is not None else {}
    )

    correspondence_map = {}
    for node_a in tree_a_root.traverse():
        best_node_b = None
        if node_a.is_leaf():
            # Fast leaf match by name
            best_node_b = leaf_name_to_node.get(node_a.name)
        else:
            # Fast internal node match by split
            best_node_b: Node | None = split_to_node.get(node_a.split_indices)

        # Fallback: if no best match found, map to the same node if it exists in tree B
        if best_node_b is None and node_a in tree_b_root.traverse():
            best_node_b = node_a

        correspondence_map[node_a] = best_node_b
    return correspondence_map


# =============================================================================
# MIDPOINT ROOTING
# =============================================================================
def _collect_all_leaves_bfs(root: Node) -> List[Node]:
    """
    Collect all leaves in the tree using BFS traversal.

    Args:
        root: Starting node for traversal

    Returns:
        List of all leaf nodes in the tree

    Raises:
        ValueError: If no leaves are found
    """
    leaves = []
    visited = set()
    queue = deque([root])

    while queue:
        node: Node = queue.popleft()
        node_id: int = id(node)
        if node_id in visited:
            continue
        visited.add(node_id)

        if node.is_leaf():
            leaves.append(node)

        # Traverse both parent and children
        if node.parent and id(node.parent) not in visited:
            queue.append(node.parent)
        for child in node.children:
            if id(child) not in visited:
                queue.append(child)

    if not leaves:
        raise ValueError("Tree has no leaves")

    return leaves


def find_farthest_leaves(root: Node) -> Tuple[Node, Node, float]:
    """
    Find the two leaves in the tree that are farthest apart and return them and their distance.

    Uses the standard two-BFS algorithm: first BFS finds the farthest leaf from an arbitrary start,
    then second BFS from that leaf finds the actual farthest pair.

    Args:
        root: Any node in the tree to start from

    Returns:
        Tuple of (leaf1, leaf2, distance) representing the farthest pair
    """
    # Collect all leaves to get a starting point
    leaves = _collect_all_leaves_bfs(root)

    # Use the two-BFS algorithm for finding diameter
    start = leaves[0]
    farthest, _ = _bfs_farthest(start)
    other, max_dist = _bfs_farthest(farthest)

    return farthest, other, max_dist


def _get_node_neighbors_with_distances(node: Node) -> List[Tuple[Node, float]]:
    """
    Get all neighbors of a node with their edge distances.

    Args:
        node: The node to get neighbors for

    Returns:
        List of (neighbor_node, edge_length) tuples
    """
    neighbors = []
    if node.parent:
        neighbors.append((node.parent, node.length or 0.0))
    for child in node.children:
        neighbors.append((child, child.length or 0.0))
    return neighbors


def _bfs_farthest(start: Node) -> Tuple[Node, float]:
    """
    Find the farthest node from start node using BFS.

    Args:
        start: The starting node for BFS

    Returns:
        Tuple of (farthest_node, distance_to_farthest)
    """
    visited = set()
    queue = deque([(start, 0.0)])
    farthest: Optional[Node] = start
    max_dist: float = 0.0

    while queue:
        node, dist = queue.popleft()
        node_id = id(node)
        if node_id in visited:
            continue
        visited.add(node_id)

        if node.is_leaf() and dist > max_dist:
            farthest, max_dist = node, dist

        neighbors = _get_node_neighbors_with_distances(node)
        for neighbor, edge_len in neighbors:
            if id(neighbor) not in visited:
                queue.append((neighbor, dist + edge_len))

    # farthest is always a Node, but type checker wants Optional[Node]
    assert farthest is not None
    return farthest, max_dist


def _build_path_reconstruction_data(
    node1: Node, node2: Node
) -> Tuple[Dict[int, Tuple[Optional[Node], float]], Dict[int, Node]]:
    """
    Build data structures needed for path reconstruction using BFS.

    Args:
        node1: Starting node
        node2: Target node

    Returns:
        Tuple of (parent_map, node_map) for path reconstruction

    Raises:
        ValueError: If no path exists between the nodes
    """
    parent: Dict[int, Tuple[Optional[Node], float]] = {id(node1): (None, 0.0)}
    node_map: Dict[int, Node] = {id(node1): node1}
    queue = deque([node1])

    while queue:
        node: Node = queue.popleft()
        for neighbor, edge_len in _neighbors_with_length(node):
            neighbor_id: int = id(neighbor)
            if neighbor_id not in parent:
                parent[neighbor_id] = (node, edge_len)
                node_map[neighbor_id] = neighbor
                queue.append(neighbor)

    if id(node2) not in parent:
        raise ValueError(
            f"No path found between nodes: {getattr(node1, 'name', None)} and {getattr(node2, 'name', None)}"
        )

    return parent, node_map


def _reconstruct_path_from_bfs_data(
    node1: Node, node2: Node, parent: Dict[int, Tuple[Optional[Node], float]]
) -> List[Tuple[Node, float]]:
    """
    Reconstruct the actual path from BFS parent data.

    Args:
        node1: Starting node
        node2: Target node
        parent: Parent mapping from BFS

    Returns:
        List of (node, edge_length) tuples representing the path
    """
    path = []
    node = node2

    while node != node1:
        prev, edge_len = parent[id(node)]
        assert prev is not None  # for type checker
        path.append((node, edge_len))
        node = prev

    path.append((node1, 0.0))
    path.reverse()
    return path


def path_between(node1: Node, node2: Node) -> List[Tuple[Node, float]]:
    """
    Return the path (as list of (node, edge_length)) from node1 to node2.

    Args:
        node1: Starting node
        node2: Target node

    Returns:
        List of (node, edge_length) tuples representing the path from node1 to node2

    Raises:
        ValueError: If no path exists between the nodes
    """
    parent, node_map = _build_path_reconstruction_data(node1, node2)
    return _reconstruct_path_from_bfs_data(node1, node2, parent)


def _neighbors_with_length(node: Node):
    """Get neighbors of a node with their edge lengths."""
    if node.parent:
        yield node.parent, node.length or 0.0
    for child in node.children:
        yield child, child.length or 0.0


def _find_midpoint_on_path(path: List[Tuple[Node, float]], max_dist: float) -> Node:
    """
    Find the exact midpoint position along a path and return the appropriate root.

    Args:
        path: List of (node, edge_length) tuples representing the path
        max_dist: Total distance of the path

    Returns:
        The node to root at (either existing node or newly inserted)

    Raises:
        RuntimeError: If midpoint cannot be found
    """
    half = max_dist / 2.0
    acc = 0.0

    for i in range(1, len(path)):
        prev_node, _ = path[i - 1]
        node, edge_len = path[i]

        if acc + edge_len == half:
            # Midpoint is exactly at this node
            return reroot_at_node(node)
        elif acc + edge_len > half:
            # Midpoint is on the edge between prev_node and node
            dist_from_prev: float = half - acc
            dist_from_next: float = edge_len - dist_from_prev
            return insert_root_on_edge(prev_node, node, dist_from_prev, dist_from_next)

        acc += edge_len

    raise RuntimeError("Failed to find midpoint on path")


def midpoint_root(tree: Node) -> Node:
    """
    Return a new tree rooted at the midpoint of the longest path between any two leaves.

    Args:
        tree: The tree to reroot at its midpoint

    Returns:
        A copy of the tree rooted at the midpoint
    """
    tree = tree.deep_copy()
    L1, L2, max_dist = find_farthest_leaves(tree)
    path = path_between(L1, L2)
    return _find_midpoint_on_path(path, max_dist)


# =============================================================================
# JACCARD SIMILARITY-BASED MATCHING
# =============================================================================


def reroot_at_node(node: Node) -> Node:
    """
    Reroot the tree at the specified node.

    Args:
        node: The node to become the new root

    Returns:
        The new root of the rerooted tree
    """
    # Find the original root to get the encoding
    original_root: Node = node
    while original_root.parent is not None:
        original_root = original_root.parent

    # Store the original encoding and order
    original_encoding = getattr(original_root, "_encoding", {})
    original_order = getattr(original_root, "_order", ())

    # Perform the rerooting
    rerooted_tree: Node = _flip_upward(node)

    # Propagate the encoding and order to all nodes in the rerooted tree
    def propagate_tree_attributes(
        node: Node, encoding: dict[str, int], order: list[str]
    ):
        node.taxon_encoding = encoding
        if hasattr(node, "_order"):
            node._order = order
        for child in node.children:
            propagate_tree_attributes(child, encoding, order)

    propagate_tree_attributes(rerooted_tree, original_encoding, original_order)
    return rerooted_tree


def insert_root_on_edge(node1: Node, node2: Node, len1: float, len2: float) -> Node:
    """
    Insert a new root node on the edge between two nodes.

    Args:
        node1: First node
        node2: Second node
        len1: Length from new root to node1
        len2: Length from new root to node2

    Returns:
        The new root node
    """
    # Disconnect node2 from node1
    if node2.parent == node1:
        node1.children.remove(node2)
        node2.parent = None
    elif node1.parent == node2:
        node2.children.remove(node1)
        node1.parent = None
    else:
        raise ValueError("Nodes are not directly connected")

    root = type(node1)(name="MidpointRoot", length=0.0)
    node1.length = len1
    node2.length = len2
    root.children = [node1, node2]
    node1.parent = root
    node2.parent = root
    return root


def _flip_upward(new_root: Node) -> Node:
    """
    Reverse parent/child relationships along the path to create a new root.

    This is the core rerooting algorithm that preserves all tree structure
    while changing the root position.

    Args:
        new_root: The node that should become the new root

    Returns:
        The new root node with updated tree structure
    """
    # Step 1: Collect the path from new_root up to the current root
    path: List[Node] = _collect_path_to_root(new_root)

    # Step 2: Reverse parent/child relationships along the path
    prev: Optional[Node] = None
    prev_length = 0.0

    for node in path:
        prev, prev_length = _update_node_relationships(node, prev, prev_length)

    return new_root


# =============================================================================
# NODE MATCHING AND CORRESPONDENCE
# =============================================================================


def _get_target_indices_and_bitmask(
    target_partition: Partition,
) -> Tuple[Optional[int], Optional[set]]:
    """
    Extract bitmask and indices from target partition for efficient comparison.

    Args:
        target_partition: The partition to extract data from

    Returns:
        Tuple of (bitmask, indices_set) where one may be None
    """
    target_bitmask = None
    target_indices = None

    if hasattr(target_partition, "bitmask"):
        target_bitmask = target_partition.bitmask
    else:
        target_indices = (
            set(target_partition.indices)
            if hasattr(target_partition, "indices")
            else set(target_partition)
        )

    return target_bitmask, target_indices


def _calculate_jaccard_similarity(
    target_partition: Partition,
    target_bitmask: Optional[int],
    target_indices: Optional[set],
    partition_b: Partition,
) -> float:
    """
    Calculate Jaccard similarity between target partition and partition_b.

    Args:
        target_partition: Original target partition for fallback
        target_bitmask: Bitmask of target partition (if available)
        target_indices: Indices set of target partition (if available)
        partition_b: The partition to compare against

    Returns:
        Jaccard similarity score (0.0 to 1.0)
    """
    # Use bitmask for efficient calculation if available
    if target_bitmask is not None and hasattr(partition_b, "bitmask"):
        # Bitwise operations for intersection and union
        intersection_bits = target_bitmask & partition_b.bitmask
        union_bits = target_bitmask | partition_b.bitmask

        intersection_count: int = bin(intersection_bits).count("1")
        union_count: int = bin(union_bits).count("1")

        return intersection_count / union_count if union_count > 0 else 0.0
    else:
        # Fallback to set operations
        if target_indices is None:
            target_indices = (
                set(target_partition.indices)
                if hasattr(target_partition, "indices")
                else set(target_partition)
            )

        node_indices = (
            set(partition_b.indices)
            if hasattr(partition_b, "indices")
            else set(partition_b)
        )

        intersection: int = len(target_indices & node_indices)
        union: int = len(target_indices | node_indices)

        return intersection / union if union > 0 else 0.0


def find_best_matching_node_jaccard(
    target_partition: Partition, root: Node
) -> Optional[Node]:
    """
    Returns the node in root whose Partition has the highest Jaccard similarity with target_partition.
    Jaccard similarity = |intersection| / |union|, inspired by phylo-io's approach.
    """
    best_node = None
    best_jaccard = 0.0

    # Extract target partition data once for efficiency
    target_bitmask, target_indices = _get_target_indices_and_bitmask(target_partition)

    for node in root.traverse():
        partition_b: Partition = node.split_indices

        jaccard = _calculate_jaccard_similarity(
            target_partition, target_bitmask, target_indices, partition_b
        )

        if jaccard > best_jaccard:
            best_jaccard = jaccard
            best_node = node

            # Early termination for perfect Jaccard similarity
            if jaccard == 1.0:
                return best_node

    return best_node


def reroot_to_best_match_jaccard(reference_node: Node, target_tree_root: Node) -> Node:
    """
    Reroots the target tree at the node whose clade has the highest Jaccard similarity
    with the reference_node's clade. Uses phylo-io-inspired similarity metric.
    Returns the new root of the rerooted tree.
    """
    target_partition: Partition = reference_node.split_indices
    best_node: Node | None = find_best_matching_node_jaccard(
        target_partition, target_tree_root
    )

    if best_node is None:
        raise ValueError("No matching node found for rerooting.")
    rerooted_tree: Node = reroot_at_node(best_node)
    rerooted_tree.invalidate_caches()
    rerooted_tree.build_split_index()
    rerooted_tree._initialize_split_indices(rerooted_tree.taxa_encoding)
    return rerooted_tree


# =============================================================================
# ENHANCED GLOBAL OPTIMIZATION (PHYLO-IO INSPIRED)
# =============================================================================


def _filter_and_score_split_candidates(
    split_a: Partition,
    splits_b: PartitionSet[Partition],
    similarity_matrix: Dict[Tuple[Partition, Partition], float],
) -> List[Tuple[Partition, float]]:
    """
    Filter and score potential split candidates for a given split.

    Args:
        split_a: The source split to find candidates for
        splits_b: All splits in the target tree
        similarity_matrix: Pre-computed similarity scores

    Returns:
        List of (split_b, similarity_score) tuples, sorted by decreasing similarity
    """
    # Gather all split_b with nonzero similarity to split_a
    candidates = [
        (split_b, similarity_matrix[(split_a, split_b)])
        for split_b in splits_b
        if len(split_b) > 1 and similarity_matrix.get((split_a, split_b), 0) > 0
    ]
    candidates.sort(key=lambda x: x[1], reverse=True)
    return candidates


def build_global_correspondence_map(
    tree_a: Node, tree_b: Node
) -> Dict[Partition, List[Tuple[Partition, float]]]:
    """
    Build a global correspondence map like phylo-io's elementBCN.
    Uses BranchArchitect's optimized to_splits() method instead of manual traversal.

    For each split in tree_a, find ALL potential corresponding splits in tree_b
    with their similarity scores, sorted by best match first.

    This replaces the on-demand single-node matching with pre-computed global analysis.

    Returns:
        Dict mapping each split in tree_a to a list of (split_b, jaccard_similarity) tuples,
        sorted by decreasing similarity.
    """
    # Use the all-to-all similarity matrix for efficiency and deduplication
    similarity_matrix = compute_all_to_all_similarity_matrix(tree_a, tree_b)
    correspondence_map = {}
    splits_a: PartitionSet[Partition] = tree_a.to_splits()
    splits_b: PartitionSet[Partition] = tree_b.to_splits()

    for split_a in splits_a:
        if len(split_a) <= 1:
            continue

        # Filter and score candidates for this split
        candidates = _filter_and_score_split_candidates(
            split_a, splits_b, similarity_matrix
        )
        correspondence_map[split_a] = candidates

    return correspondence_map


def _compute_jaccard_similarity_splits(split_a: Partition, split_b: Partition) -> float:
    """
    Compute Jaccard similarity between two splits (Partition objects).
    Optimized for BranchArchitect's split representation.
    Jaccard = |intersection| / |union|
    """
    # Use bitmask for efficient computation if available
    if hasattr(split_a, "bitmask") and hasattr(split_b, "bitmask"):
        intersection_bits = split_a.bitmask & split_b.bitmask
        union_bits = split_a.bitmask | split_b.bitmask

        intersection = bin(intersection_bits).count("1")
        union = bin(union_bits).count("1")
    else:
        # Fallback to set operations on indices
        set_a = set(split_a.indices) if hasattr(split_a, "indices") else set(split_a)
        set_b = set(split_b.indices) if hasattr(split_b, "indices") else set(split_b)

        intersection: int = len(set_a & set_b)
        union: int = len(set_a | set_b)

    return intersection / union if union > 0 else 0.0


def _get_split_to_node_mapping_for_root_search(tree: Node) -> Dict[Partition, Node]:
    """
    Create a mapping from splits to nodes for root candidate evaluation.

    Args:
        tree: The tree to create mapping for

    Returns:
        Dictionary mapping splits to their corresponding nodes
    """
    tree.build_split_index()
    if tree._split_index is None:
        return {}
    return tree._split_index


def _evaluate_split_as_root_candidate(
    split_b: Partition,
    tree_a: Node,
    tree_b: Node,
    correspondence_map: Dict[Partition, List[Tuple[Partition, float]]],
    split_to_node_b: Dict[Partition, Node],
) -> Optional[Tuple[Node, float]]:
    """
    Evaluate a single split as a potential root candidate.

    Args:
        split_b: The split to evaluate as root
        tree_a: Reference tree
        tree_b: Target tree
        correspondence_map: Global correspondence mapping
        split_to_node_b: Mapping from splits to nodes in tree_b

    Returns:
        Tuple of (node, global_score) if valid candidate, None otherwise
    """
    if len(split_b) <= 1:  # Skip trivial splits (leaves)
        return None

    # Get the corresponding node for this split
    potential_root: Node | None = split_to_node_b.get(split_b)
    if potential_root is None:
        return None

    # Compute global similarity score if we root tree_b at this node
    global_score: float = _compute_global_similarity_score_splits(
        tree_a, tree_b, split_b, correspondence_map
    )

    return (potential_root, global_score)


def _add_fallback_candidates(
    tree_b: Node, root_candidates: List[Tuple[Node, float]]
) -> None:
    """
    Add fallback candidates (all nodes) with zero score if no good candidates found.

    Args:
        tree_b: Target tree to get nodes from
        root_candidates: List to add candidates to (modified in place)
    """
    for node in tree_b.traverse():
        global_score = 0.0  # Could compute a fallback score if needed
        root_candidates.append((node, global_score))


def find_optimal_root_candidates(
    tree_a: Node,
    tree_b: Node,
    correspondence_map: Optional[Dict[Partition, List[Tuple[Partition, float]]]] = None,
) -> List[Tuple[Node, float]]:
    """
    Find optimal root candidates in tree_b based on global tree structure analysis.
    Uses BranchArchitect's optimized to_splits() method instead of manual traversal.

    This implements phylo-io's strategy of choosing roots that optimize global tree similarity
    rather than just local node matching.

    Args:
        tree_a: Reference tree
        tree_b: Target tree to be rerooted
        correspondence_map: Pre-computed global correspondence map (optional)

    Returns:
        List of (candidate_node, global_similarity_score) tuples, sorted by decreasing score
    """
    if correspondence_map is None:
        correspondence_map = build_global_correspondence_map(tree_a, tree_b)

    root_candidates = []

    # Get mapping from splits to nodes for rerooting
    split_to_node_b = _get_split_to_node_mapping_for_root_search(tree_b)

    # Evaluate each potential root position in tree_b using splits
    splits_b: PartitionSet[Partition] = tree_b.to_splits()
    for split_b in splits_b:
        candidate_result = _evaluate_split_as_root_candidate(
            split_b, tree_a, tree_b, correspondence_map, split_to_node_b
        )
        if candidate_result is not None:
            root_candidates.append(candidate_result)

    # Sort by decreasing global similarity score
    root_candidates.sort(key=lambda x: x[1], reverse=True)

    # Add fallback candidates if needed
    _add_fallback_candidates(tree_b, root_candidates)

    return root_candidates


def _calculate_split_weight(
    split_a: Partition, splits_a: PartitionSet[Partition]
) -> float:
    """
    Calculate the structural weight of a split based on its size.

    Args:
        split_a: The split to calculate weight for
        splits_a: All splits in the tree for normalization

    Returns:
        Weight value between 0.0 and 1.0
    """
    return len(split_a) / len(splits_a) if len(splits_a) > 0 else 1.0


def _get_best_similarity_for_split(
    split_a: Partition,
    correspondence_map: Dict[Partition, List[Tuple[Partition, float]]],
) -> float:
    """
    Get the best similarity score for a split from the correspondence map.

    Args:
        split_a: The split to get similarity for
        correspondence_map: Global correspondence mapping

    Returns:
        Best similarity score (0.0 if no correspondence found)
    """
    if split_a in correspondence_map and correspondence_map[split_a]:
        # Get the best correspondence for this split
        _, best_similarity = correspondence_map[split_a][0]
        return best_similarity
    return 0.0


def _compute_global_similarity_score_splits(
    tree_a: Node,
    tree_b: Node,
    potential_root_split: Partition,
    correspondence_map: Dict[Partition, List[Tuple[Partition, float]]],
) -> float:
    """
    Compute a global similarity score for rerooting tree_b at potential_root_split.
    Uses split-based operations instead of manual traversal.

    This simulates the tree structure that would result from rerooting and
    evaluates how well it matches tree_a across all splits.

    Args:
        tree_a: Reference tree
        tree_b: Target tree to be rerooted
        potential_root_split: The split at which to potentially root tree_b
        correspondence_map: Global correspondence mapping

    Returns:
        Global similarity score (0.0 to 1.0)
    """
    total_score: float = 0.0
    node_count: float = 0.0

    # Use splits instead of traversing nodes
    splits_a: PartitionSet[Partition] = tree_a.to_splits()

    for split_a in splits_a:
        if len(split_a) <= 1:  # Skip trivial splits
            continue

        best_similarity = _get_best_similarity_for_split(split_a, correspondence_map)

        # Weight the similarity by the structural importance of the split
        # (larger splits might be weighted more as they represent larger clades)
        weight = _calculate_split_weight(split_a, splits_a)

        total_score += best_similarity * weight
        node_count += weight

    return total_score / node_count if node_count > 0 else 0.0


def _fallback_to_simple_rerooting(reference_tree: Node, target_tree: Node) -> Node:
    """
    Fallback to simple rerooting when global optimization is disabled.

    Args:
        reference_tree: The tree to match against
        target_tree: The tree to be rerooted

    Returns:
        Rerooted target tree
    """
    if reference_tree.children:
        reference_node = reference_tree.children[0]  # Use first child as reference
        return reroot_to_best_match(reference_node, target_tree)

    # If no children, just return the target tree as-is
    return target_tree


def _select_best_non_leaf_candidate(root_candidates: List[Tuple[Node, float]]) -> Node:
    """
    Select the best root candidate, preferring non-leaf nodes.

    Args:
        root_candidates: List of (node, score) tuples sorted by score

    Returns:
        The best candidate node
    """
    best_root_node = None
    for candidate, _ in root_candidates:
        if not candidate.is_leaf():
            best_root_node = candidate
            break
    else:
        # All candidates are leaves; fallback to first candidate
        best_root_node = root_candidates[0][0]

    return best_root_node


def _validate_and_rebuild_tree_structure(
    rerooted_tree: Node, original_encoding: Dict
) -> Node:
    """
    Validate and rebuild tree structure after rerooting to ensure consistency.

    Args:
        rerooted_tree: The rerooted tree
        original_encoding: Original tree encoding to maintain

    Returns:
        The validated and rebuilt tree

    Raises:
        ValueError: If validation fails
    """
    # Check that all leaves in rerooted_tree are present in the original encoding
    rerooted_leaves: List[str] = [leaf.name for leaf in rerooted_tree.get_leaves()]
    if set(rerooted_leaves) != set(original_encoding.keys()):
        raise ValueError(
            f"Leaf set after rerooting does not match original encoding. "
            f"Leaves: {rerooted_leaves}, Encoding: {list(original_encoding.keys())}"
        )

    # Rebuild split indices using the original encoding (order does not matter, only encoding)
    rerooted_tree._initialize_split_indices(original_encoding)

    # Check that encoding is unchanged
    if rerooted_tree.taxa_encoding != original_encoding:
        raise ValueError("Tree encoding changed after rerooting. This is not allowed.")

    return rerooted_tree


def reroot_to_compared_tree(
    reference_tree: Node, target_tree: Node, use_global_optimization: bool = True
) -> Node:
    """
    Enhanced rerooting function that mimics phylo-io's reroot_to_compared_tree.

    This implements the missing global correspondence mapping and optimal root selection
    that phylo-io uses instead of BranchArchitect's simpler node-by-node matching.

    Args:
        reference_tree: The tree to match against
        target_tree: The tree to be rerooted
        use_global_optimization: Whether to use global optimization (True) or fall back to simple matching

    Returns:
        Rerooted target tree that best matches the reference tree structure
    """
    if not use_global_optimization:
        # Fall back to existing implementation
        return _fallback_to_simple_rerooting(reference_tree, target_tree)

    # Build global correspondence map (like phylo-io's elementBCN)
    correspondence_map = build_global_correspondence_map(reference_tree, target_tree)

    # Find optimal root candidates using global analysis
    root_candidates = find_optimal_root_candidates(
        reference_tree, target_tree, correspondence_map
    )

    if not root_candidates:
        raise ValueError("No suitable root candidates found")

    # Select the best root candidate, but refuse to reroot at a leaf if possible
    best_root_node = _select_best_non_leaf_candidate(root_candidates)

    # Reroot at the optimal position
    rerooted_tree = reroot_at_node(best_root_node)
    rerooted_tree.invalidate_caches()
    rerooted_tree.build_split_index()

    # ENFORCE: encoding must remain the same as the original target_tree encoding
    original_encoding = getattr(target_tree, "_encoding", None)
    if original_encoding is None:
        raise ValueError(
            "Target tree does not have an encoding to enforce after rerooting."
        )

    # Validate and rebuild tree structure
    return _validate_and_rebuild_tree_structure(rerooted_tree, original_encoding)


def compute_all_to_all_similarity_matrix(
    tree_a: Node, tree_b: Node
) -> Dict[Tuple[Partition, Partition], float]:
    """
    Compute all-to-all similarity matrix between splits of two trees.
    Uses BranchArchitect's optimized to_splits() method instead of manual traversal.

    This pre-computes all pairwise similarities, similar to phylo-io's approach
    of building comprehensive correspondence data structures.

    Returns:
        Dictionary mapping (split_a, split_b) tuples to Jaccard similarity scores
    """
    similarity_matrix = {}

    # Use BranchArchitect's optimized to_splits() method
    splits_a: PartitionSet[Partition] = tree_a.to_splits()
    splits_b: PartitionSet[Partition] = tree_b.to_splits()

    for split_a in splits_a:
        if len(split_a) <= 1:  # Skip trivial splits
            continue
        for split_b in splits_b:
            if len(split_b) <= 1:  # Skip trivial splits
                continue
            similarity: float = _compute_jaccard_similarity_splits(split_a, split_b)
            similarity_matrix[(split_a, split_b)] = similarity

    return similarity_matrix


def _get_split_to_node_mapping(tree: Node) -> Dict[Partition, Node]:
    """
    Create a mapping from split indices to their corresponding nodes.
    This bridges the gap between split-based operations and node-based rerooting.
    """
    # Use the built-in split index from the Node class for efficient mapping
    tree.build_split_index()
    # _split_index is a dict: Partition -> Node
    if tree._split_index is None:
        return {}
    return tree._split_index
