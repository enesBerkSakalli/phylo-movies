"""Core type definitions for phylogenetic analysis."""

from typing import List, Tuple, Any, Dict, TypeAlias, TypedDict, NamedTuple, Optional
from dataclasses import dataclass
from brancharchitect.tree import Node
from brancharchitect.elements.partition import Partition
from numpy._typing._array_like import NDArray

# Type definitions
TreeList: TypeAlias = List[Node]


@dataclass
class PipelineConfig:
    """Configuration for tree interpolation pipeline."""

    enable_rooting: bool = False
    optimization_iterations: int = 10
    bidirectional_optimization: bool = False
    enable_distance_matrix: bool = True
    logger_name: str = __name__


class InterpolationData(NamedTuple):
    """Data from tree pair interpolation."""

    interpolated_trees: List[Node]
    tree_names: List[str]
    tree_pair_solutions: List["TreePairSolution"]


class DistanceMetrics(NamedTuple):
    """Distance metrics between trees."""

    rfd_list: List[float]
    wrfd_list: List[float]
    distance_matrix: NDArray[Any]


class TreePairData(TypedDict):
    """Data for a single tree pair processing."""

    tree1: Node
    tree2: Node
    interpolated: List[Node]
    solution: "TreePairSolution"


class TreePairSolution(TypedDict):
    """Solution data for a single tree pair."""

    # Core lattice algorithm result (CRITICAL - was missing!)
    lattice_edge_solutions: Dict[Partition, List[List[Partition]]]

    # Tree pair information
    tree_indices: Tuple[int, int]  # (start_tree_idx, end_tree_idx)

    # Mappings for atom translation
    mapping_one: Dict[Partition, Partition]  # Mapping from interpolation
    mapping_two: Dict[Partition, Partition]  # Mapping from interpolation

    # Edge sequence for tracking interpolation steps
    s_edge_sequence: List[Optional[Partition]]


class ProcessingResult(TypedDict):
    """Result of tree processing pipeline."""

    # Core results
    interpolated_trees: List[Node]
    tree_names: List[str]
    tree_pair_solutions: List[TreePairSolution]

    # Distance metrics
    rfd_list: List[float]
    wrfd_list: List[float]
    distance_matrix: NDArray[Any]

    # Metadata
    original_tree_count: int
    interpolated_tree_count: int
    processing_time: float
