"""
Tree interpolation module for creating smooth animations between phylogenetic trees.

This module provides the main public API for tree interpolation, creating
intermediate states that allow continuous morphing from one tree topology to another.
"""

from __future__ import annotations

import logging
from typing import List, Optional, Dict, Tuple

from brancharchitect.elements.partition import Partition
from brancharchitect.tree_interpolation.core import (
    calculate_consensus_tree,
    calculate_intermediate_tree,
    create_progressive_consensus_sequence,
)
from brancharchitect.tree import Node
from brancharchitect.tree_interpolation.types import ConsensusResult, TreePairResult

from brancharchitect.tree_interpolation.types import (
    InterpolationTrees,
    LatticeEdgeData,
)
from brancharchitect.tree_interpolation.helpers import (
    create_branch_averaging_progressions,
    generate_tree_names,
    generate_s_edge_tracking,
)

logger: logging.Logger = logging.getLogger(__name__)

__all__: List[str] = [
    "interpolate_tree",
    "interpolate_adjacent_tree_pairs",
    "interpolate_adjacent_blocked_tree_pairs",
]


# Public API
def interpolate_tree(target: Node, reference: Node) -> tuple[Node, Node, Node, Node]:
    """
    Interpolate between two trees to create intermediate and consensus trees.

    Returns a tuple of 4 trees:
    1. Intermediate tree from target (branch lengths averaged toward reference)
    2. Consensus from target (keeping only splits that are also in reference)
    3. Consensus from reference (keeping only splits that are also in target)
    4. Intermediate tree from reference (branch lengths averaged toward target)
    """
    target_splits: Dict[Partition, float] = target.to_weighted_splits()
    reference_splits: Dict[Partition, float] = reference.to_weighted_splits()

    intermediate_from_target: Node = calculate_intermediate_tree(
        target, reference_splits
    )
    intermediate_from_reference = calculate_intermediate_tree(reference, target_splits)

    consensus_from_target: Node = calculate_consensus_tree(
        intermediate_from_target, reference_splits
    )
    consensus_from_reference: Node = calculate_consensus_tree(
        intermediate_from_reference, target_splits
    )

    return (
        intermediate_from_target,
        consensus_from_target,
        consensus_from_reference,
        intermediate_from_reference,
    )


def interpolate_adjacent_tree_pairs(tree_list: List[Node]) -> List[Node]:
    """Interpolate between all adjacent pairs in a list of trees."""
    if len(tree_list) < 2:
        raise ValueError("Need at least 2 trees for interpolation")

    logger.info(f"Interpolating {len(tree_list)} trees with adjacent pairs method")
    results: List[Node] = []
    for i in range(len(tree_list) - 1):
        target = tree_list[i]
        reference = tree_list[i + 1]

        trees = interpolate_tree(target, reference)
        results.append(target)
        results.extend(trees)

    results.append(tree_list[-1])
    return results


def process_tree_pair(target: Node, reference: Node, tree_index: int) -> TreePairResult:
    """Process a single tree pair and return all interpolation results."""
    # Extract split dictionaries
    split_data: Tuple[Dict[Partition, float], Dict[Partition, float]] = (
        target.to_weighted_splits(),
        reference.to_weighted_splits(),
    )

    # Import here to avoid circular import
    from brancharchitect.jumping_taxa.lattice.lattice_solver import (
        iterate_lattice_algorithm,
    )

    lattice_edge_solutions: Dict[Partition, List[List[Partition]]] = (
        iterate_lattice_algorithm(target, reference)
    )
    lattice_edges: List[Partition] = list(lattice_edge_solutions.keys())
    lattice_edge_data = LatticeEdgeData(lattice_edges, lattice_edge_solutions)
    lattice_edge_data.compute_depths(target, reference)

    # Create progressive sequences with averaged branch lengths
    interpolation_trees: InterpolationTrees = create_branch_averaging_progressions(
        target, reference, split_data, lattice_edge_data
    )

    # Generate consensus trees
    consensus_result: ConsensusResult = create_progressive_consensus_sequence(
        target, reference, split_data, lattice_edge_data
    )

    # Collect all trees in order
    all_trees: List[Node] = (
        [target]
        + interpolation_trees.down
        + consensus_result.trees
        + interpolation_trees.up
    )

    # Generate names
    names: List[str] = generate_tree_names(
        tree_index,
        len(interpolation_trees.down),
        len(consensus_result.trees),
        len(interpolation_trees.up),
    )

    # Generate s_edge tracking
    s_edge_tracking: List[Optional[Partition]] = generate_s_edge_tracking(
        lattice_edge_data,
        len(interpolation_trees.down),
        len(consensus_result.trees),
        len(interpolation_trees.up),
    )

    return TreePairResult(
        trees=all_trees,
        names=names,
        mapping_one=consensus_result.mapping_one,
        mapping_two=consensus_result.mapping_two,
        s_edge_tracking=s_edge_tracking,
        lattice_edge_solutions=lattice_edge_solutions,
    )


def interpolate_adjacent_blocked_tree_pairs(
    tree_list: List[Node],
) -> Tuple[
    List[Node],
    List[str],
    List[Dict[Partition, Partition]],
    List[Dict[Partition, Partition]],
    List[Optional[Partition]],
    List[int],
    List[Dict[Partition, List[List[Partition]]]],
]:
    """
    Interpolate adjacent tree pairs with progressive consensus tree ordering.

    For each adjacent pair of trees:
    1. Compute intermediate trees using weighted splits
    2. Find lattice edges using lattice algorithm
    3. Sort lattice edges by average depth in both trees
    4. Create progressively ordered consensus trees

    Returns:
        Tuple of (interpolated_trees, tree_names, mapping_one, mapping_two,
                 s_edge_tracking, s_edge_lengths, lattice_solutions_list)
    """
    if len(tree_list) < 2:
        raise ValueError("Need at least 2 trees for interpolation")

    logger.info(f"Interpolating {len(tree_list)} trees with blocked progressive method")
    results: List[Node] = []
    consecutive_tree_names: List[str] = []
    solution_to_atom_mapping_list_one: List[Dict[Partition, Partition]] = []
    solution_to_atom_mapping_list_two: List[Dict[Partition, Partition]] = []
    all_s_edge_tracking: List[Optional[Partition]] = []
    s_edge_lengths: List[int] = []
    lattice_solutions_list: List[Dict[Partition, List[List[Partition]]]] = []

    for i in range(len(tree_list) - 1):
        target: Node = tree_list[i].deep_copy()
        reference: Node = tree_list[i + 1].deep_copy()
        # Process single tree pair
        pair_result: TreePairResult = process_tree_pair(target, reference, i)

        # Collect results
        results.extend(pair_result.trees)
        consecutive_tree_names.extend(pair_result.names)
        solution_to_atom_mapping_list_one.append(pair_result.mapping_one)
        solution_to_atom_mapping_list_two.append(pair_result.mapping_two)
        all_s_edge_tracking.extend(pair_result.s_edge_tracking)
        s_edge_lengths.append(len(pair_result.s_edge_tracking))
        lattice_solutions_list.append(pair_result.lattice_edge_solutions)

    # Add final tree
    results.append(tree_list[-1])
    consecutive_tree_names.append(f"T{len(tree_list) - 1}")
    all_s_edge_tracking.append(None)  # Final tree has no s_edge applied

    return (
        results,
        consecutive_tree_names,
        solution_to_atom_mapping_list_one,
        solution_to_atom_mapping_list_two,
        all_s_edge_tracking,
        s_edge_lengths,
        lattice_solutions_list,
    )
