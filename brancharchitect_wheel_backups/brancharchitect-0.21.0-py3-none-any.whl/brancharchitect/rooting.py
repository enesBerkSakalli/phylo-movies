# --- Robust rerooting at best matching node (phylo-io style) ---
from typing import Optional, Dict
from collections import deque
from typing import Tuple, List
from brancharchitect.tree import Node  # Import Node for type annotations


def find_best_matching_node(target_partition, root: Node) -> Optional[Node]:
    """
    Returns the node in root whose Partition has the largest overlap with target_partition.
    Uses bitmask operations for efficient set intersection and early termination for perfect matches.
    """
    best_node = None
    best_overlap = 0
    target_size = len(target_partition.indices) if hasattr(target_partition, 'indices') else len(target_partition)
    
    # Get target bitmask for efficient bitwise operations
    if hasattr(target_partition, 'bitmask'):
        target_bitmask = target_partition.bitmask
    else:
        # Fallback for non-Partition objects
        target_indices = set(target_partition.indices) if hasattr(target_partition, 'indices') else set(target_partition)
    
    for node in root.traverse():
        partition_b = node.split_indices
        
        # Use bitmask for efficient overlap calculation if available
        if hasattr(target_partition, 'bitmask') and hasattr(partition_b, 'bitmask'):
            # Count number of set bits in the intersection
            overlap = bin(target_bitmask & partition_b.bitmask).count('1')
        else:
            # Fallback to set intersection
            target_indices = set(target_partition.indices) if hasattr(target_partition, 'indices') else set(target_partition)
            node_indices = set(partition_b.indices) if hasattr(partition_b, 'indices') else set(partition_b)
            overlap = len(target_indices & node_indices)
        
        if overlap > best_overlap:
            best_overlap = overlap
            best_node = node
            
            # Early termination: if we found a perfect match (complete overlap), return immediately
            if overlap == target_size:
                return best_node
    
    return best_node

def reroot_to_best_match(reference_node: Node, target_tree_root: Node) -> Node:
    """
    Reroots the target tree at the node whose clade/partition best matches the reference_node's clade.
    Returns the new root of the rerooted tree.
    """
    target_partition = reference_node.split_indices
    best_node = find_best_matching_node(target_partition, target_tree_root)
    if best_node is None:
        raise ValueError("No matching node found for rerooting.")
    return reroot_at_node(best_node)

def build_correspondence_map(tree_a_root: Node, tree_b_root: Node) -> Dict[Node, Node]:
    """
    Build a correspondence map from each node in tree A to its best matching node in tree B (by clade overlap).
    For leaves, prioritize exact matches (same taxon name).
    Returns a dict: {node_a: best_node_b}
    """
    correspondence_map = {}
    for node_a in tree_a_root.traverse():
        if node_a.is_leaf():
            # For leaves, find exact match by name
            best_node_b = None
            for node_b in tree_b_root.traverse():
                if node_b.is_leaf() and node_b.name == node_a.name:
                    best_node_b = node_b
                    break
            if best_node_b is None:
                # Fallback to overlap-based matching if no exact match
                partition_a = node_a.split_indices
                best_overlap = 0
                for node_b in tree_b_root.traverse():
                    partition_b = node_b.split_indices
                    overlap = len(set(partition_a) & set(partition_b))
                    if overlap > best_overlap:
                        best_overlap = overlap
                        best_node_b = node_b
        else:
            # For internal nodes, use overlap-based matching
            partition_a = node_a.split_indices
            best_node_b = None
            best_overlap = 0
            for node_b in tree_b_root.traverse():
                partition_b = node_b.split_indices
                overlap = len(set(partition_a) & set(partition_b))
                if overlap > best_overlap:
                    best_overlap = overlap
                    best_node_b = node_b
        
        # Fallback: if no best match found, map to the same node if it exists in tree B
        if best_node_b is None and node_a in [n for n in tree_b_root.traverse()]:
            best_node_b = node_a
        
        correspondence_map[node_a] = best_node_b
    return correspondence_map

# --- Robust midpoint rooting implementation ---
def find_farthest_leaves(root: Node) -> Tuple[Node, Node, float]:
    """Find the two leaves in the tree that are farthest apart and return them and their distance."""
    leaves = [n for n in root.traverse() if n.is_leaf()]
    if not leaves:
        raise ValueError("Tree has no leaves")
    start = leaves[0]
    farthest, dist = _bfs_farthest(start)
    other, max_dist = _bfs_farthest(farthest)
    return farthest, other, max_dist


def _bfs_farthest(start: Node) -> Tuple[Node, float]:
    visited = set()
    queue = deque([(start, 0.0)])
    farthest, max_dist = start, 0.0
    while queue:
        node, dist = queue.popleft()
        if node in visited:
            continue
        visited.add(node)
        if node.is_leaf() and dist > max_dist:
            farthest, max_dist = node, dist
        neighbors = []
        if node.parent:
            neighbors.append((node.parent, node.length or 0.0))
        for child in node.children:
            neighbors.append((child, child.length or 0.0))
        for neighbor, edge_len in neighbors:
            if neighbor not in visited:
                queue.append((neighbor, dist + edge_len))
    return farthest, max_dist


def path_between(node1: Node, node2: Node) -> List[Tuple[Node, float]]:
    """Return the path (as list of (node, edge_length)) from node1 to node2."""
    parent = {node1: (None, 0.0)}
    queue = deque([node1])
    found = False
    while queue and not found:
        node = queue.popleft()
        for neighbor, edge_len in _neighbors_with_length(node):
            if neighbor not in parent:
                parent[neighbor] = (node, edge_len)
                queue.append(neighbor)
                if neighbor == node2:
                    found = True
                    break
    path = []
    node = node2
    while node != node1:
        prev, edge_len = parent[node]
        path.append((node, edge_len))
        node = prev
    path.append((node1, 0.0))
    path.reverse()
    return path


def _neighbors_with_length(node: Node):
    if node.parent:
        yield node.parent, node.length or 0.0
    for child in node.children:
        yield child, child.length or 0.0


def midpoint_root(tree: Node) -> Node:
    """
    Return a new tree rooted at the midpoint of the longest path between any two leaves.
    """
    tree = tree.deep_copy()
    L1, L2, max_dist = find_farthest_leaves(tree)
    path = path_between(L1, L2)
    half = max_dist / 2.0
    acc = 0.0
    for i in range(1, len(path)):
        prev_node, _ = path[i - 1]
        node, edge_len = path[i]
        if acc + edge_len == half:
            return reroot_at_node(node)
        elif acc + edge_len > half:
            dist_from_prev = half - acc
            dist_from_next = edge_len - dist_from_prev
            return insert_root_on_edge(prev_node, node, dist_from_prev, dist_from_next)
        acc += edge_len
    raise RuntimeError("Failed to find midpoint on path")


def reroot_at_node(node: Node) -> Node:
    return _flip_upward(node)


def insert_root_on_edge(node1: Node, node2: Node, len1: float, len2: float) -> Node:
    # Disconnect node2 from node1
    if node2.parent == node1:
        node1.children.remove(node2)
        node2.parent = None
    elif node1.parent == node2:
        node2.children.remove(node1)
        node1.parent = None
    else:
        raise ValueError("Nodes are not directly connected")
    root = type(node1)(name="MidpointRoot", length=None)
    node1.length = len1
    node2.length = len2
    root.children = [node1, node2]
    node1.parent = root
    node2.parent = root
    return root


def _flip_upward(new_root: Node) -> Node:
    current = new_root
    prev_node = None
    prev_length = 0.0
    while current.parent:
        parent = current.parent
        old_length = current.length or 0.0
        if parent in current.children:
            current.children.remove(parent)
        if current in parent.children:
            parent.children.remove(current)
        current.parent = prev_node
        current.length = prev_length
        if prev_node is not None:
            prev_node.children.append(current)
        prev_node = current
        prev_length = old_length
        current = parent
    if current is not None:
        current.parent = prev_node
        current.length = prev_length
        if prev_node is not None and current not in prev_node.children:
            prev_node.children.append(current)
    return new_root

def find_best_matching_node_jaccard(target_partition, root: Node) -> Optional[Node]:
    """
    Returns the node in root whose Partition has the highest Jaccard similarity with target_partition.
    Jaccard similarity = |intersection| / |union|, inspired by phylo-io's approach.
    """
    best_node = None
    best_jaccard = 0.0
    
    # Get target bitmask for efficient bitwise operations
    if hasattr(target_partition, 'bitmask'):
        target_bitmask = target_partition.bitmask
    else:
        target_indices = set(target_partition.indices) if hasattr(target_partition, 'indices') else set(target_partition)
    
    for node in root.traverse():
        partition_b = node.split_indices
        
        # Use bitmask for efficient Jaccard calculation if available
        if hasattr(target_partition, 'bitmask') and hasattr(partition_b, 'bitmask'):
            # Bitwise operations for intersection and union
            intersection_bits = target_bitmask & partition_b.bitmask
            union_bits = target_bitmask | partition_b.bitmask
            
            intersection_count = bin(intersection_bits).count('1')
            union_count = bin(union_bits).count('1')
            
            jaccard = intersection_count / union_count if union_count > 0 else 0.0
        else:
            # Fallback to set operations
            target_indices = set(target_partition.indices) if hasattr(target_partition, 'indices') else set(target_partition)
            node_indices = set(partition_b.indices) if hasattr(partition_b, 'indices') else set(partition_b)
            
            intersection = len(target_indices & node_indices)
            union = len(target_indices | node_indices)
            
            jaccard = intersection / union if union > 0 else 0.0
        
        if jaccard > best_jaccard:
            best_jaccard = jaccard
            best_node = node
            
            # Early termination for perfect Jaccard similarity
            if jaccard == 1.0:
                return best_node
    
    return best_node

def reroot_to_best_match_jaccard(reference_node: Node, target_tree_root: Node) -> Node:
    """
    Reroots the target tree at the node whose clade has the highest Jaccard similarity 
    with the reference_node's clade. Uses phylo-io-inspired similarity metric.
    Returns the new root of the rerooted tree.
    """
    target_partition = reference_node.split_indices
    best_node = find_best_matching_node_jaccard(target_partition, target_tree_root)
    if best_node is None:
        raise ValueError("No matching node found for rerooting.")
    return reroot_at_node(best_node)
