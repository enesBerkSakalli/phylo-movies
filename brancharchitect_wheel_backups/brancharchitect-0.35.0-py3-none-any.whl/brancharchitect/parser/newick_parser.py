import math
import ast

from typing import Optional, Union, List, Dict, Tuple, Any
from brancharchitect.tree import Node


# ===================================================================
# 1. METADATA PROCESSING FUNCTIONS
# ===================================================================


def split_token(token: str) -> Tuple[str, Any]:
    """
    Split a metadata token into name and value parts.

    Args:
        token: String containing a name-value pair separated by "=" or ":"

    Returns:
        A tuple containing (name, value) where value is parsed using ast.literal_eval

    Raises:
        ValueError: If the token doesn't contain either "=" or ":" as a separator
    """
    name: str = ""
    value_str: str = ""
    if "=" in token:
        name = token.split("=")[0]
        value_str = token.split("=")[1]
    elif ":" in token:
        name = token.split(":")[0]
        value_str = token.split(":")[1]
    else:
        raise ValueError(f'Metadata Token has neither "=" nor ":", it is {token}')
    value: Any = ast.literal_eval(value_str)
    return (name, value)


def parse_metadata(data: str) -> Dict[str, Any]:
    """
    Parse a metadata string into a dictionary.

    Args:
        data: String containing metadata in format "key1=value1,key2=value2"

    Returns:
        Dictionary mapping keys to their parsed values
    """
    token_strings = data.split(",")
    token_pairs = [split_token(token) for token in token_strings]
    return dict(token_pairs)


def flush_meta_buffer(meta_buffer: List[str], stack: List[Node]) -> None:
    """
    Process the accumulated metadata buffer and apply it to the current node.

    Args:
        meta_buffer: A list of characters containing metadata information
        stack: The current stack of nodes being processed

    Returns:
        None - modifies the stack and meta_buffer in place
    """
    buffer_value = "".join(meta_buffer)
    meta_dict = parse_metadata(buffer_value)
    stack[-1].values = meta_dict
    meta_buffer.clear()


# ===================================================================
# 2. BUFFER PROCESSING FUNCTIONS
# ===================================================================


def flush_character_buffer(buffer: List[str], stack: List[Node]) -> None:
    """
    Process the character buffer and assign the name to the current node.

    Args:
        buffer: List of characters to join as the node name
        stack: The current stack of nodes being processed

    Returns:
        None - modifies the stack and buffer in place
    """
    buffer_value = "".join(buffer)
    stack[-1].name = buffer_value
    buffer.clear()


def flush_length_buffer(buffer: List[str], stack: List[Node]) -> None:
    """
    Process the length buffer and assign the branch length to the current node.

    Args:
        buffer: List of characters to join and parse as branch length
        stack: The current stack of nodes being processed

    Returns:
        None - modifies the stack and buffer in place

    Raises:
        ValueError: If the buffer content cannot be parsed as a valid float
    """
    buffer_value = "".join(buffer).strip()
    try:
        # Convert buffer_value to a float
        parsed_number = float(buffer_value)
        # Handle special float values if needed
        if math.isinf(parsed_number):
            raise ValueError("Parsed an invalid length inf")
        if math.isnan(parsed_number):
            raise ValueError("Parsed an invalid length NaN")
        stack[-1].length = parsed_number
    except ValueError as e:
        raise ValueError(f"Failed to parse '{buffer_value}' as a float: {str(e)}")
    buffer.clear()


def flush_buffer(buffer: List[str], stack: List[Node], mode: str) -> None:
    """
    Process the accumulated buffer based on the current parsing mode.

    Args:
        buffer: List of characters accumulated during parsing
        stack: The current stack of nodes being processed
        mode: Current parsing mode ("character_reader" or "length_reader")

    Returns:
        None - modifies the stack and buffer in place
    """
    if mode == "character_reader":
        flush_character_buffer(buffer, stack)
    elif mode == "length_reader":
        flush_length_buffer(buffer, stack)


# ===================================================================
# 3. NODE STACK MANAGEMENT FUNCTIONS
# ===================================================================


def init_nodestack() -> List[Node]:
    """
    Initialize the node stack with a dummy root node.

    Returns:
        List containing a single root node
    """
    root = Node(name="root", length=1, depth=0)
    return [root]


def create_new_node(
    stack: List[Node], buffer: List[str], mode: str, default_length: float
) -> Tuple[List[Node], List[str], str]:
    """
    Create a new node and add it to the tree structure.

    Args:
        stack: The current stack of nodes being processed
        buffer: The current character buffer
        mode: The current parsing mode
        default_length: The default branch length to use for new nodes

    Returns:
        A tuple of (stack, buffer, mode) with the new node added to the stack
    """
    parent = stack[-1]
    new_node = Node(
        length=default_length,
        depth=(parent.depth + 1 if parent.depth is not None else 1),
    )

    # Add new_node to the current top node's children
    parent.children.append(new_node)

    # Set the child's parent pointer, making the tree pointer-based
    new_node.parent = parent

    stack.append(new_node)
    return stack, buffer, mode


def close_node(
    stack: List[Node], buffer: List[str], mode: str
) -> Tuple[List[Node], List[str], str]:
    """
    Close the current node by removing it from the stack.

    Args:
        stack: The current stack of nodes being processed
        buffer: The current character buffer
        mode: The current parsing mode

    Returns:
        A tuple of (stack, buffer, mode) with the node popped from the stack
    """
    stack.pop()
    return stack, buffer, mode


# ===================================================================
# 4. CORE PARSING FUNCTIONS
# ===================================================================


def _parse_newick(tokens: str, default_length: float) -> List[Node]:
    """
    Return a list of top-level Node trees from the token string.

    This is the low-level parsing function that processes character by character.

    Args:
        tokens: Raw Newick format string
        default_length: Default branch length for nodes without explicit lengths

    Returns:
        List of parsed Node trees
    """
    trees: List[Node] = []
    buffer: List[str] = []
    meta_buffer: List[str] = []
    mode: str = "character_reader"
    node_stack: List[Node] = init_nodestack()

    for index in range(len(tokens)):
        char = tokens[index]

        if char == "\n":
            continue

        elif char == "(":
            # Start a new internal node
            if len(node_stack) == 0:
                node_stack = init_nodestack()
            node_stack, buffer, mode = create_new_node(
                node_stack, buffer, mode, default_length
            )
            mode = "character_reader"

        elif char == ")":
            flush_buffer(buffer, node_stack, mode)
            # When closing a node, do not pop the root dummy node
            if len(node_stack) > 1:
                close_node(node_stack, buffer, mode)
            mode = "character_reader"

        elif char == "," and mode in ["character_reader", "length_reader"]:
            flush_buffer(buffer, node_stack, mode)
            # Only close node if not at the root dummy node
            if len(node_stack) > 1:
                close_node(node_stack, buffer, mode)
            node_stack, buffer, mode = create_new_node(
                node_stack, buffer, mode, default_length
            )
            mode = "character_reader"

        elif char == ":":
            flush_buffer(buffer, node_stack, mode)
            mode = "length_reader"

        elif char == "[":  # metadata
            mode = "metadata_reader"

        elif char == "]" and mode == "metadata_reader":
            flush_meta_buffer(meta_buffer, node_stack)
            mode = "character_reader"

        elif char == ";":
            if mode == "metadata_reader":
                meta_buffer.append(char)
            else:
                flush_buffer(buffer, node_stack, mode)
                # Only pop the root dummy node at the very end
                while len(node_stack) > 1:
                    close_node(node_stack, buffer, mode)
                assert len(node_stack) == 1
                trees.append(node_stack.pop())

        elif mode == "metadata_reader":
            meta_buffer.append(char)
        else:
            buffer.append(char)

    if len(node_stack) > 0:
        flush_buffer(buffer, node_stack, mode)
        while len(node_stack) > 1:
            close_node(node_stack, buffer, mode)
        assert len(node_stack) == 1
        trees.append(node_stack.pop())

    return trees


# ===================================================================
# 5. PUBLIC API FUNCTIONS
# ===================================================================


def parse_newick(
    tokens: str,
    order: Optional[List[str]] = None,
    encoding: Optional[Dict[str, int]] = None,
    default_length: float = 1.0,
    force_list: bool = False,
) -> Union[Node, List[Node]]:
    """
    Parse a Newick string into a tree or list of trees.

    This is the main public API function for parsing Newick format strings.
    It handles post-processing such as setting up order, encoding, and tree properties.

    Args:
        tokens: Newick format string
        order: Optional order for taxa names
        encoding: Optional encoding mapping for taxa names
        default_length: Default branch length for nodes without explicit lengths
        force_list: Always return a list even for single trees

    Returns:
        Single Node or list of Nodes representing parsed tree(s)
    """
    trees: List[Node] = _parse_newick(tokens, default_length=default_length)

    if order is None:
        # If user didn't supply an order, gather from first tree
        order = list(trees[0].get_current_order())

    if encoding is None:
        encoding = {name: idx for idx, name in enumerate(order)}

    # Post-process trees with metadata and ordering
    for idx, tree in enumerate(trees):
        tree.list_index = idx
        tree.taxa_encoding = encoding
        tree._order = order
        tree._initialize_split_indices(encoding)
        tree.fix_child_order()

    if len(trees) == 1 and not force_list:
        return trees[0]
    return trees
