from typing import List, Dict, Tuple, Optional, Union, Any
from dataclasses import dataclass
import tempfile
import os


# Configuration dataclasses to reduce parameter redundancy
@dataclass
class StylingConfig:
    """Configuration for styling options."""

    font_family: str = "Monospace"
    font_size: str = "18"
    leaf_font_size: Optional[str] = None
    stroke_color: str = "#000"
    general_stroke_width: float = 2.0


@dataclass
class HighlightConfig:
    """Configuration for branch highlighting."""

    branches: Optional[Any] = None
    width: Union[float, List[float]] = 10.0
    colors: Optional[Any] = None


@dataclass
class BezierConfig:
    """Configuration for Bezier curve styling."""

    min_width: float = 4.0
    max_width: float = 14.0
    cmap_name: str = "viridis"
    colors: Optional[Any] = None
    stroke_widths: Optional[Any] = None


@dataclass
class PlotConfig:
    """Configuration for distance plots."""

    title: Optional[str] = None
    xlabel: Optional[str] = None
    ylabel: Optional[str] = None
    plot_type: str = "both"  # "both", "rf", "circular"


@dataclass
class LayoutConfig:
    """Configuration for layout and dimensions."""

    size: int = 240
    margin: int = 50
    label_offset: int = 18
    y_steps: int = 7
    top_margin: int = 210
    bottom_margin: int = 36


# Configuration factory functions for common use cases
def create_paper_styling() -> StylingConfig:
    """Create styling configuration optimized for scientific papers."""
    return StylingConfig(
        font_family="Arial",
        font_size="14",
        stroke_color="#333",
        general_stroke_width=1.5,
    )


def create_presentation_styling() -> StylingConfig:
    """Create styling configuration optimized for presentations."""
    return StylingConfig(
        font_family="Arial",
        font_size="20",
        stroke_color="#000",
        general_stroke_width=2.5,
    )


def create_web_styling() -> StylingConfig:
    """Create styling configuration optimized for web display."""
    return StylingConfig(
        font_family="system-ui",
        font_size="16",
        stroke_color="#444",
        general_stroke_width=2.0,
    )


def create_compact_layout() -> LayoutConfig:
    """Create layout configuration for compact displays."""
    return LayoutConfig(size=180, margin=30, label_offset=12, y_steps=5)


def create_large_layout() -> LayoutConfig:
    """Create layout configuration for large displays."""
    return LayoutConfig(size=320, margin=70, label_offset=24, y_steps=9)


# --- Section 1: Distance Computation Functions ---
def compute_rf_distances(trees: List[Any]) -> List[float]:
    from brancharchitect.distances.distances import robinson_foulds_distance

    return [
        robinson_foulds_distance(trees[i], trees[i + 1]) for i in range(len(trees) - 1)
    ]


def per_taxa_circular_distances(tree1: Any, tree2: Any) -> List[float]:
    # Handle cases where trees don't have get_current_order method
    if not hasattr(tree1, 'get_current_order') or not hasattr(tree2, 'get_current_order'):
        return []
    
    order1 = tree1.get_current_order()
    order2 = tree2.get_current_order()
    
    # Handle empty orders
    if not order1 or not order2:
        return []
    
    n = len(order1)
    
    # Handle single taxon case
    if n <= 1:
        return [0.0] * n
    
    idx1 = {name: i for i, name in enumerate(order1)}
    idx2 = {name: i for i, name in enumerate(order2)}
    dists: List[float] = []
    
    for name in order1:
        if name not in idx2:
            # Taxa not present in second tree - assign max distance
            dists.append(1.0)
        else:
            diff = abs(idx1[name] - idx2[name])
            d = min(diff, n - diff) / (n // 2) if n > 1 else 0.0
            dists.append(d)
    return dists


def compute_per_pair_taxa_dists(trees: List[Any]) -> List[List[float]]:
    if len(trees) < 2:
        return []
    
    num_pairs = len(trees) - 1
    return [
        per_taxa_circular_distances(trees[i], trees[i + 1]) for i in range(num_pairs)
    ]


def compute_bezier_colors_and_widths(
    per_pair_taxa_dists: List[List[float]],
    norm: Any,
    subtle_color: Any,
    min_width: float,
    max_width: float,
) -> Tuple[List[List[str]], List[List[float]]]:
    bezier_colors_per_pair = [
        [subtle_color(norm(d)) for d in pair] for pair in per_pair_taxa_dists
    ]
    bezier_stroke_widths_per_pair = [
        [min_width + (max_width - min_width) * norm(d) for d in pair]
        for pair in per_pair_taxa_dists
    ]
    return bezier_colors_per_pair, bezier_stroke_widths_per_pair


def _normalize_highlight_branches(highlight_branches: Any, n: int) -> List[Any]:
    if highlight_branches is None or (
        isinstance(highlight_branches, list)
        and (
            len(highlight_branches) == 0
            or not isinstance(highlight_branches[0], (list, tuple))
        )
    ):
        return [highlight_branches] * n
    return highlight_branches


def _normalize_highlight_width(
    highlight_width: Union[int, float, List[Union[int, float]]], n: int
) -> List[Union[int, float]]:
    if isinstance(highlight_width, (int, float)):
        return [highlight_width] * n
    return highlight_width


# --- Section 2: Styling and Utility Functions ---
def _apply_matplotlib_styling(
    fig_or_ax: Any,
    title: Optional[str] = None,
    xlabel: Optional[str] = None,
    ylabel: Optional[str] = None,
    ylabel_color: str = "tab:blue",
) -> None:
    """Apply common matplotlib styling to figure or axes."""
    if hasattr(fig_or_ax, "subplots_adjust"):  # It's a figure
        fig = fig_or_ax
        axs = fig.get_axes()
        if title:
            fig.suptitle(title, fontsize=28, fontweight="bold", y=1.03)
        for ax in axs:
            _style_single_axis(ax)
            if xlabel and ax == axs[-1]:  # Apply xlabel to bottom axis
                ax.set_xlabel(xlabel, fontsize=22, fontweight="bold")
            if ylabel and ylabel_color:
                ax.set_ylabel(
                    ylabel,
                    fontsize=20,
                    color=ylabel_color,
                    labelpad=2,
                    fontweight="bold",
                )
    else:  # It's a single axis
        ax = fig_or_ax
        _style_single_axis(ax)
        if title:
            ax.figure.suptitle(title, fontsize=28, fontweight="bold", y=1.03)
        if xlabel:
            ax.set_xlabel(xlabel, fontsize=22, fontweight="bold")
        if ylabel:
            ax.set_ylabel(
                ylabel, fontsize=20, color=ylabel_color, labelpad=2, fontweight="bold"
            )


def _style_single_axis(ax: Any) -> None:
    """Apply common styling to a single axis."""
    ax.tick_params(axis="both", labelsize=16)
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontweight("bold")
    leg = ax.get_legend()
    if leg:
        for text in leg.get_texts():
            text.set_fontsize(18)
            text.set_fontweight("bold")


def _combine_images(tree_img: Any, dist_img: Any) -> Any:
    """Combine tree and distance plot images vertically."""
    import PIL.Image

    w = max(tree_img.width, dist_img.width)
    tree_img = tree_img.resize((w, tree_img.height), PIL.Image.Resampling.LANCZOS)
    dist_img = dist_img.resize((w, dist_img.height), PIL.Image.Resampling.LANCZOS)
    total_height = tree_img.height + dist_img.height
    combined = PIL.Image.new("RGBA", (w, total_height), (255, 255, 255, 255))
    combined.paste(tree_img, (0, 0))
    combined.paste(dist_img, (0, tree_img.height))
    return combined


def _setup_common_axis_style(
    ax: Any, color: str, n: int, ylabel_text: str, show_xticks: bool = False
) -> None:
    """Apply common axis styling for distance plots."""
    import numpy as np

    ax.tick_params(axis="y", labelcolor=color, length=0, labelsize=14)
    ax.set_xlim(0, n - 1)
    if show_xticks:
        ax.set_xticks(np.arange(n))
        ax.set_xticklabels(
            [f"T{i + 1}" for i in range(n)], fontsize=16, fontweight="bold"
        )
    else:
        ax.set_xticks([])
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(color)
    ax.spines["bottom"].set_color("#888" if show_xticks else color)
    if not show_xticks:
        ax.spines["bottom"].set_visible(False)
    ax.grid(axis="y", linestyle=":", alpha=0.22)
    ax.set_ylabel(ylabel_text, fontsize=18, color=color, labelpad=2, fontweight="bold")


# --- Section 3: SVG Construction Functions ---
def _make_svg_element(
    trees: List[Any],
    size: int,
    margin: int,
    bezier_colors: List[List[str]],
    bezier_stroke_widths: List[List[float]],
    label_offset: int,
    highlight_branches: Any,
    highlight_width: Union[float, List[float]],
    highlight_colors: Optional[Any] = None,
    font_family: str = "Monospace",
    font_size: str = "12",
    stroke_color: str = "#000",
    leaf_font_size: Optional[str] = None,
) -> Any:
    from brancharchitect.plot.tree_plot import plot_circular_trees_in_a_row

    return plot_circular_trees_in_a_row(
        trees,
        size=size,
        margin=margin,
        bezier_colors=bezier_colors,
        bezier_stroke_widths=bezier_stroke_widths,
        label_offset=label_offset,
        highlight_branches=highlight_branches,
        highlight_width=highlight_width,
        highlight_colors=highlight_colors,
        font_family=font_family,
        font_size=font_size,
        stroke_color=stroke_color,
        leaf_font_size=leaf_font_size,
    )


def _get_svg_size(svg_element: Any, size: int, n: int) -> Tuple[int, int]:
    width = int(svg_element.attrib.get("width", size * n))
    height = int(svg_element.attrib.get("height", size))
    return width, height


def _add_svg_background(
    svg_element: Any,
    width: int,
    height: int,
    top_margin: int = 38,
    bottom_margin: int = 0,
) -> None:
    import xml.etree.ElementTree as ET

    background = ET.Element(
        "rect",
        {
            "x": "0",
            "y": "0",
            "width": str(width + 100),
            "height": str(height + top_margin + bottom_margin + 100),
            "fill": "#fff",
        },
    )
    svg_element.insert(0, background)


def _make_and_style_svg_element(
    trees: List[Any],
    size: int,
    margin: int,
    bezier_colors_per_pair: List[List[str]],
    bezier_stroke_widths_per_pair: List[List[float]],
    label_offset: int,
    highlight_branches_list: List[Any],
    highlight_width_list: List[Union[int, float]],
    highlight_colors_list: List[Dict[Any, Any]],
    y_steps: int,
    top_margin: int = 190,
    font_family: str = "Monospace",
    font_size: str = "12",
    stroke_color: str = "#000",
    leaf_font_size: Optional[str] = None,
) -> Tuple[Any, int, int]:
    svg_element = _make_svg_element(
        trees,
        size,
        margin,
        bezier_colors_per_pair,
        bezier_stroke_widths_per_pair,
        label_offset,
        highlight_branches_list,
        highlight_width_list,
        highlight_colors_list,
        font_family=font_family,
        font_size=font_size,
        stroke_color=stroke_color,
        leaf_font_size=leaf_font_size,
    )
    width, height = _get_svg_size(svg_element, size, len(trees))
    _add_svg_background(
        svg_element, width, height, top_margin=top_margin, bottom_margin=0
    )
    _add_svg_gridlines(svg_element, width, height, y_steps)
    return svg_element, width, height


def _add_svg_gridlines(svg_element: Any, width: int, height: int, y_steps: int) -> None:
    from brancharchitect.plot.tree_plot import add_svg_gridlines

    add_svg_gridlines(svg_element, width, height, y_steps=y_steps)


# --- Section 4: Distance Plotting Functions ---
def _add_distance_annotation(
    ax: Any, total_circular_distance: float, bottom_margin: int, height: int
) -> None:
    """Add total circular distance annotation to axis."""
    ax.annotate(
        f"Total circular distance: {total_circular_distance:.2f}",
        xy=(1, -0.32 - (bottom_margin / height if bottom_margin else 0)),
        xycoords="axes fraction",
        ha="right",
        va="top",
        fontsize=22,
        color="tab:blue",
        fontweight="bold",
        bbox=dict(
            boxstyle="round,pad=0.3", fc="#f8fafd", ec="#b0c4de", lw=2, alpha=0.92
        ),
    )


def _make_distance_plot(
    trees: List[Any],
    width: int,
    height: int,
    title: Optional[str] = None,
    xlabel: Optional[str] = None,
    ylabel: Optional[str] = None,
    bottom_margin: int = 0,
    distance_plot_type: str = "both",
) -> Any:
    import matplotlib.pyplot as plt
    import numpy as np

    rf_dists = compute_rf_distances(trees)
    circ_dists = [np.mean(pair) for pair in compute_per_pair_taxa_dists(trees)]
    circ_sums = [np.sum(pair) for pair in compute_per_pair_taxa_dists(trees)]
    total_circular_distance = sum(circ_sums)
    x = np.arange(0.5, len(trees) - 0.5, 1)

    if distance_plot_type == "both":
        fig, axs = plt.subplots(
            2,
            1,
            figsize=(width / 80, 3.2 + bottom_margin / 80),
            sharex=True,
            gridspec_kw={"height_ratios": [1, 1], "hspace": 0.18},
        )
        _plot_rf(axs[0], x, rf_dists, len(trees))
        _plot_circ(axs[1], x, circ_dists, len(trees))
        fig.subplots_adjust(
            bottom=0.22 + (bottom_margin / height if bottom_margin else 0)
        )
        _add_distance_annotation(axs[1], total_circular_distance, bottom_margin, height)
        _apply_matplotlib_styling(fig, title, xlabel, ylabel, "tab:blue")
        plt.tight_layout(pad=0.22)
        return fig
    elif distance_plot_type == "rf":
        fig, ax = plt.subplots(1, 1, figsize=(width / 80, 1.6 + bottom_margin / 80))
        _plot_rf(ax, x, rf_dists, len(trees))
        _apply_matplotlib_styling(ax, title, xlabel, ylabel, "tab:red")
        plt.tight_layout(pad=0.22)
        return fig
    elif distance_plot_type == "circular":
        fig, ax = plt.subplots(1, 1, figsize=(width / 80, 1.6 + bottom_margin / 80))
        _plot_circ(ax, x, circ_dists, len(trees))
        _add_distance_annotation(ax, total_circular_distance, bottom_margin, height)
        _apply_matplotlib_styling(ax, title, xlabel, ylabel, "tab:blue")
        plt.tight_layout(pad=0.22)
        return fig
    else:
        raise ValueError(
            f"Invalid distance_plot_type: {distance_plot_type}. Use 'both', 'rf', or 'circular'."
        )


def _plot_rf(ax: Any, x: Any, rf_dists: List[float], n: int) -> None:
    ax.plot(
        x,
        rf_dists,
        color="tab:red",
        lw=2.2,
        marker="o",
        markersize=9,
        label="Robinson-Foulds",
    )
    _setup_common_axis_style(ax, "tab:red", n, "RF", show_xticks=False)
    ax.legend(loc="upper right", fontsize=18, frameon=False)


def _plot_circ(ax: Any, x: Any, circ_dists: Any, n: int) -> None:
    ax.plot(
        x,
        circ_dists,
        color="tab:blue",
        lw=2.2,
        marker="o",
        markersize=9,
        label="Circular (mean)",
    )
    _setup_common_axis_style(ax, "tab:blue", n, "Circular", show_xticks=True)
    ax.legend(loc="upper right", fontsize=18, frameon=False)


# --- Section 5: Image Processing and Output ---
def _combine_and_display(
    svg_string: str, fig: Any, save_format: str, output_path: Optional[str] = None
) -> None:
    from IPython.display import Image, display
    import cairosvg  # type: ignore
    import PIL.Image

    def _save_and_combine_images(
        tmpdir: str, svg_string: str, fig: Any, output_path: str
    ) -> Any:
        """Helper to save SVG as PNG, save matplotlib fig, and combine them."""
        svg_path = os.path.join(tmpdir, "trees.svg")
        tree_png_path = os.path.join(tmpdir, "trees.png")
        dist_png_path = os.path.join(tmpdir, "dist.png")

        with open(svg_path, "w") as f:
            f.write(svg_string)
        cairosvg.svg2png(url=svg_path, write_to=tree_png_path)
        fig.savefig(dist_png_path, bbox_inches="tight", dpi=100)

        tree_img = PIL.Image.open(tree_png_path)
        dist_img = PIL.Image.open(dist_png_path)
        combined = _combine_images(tree_img, dist_img)
        combined.save(output_path)
        return combined

    if output_path is not None:
        tmpdir = os.path.dirname(output_path)
        os.makedirs(tmpdir, exist_ok=True)
        if output_path.lower().endswith(".pdf"):
            cairosvg.svg2pdf(
                bytestring=svg_string.encode("utf-8"), write_to=output_path
            )
        else:
            _save_and_combine_images(tmpdir, svg_string, fig, output_path)
            display(Image(filename=output_path))
    else:
        with tempfile.TemporaryDirectory() as tmpdir:
            img_path = os.path.join(tmpdir, f"combined.{save_format}")
            _save_and_combine_images(tmpdir, svg_string, fig, img_path)
            display(Image(filename=img_path))


# --- Section 6: Main API Functions ---


def plot_tree_row_with_configs(
    trees: List[Any],
    styling: Optional[StylingConfig] = None,
    highlight: Optional[HighlightConfig] = None,
    bezier: Optional[BezierConfig] = None,
    distance_plot: Optional[PlotConfig] = None,
    layout: Optional[LayoutConfig] = None,
    output_path: Optional[str] = None,
    svg_output_path: Optional[str] = None,
    save_format: str = "png",
    which_plot: str = "both",
    ignore_branch_lengths: bool = False,
    glow: bool = True,
) -> None:
    """
    Improved API with configuration objects to reduce parameter redundancy.

    This function replaces the 47-parameter version with a cleaner interface
    using configuration dataclasses. All styling, highlighting, bezier, and
    layout options are grouped into logical configuration objects.

    Args:
        trees: List of tree objects to plot
        styling: Styling configuration (fonts, colors, stroke width)
        highlight: Branch highlighting configuration
        bezier: Bezier curve styling configuration
        distance_plot: Distance plot configuration
        layout: Layout and dimensions configuration
        output_path: Path to save combined output
        svg_output_path: Path to save SVG output
        save_format: Output format for images
        which_plot: What to plot ("tree", "distance", "both")
        ignore_branch_lengths: Whether to ignore branch lengths
        glow: Whether to apply glow effect
    """
    # Use default configs if None provided
    styling = styling or StylingConfig()
    highlight = highlight or HighlightConfig()
    bezier = bezier or BezierConfig()
    distance_plot = distance_plot or PlotConfig()
    layout = layout or LayoutConfig()

    # Call the original function with expanded parameters
    # This maintains backward compatibility while providing a cleaner interface
    return plot_tree_row_with_beziers_and_distances(
        trees=trees,
        size=layout.size,
        margin=layout.margin,
        label_offset=layout.label_offset,
        y_steps=layout.y_steps,
        min_width=bezier.min_width,
        max_width=bezier.max_width,
        cmap_name=bezier.cmap_name,
        save_format=save_format,
        highlight_branches=highlight.branches,
        highlight_width=highlight.width,
        highlight_colors=highlight.colors,
        distance_plot_title=distance_plot.title,
        distance_plot_xlabel=distance_plot.xlabel,
        distance_plot_ylabel=distance_plot.ylabel,
        output_path=output_path,
        svg_output_path=svg_output_path,
        ignore_branch_lengths=ignore_branch_lengths,
        font_family=styling.font_family,
        font_size=styling.font_size,
        leaf_font_size=styling.leaf_font_size,
        stroke_color=styling.stroke_color,
        bezier_colors=bezier.colors,
        bezier_stroke_widths=bezier.stroke_widths,
        glow=glow,
        which_plot=which_plot,
        general_stroke_width=styling.general_stroke_width,
        distance_plot_type=distance_plot.plot_type,
    )


# Example usage with the new configuration-based API:
"""
# Before: 47 parameters
plot_tree_row_with_beziers_and_distances(
    trees, size=240, margin=50, label_offset=18, y_steps=7,
    min_width=4.0, max_width=14.0, cmap_name="viridis",
    save_format="png", highlight_branches=None, highlight_width=10.0,
    highlight_colors=None, distance_plot_title="Tree Comparison",
    distance_plot_xlabel="Tree Index", distance_plot_ylabel="Distance",
    output_path=None, svg_output_path=None, ignore_branch_lengths=False,
    font_family="Monospace", font_size="18", leaf_font_size=None,
    stroke_color="#000", bezier_colors=None, bezier_stroke_widths=None,
    glow=True, which_plot="both", general_stroke_width=2.0,
    distance_plot_type="both"
)

# After: 12 parameters with configuration objects
plot_tree_row_with_configs(
    trees=trees,
    styling=create_paper_styling(),
    layout=create_compact_layout(),
    distance_plot=PlotConfig(
        title="Tree Comparison",
        xlabel="Tree Index",
        ylabel="Distance"
    ),
    output_path="output.png"
)

# Or with custom configurations:
custom_styling = StylingConfig(
    font_family="Arial",
    font_size="16",
    stroke_color="#333"
)

custom_highlight = HighlightConfig(
    branches=["branch1", "branch2"],
    width=8.0,
    colors={"branch1": "red", "branch2": "blue"}
)

plot_tree_row_with_configs(
    trees=trees,
    styling=custom_styling,
    highlight=custom_highlight,
    output_path="highlighted_trees.png"
)
"""


def plot_tree_row_with_beziers_and_distances(
    trees: List[Any],
    size: int = 240,
    margin: int = 50,
    label_offset: int = 18,
    y_steps: int = 7,
    min_width: float = 4.0,
    max_width: float = 14.0,
    cmap_name: str = "viridis",
    save_format: str = "png",
    highlight_branches: Optional[Any] = None,
    highlight_width: float = 10.0,
    highlight_colors: Optional[Any] = None,
    distance_plot_title: Optional[str] = None,
    distance_plot_xlabel: Optional[str] = None,
    distance_plot_ylabel: Optional[str] = None,
    output_path: Optional[str] = None,
    svg_output_path: Optional[str] = None,
    ignore_branch_lengths: bool = False,
    font_family: str = "Monospace",
    font_size: str = "18",
    leaf_font_size: Optional[str] = None,
    stroke_color: str = "#000",
    bezier_colors: Optional[Any] = None,
    bezier_stroke_widths: Optional[Any] = None,
    glow: bool = True,
    which_plot: str = "both",
    general_stroke_width: float = 2.0,
    distance_plot_type: str = "both",
) -> None:
    """
    Main API to plot a row of circular trees with Bezier connections and/or distance plots.
    Args:
        which_plot: 'tree' (only tree row), 'distance' (only distance plot), 'both' (default, both combined)
    """
    import matplotlib.pyplot as plt
    import xml.etree.ElementTree as ET
    import cairosvg  # type: ignore
    from IPython.display import Image, display

    n = len(trees)
    highlight_branches_list = _normalize_highlight_branches(highlight_branches, n)
    highlight_width_list = _normalize_highlight_width(highlight_width, n)
    highlight_colors_list = _normalize_highlight_colors(highlight_colors, n)
    bezier_colors_per_pair, bezier_stroke_widths_per_pair = (
        _get_bezier_colors_and_widths(trees, min_width, max_width, cmap_name)
    )
    bottom_margin = 36
    effective_leaf_font_size = (
        str(leaf_font_size) if leaf_font_size is not None else font_size
    )
    svg_element, width, height = _make_and_style_svg_element(
        trees,
        size,
        margin,
        bezier_colors_per_pair,
        bezier_stroke_widths_per_pair,
        label_offset,
        highlight_branches_list,
        highlight_width_list,
        highlight_colors_list,
        y_steps,
        top_margin=210,
        font_family=font_family,
        font_size=effective_leaf_font_size,
        stroke_color=stroke_color,
        leaf_font_size=effective_leaf_font_size,
    )
    _set_svg_stroke_width(svg_element, general_stroke_width)
    svg_string = ET.tostring(svg_element, encoding="unicode")

    if svg_output_path is not None:
        with open(svg_output_path, "w", encoding="utf-8") as f:
            f.write(svg_string)

    if which_plot == "both":
        fig = _make_distance_plot(
            trees,
            width,
            height,
            title=distance_plot_title,
            xlabel=distance_plot_xlabel,
            ylabel=distance_plot_ylabel,
            bottom_margin=bottom_margin,
            distance_plot_type=distance_plot_type,
        )
        _combine_and_display(svg_string, fig, save_format, output_path=output_path)
        plt.close(fig)
    elif which_plot == "tree":
        if output_path is not None:
            if output_path.lower().endswith(".pdf"):
                cairosvg.svg2pdf(
                    bytestring=svg_string.encode("utf-8"), write_to=output_path
                )
            else:
                cairosvg.svg2png(
                    bytestring=svg_string.encode("utf-8"), write_to=output_path
                )
        else:
            with tempfile.TemporaryDirectory() as tmpdir:
                png_path = os.path.join(tmpdir, "tree_row.png")
                cairosvg.svg2png(
                    bytestring=svg_string.encode("utf-8"), write_to=png_path
                )
                display(Image(filename=png_path))
    elif which_plot == "distance":
        fig = _make_distance_plot(
            trees,
            width,
            height,
            title=distance_plot_title,
            xlabel=distance_plot_xlabel,
            ylabel=distance_plot_ylabel,
            bottom_margin=bottom_margin,
            distance_plot_type=distance_plot_type,
        )
        if output_path is not None:
            fig.savefig(output_path, bbox_inches="tight", dpi=100)
        else:
            display(fig)
        plt.close(fig)
    else:
        raise ValueError(
            f"Invalid value for which_plot: {which_plot}. Use 'tree', 'distance', or 'both'."
        )


# --- Section 7: Configuration and Helper Functions ---
def _normalize_highlight_colors(
    highlight_colors: Optional[Any], n: int
) -> List[Dict[Any, Any]]:
    if highlight_colors is None:
        return [{} for _ in range(n)]
    out: List[Dict[Any, Any]] = []
    for d in highlight_colors:
        if d is None:
            out.append({})
        elif isinstance(d, dict):
            newd: Dict[Any, Any] = {}
            for k, v in d.items():
                if isinstance(v, str):
                    newd[k] = {"highlight_color": v}
                else:
                    newd[k] = v
            out.append(newd)
        else:
            out.append(d)
    return out


def _get_bezier_colors_and_widths(
    trees: List[Any], min_width: float, max_width: float, cmap_name: str
) -> Tuple[List[List[str]], List[List[float]]]:
    import matplotlib.colors as mcolors
    import matplotlib.pyplot as plt

    per_pair_taxa_dists = compute_per_pair_taxa_dists(trees)
    all_dists = [d for pair in per_pair_taxa_dists for d in pair]
    
    # Handle empty distance list case
    if not all_dists:
        # Return default colors and widths for single tree case
        n_trees = len(trees)
        if n_trees == 1:
            # Single tree case - return empty lists
            return [[]], [[]]
        else:
            # Multiple trees but no distances computed - use defaults
            default_color = "#e0e0e0"
            default_width = min_width
            return [
                [default_color] * len(trees[0].get_current_order() if hasattr(trees[0], 'get_current_order') else []) 
                for _ in range(n_trees - 1)
            ], [
                [default_width] * len(trees[0].get_current_order() if hasattr(trees[0], 'get_current_order') else [])
                for _ in range(n_trees - 1)
            ]
    
    min_d, max_d = min(all_dists), max(all_dists)

    def norm(d: float) -> float:
        return (d - min_d) / (max_d - min_d + 1e-8)

    cmap = plt.get_cmap(cmap_name)

    def subtle_color(val: float) -> str:
        return "#e0e0e0" if val < 1e-6 else mcolors.to_hex(cmap(val))

    return compute_bezier_colors_and_widths(
        per_pair_taxa_dists, norm, subtle_color, min_width, max_width
    )


def _set_svg_stroke_width(svg_element: Any, stroke_width: float) -> None:
    # Recursively set stroke-width for all lines/paths in SVG
    for elem in svg_element.iter():
        if (
            elem.tag.endswith("line")
            or elem.tag.endswith("path")
            or elem.tag.endswith("polyline")
        ):
            elem.set("stroke-width", str(stroke_width))
