# mypy: ignore-errors
"""Core BranchArchitect package."""

# Export movie API for external use
from .movie_api import (
    TreeList,
    TreePairSolution,
    ProcessingResult,
    PipelineConfig,
    TreeInterpolationPipeline,
    process_trees,
)

__all__ = [
    "TreeList",
    "TreePairSolution",
    "ProcessingResult",
    "PipelineConfig",
    "TreeInterpolationPipeline",
    "process_trees",
]
