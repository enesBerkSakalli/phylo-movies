"""
Helper and processing functions for tree interpolation.

This module contains utility functions for processin    # Generate names
    names: List[str] = generate_tree_names(
        tree_index,
        len(interpolation_trees.down),
        len(consensus_result.trees),
        len(interpolation_trees.up)
    )

    # Generate s_edge tracking
    s_edge_tracking: List[Optional[Partition]] = generate_s_edge_tracking(
        lattice_edge_data,
        len(interpolation_trees.down),
        len(consensus_result.trees),
        len(interpolation_trees.up)
    )

    return TreePairResult(
        trees=all_trees,
        names=names,
        mapping_one=consensus_result.mapping_one,
        mapping_two=consensus_result.mapping_two,
        s_edge_tracking=s_edge_tracking,
    )extracting data, and managing the interpolation workflow.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional, Tuple
from brancharchitect.tree import Node
from brancharchitect.elements.partition import Partition
from brancharchitect.tree_interpolation.core import _calculate_intermediate
from brancharchitect.tree_interpolation.types import (
    InterpolationTrees,
    LatticeEdgeData,
)

logger: logging.Logger = logging.getLogger(__name__)


def interpolate_intermediate_tree_down_progressively(
    source_tree: Node,
    target_splits: Dict[Partition, float],
    edge_sequence: List[Partition],
) -> List[Node]:
    """
    Create progressive interpolation sequence between two trees.

    Args:
        source_tree: Starting tree for interpolation
        target_splits: Target split weights to interpolate toward
        edge_sequence: Ordered list of lattice edges to process sequentially

    Returns:
        List of trees showing progressive interpolation steps
    """
    # Import here to access private function from core module

    working_tree = source_tree.deep_copy()
    working_tree._initialize_split_indices(working_tree.taxa_encoding)
    original_weights = source_tree.to_weighted_splits()

    interpolation_steps: List[Node] = []

    # Process each edge in sequence
    for i, edge in enumerate(edge_sequence):
        edge_node = working_tree.find_node_by_split(edge)

        if edge_node is not None:
            # Apply intermediate calculation to this subtree
            _calculate_intermediate(edge_node, target_splits, original_weights)
            # Update split indices after modification
            working_tree._initialize_split_indices(working_tree.taxa_encoding)
        else:
            logger.debug(
                f"Edge {i + 1}/{len(edge_sequence)}: {edge} not found in working tree"
            )

        # Save current state as interpolation step
        interpolation_steps.append(working_tree.deep_copy())

    return interpolation_steps


def create_branch_averaging_progressions(
    target: Node,
    reference: Node,
    split_data: Tuple[Dict[Partition, float], Dict[Partition, float]],
    lattice_edge_data: LatticeEdgeData,
) -> InterpolationTrees:
    """Create progressive sequences with averaged branch lengths between trees."""
    split_dict1, split_dict2 = split_data

    # Get sorted edges for both directions
    sorted_target_desc: List[Partition] = lattice_edge_data.get_sorted_edges(
        use_reference=False, ascending=True
    )
    sorted_reference_desc: List[Partition] = lattice_edge_data.get_sorted_edges(
        use_reference=True, ascending=True
    )

    # Create interpolation sequences
    it_down: List[Node] = interpolate_intermediate_tree_down_progressively(
        target, split_dict2, sorted_target_desc
    )
    it_up: List[Node] = interpolate_intermediate_tree_down_progressively(
        reference, split_dict1, sorted_reference_desc
    )
    it_up = it_up[::-1]  # Reverse for upward interpolation

    return InterpolationTrees(it_down, it_up)


def generate_tree_names(
    tree_index: int, num_down: int, num_consensus: int, num_up: int
) -> List[str]:
    """Generate names for a single interpolation sequence."""
    names: list[str] = []
    # Starting tree
    names.append(f"T{tree_index}")
    # Down phase trees
    names.extend([f"IT{tree_index}_down_{i + 1}" for i in range(num_down)])
    # Consensus phase trees
    names.extend([f"C{tree_index}_{i + 1}" for i in range(num_consensus)])
    # Up phase trees
    names.extend([f"IT{tree_index}_up_{i + 1}" for i in range(num_up)])
    return names


def generate_s_edge_tracking(
    lattice_edge_data: LatticeEdgeData, num_down: int, num_consensus: int, num_up: int
) -> List[Optional[Partition]]:
    """
    Generate s_edge tracking list that corresponds to each interpolated tree.

    Returns a list where each element corresponds to the s_edge (lattice edge)
    that was applied to generate that tree, or None for starting/ending trees.
    """
    # Get the edge sequences used in each phase
    sorted_target_desc: List[Partition] = lattice_edge_data.get_sorted_edges(
        use_reference=False, ascending=True
    )
    sorted_reference_desc: List[Partition] = lattice_edge_data.get_sorted_edges(
        use_reference=True, ascending=True
    )
    sorted_edges_asc: List[Partition] = lattice_edge_data.get_sorted_edges(
        use_reference=True, ascending=True
    )

    s_edge_tracking: List[Optional[Partition]] = []

    # Starting tree (no s_edge applied)
    s_edge_tracking.append(None)

    # Down phase - each tree is generated by applying one edge from sorted_target_desc
    for i in range(num_down):
        if i < len(sorted_target_desc):
            s_edge_tracking.append(sorted_target_desc[i])
        else:
            s_edge_tracking.append(None)

    # Consensus phase - each tree is generated by applying one edge from sorted_edges_asc
    for i in range(num_consensus):
        if i < len(sorted_edges_asc):
            s_edge_tracking.append(sorted_edges_asc[i])
        else:
            s_edge_tracking.append(None)

    # Up phase - each tree is generated by applying one edge from sorted_reference_desc (reversed)
    sorted_reference_desc_reversed = sorted_reference_desc[::-1]
    for i in range(num_up):
        if i < len(sorted_reference_desc_reversed):
            s_edge_tracking.append(sorted_reference_desc_reversed[i])
        else:
            s_edge_tracking.append(None)

    return s_edge_tracking
