# mypy: ignore-errors
"""Core BranchArchitect package."""

# Export movie API for external use
from .movie_api import (
    TreeList,
    TreePairSolution,
    InterpolationSequence,
    PipelineConfig,
    TreeInterpolationPipeline,
    process_trees,
)

__all__ = [
    "TreeList",
    "TreePairSolution",
    "InterpolationSequence",
    "PipelineConfig",
    "TreeInterpolationPipeline",
    "process_trees",
]
