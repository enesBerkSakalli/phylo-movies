from typing import List, Dict, Tuple, Optional, Union, Any
from dataclasses import dataclass
import tempfile
import os


# Configuration dataclasses to reduce parameter redundancy
@dataclass
class StylingConfig:
    """Configuration for styling options."""

    font_family: str = "Monospace"
    font_size: str = "18"
    leaf_font_size: Optional[str] = None
    stroke_color: str = "#000"
    general_stroke_width: float = 2.0


@dataclass
class HighlightConfig:
    """Configuration for branch highlighting."""

    branches: Optional[Any] = None
    width: Union[float, List[float]] = 10.0
    colors: Optional[Any] = None


@dataclass
class BezierConfig:
    """Configuration for Bezier curve styling."""

    min_width: float = 4.0
    max_width: float = 14.0
    cmap_name: str = "viridis"
    colors: Optional[Any] = None
    stroke_widths: Optional[Any] = None


@dataclass
class PlotConfig:
    """Configuration for distance plots."""

    title: Optional[str] = None
    xlabel: Optional[str] = None
    ylabel: Optional[str] = None
    plot_type: str = "both"  # "both", "rf", "circular"


@dataclass
class LayoutConfig:
    """Configuration for layout and dimensions."""

    size: int = 240
    margin: int = 50
    label_offset: int = 18
    y_steps: int = 7
    top_margin: int = 210
    bottom_margin: int = 36


# --- Parameter Normalization Utilities ---
@dataclass
class TreeRenderingParams:
    """Normalized parameters for tree rendering."""
    highlight_branches: List[Any]
    highlight_width: List[Union[int, float]]
    highlight_colors: List[Dict[Any, Any]]
    
    @classmethod
    def normalize(cls, n_trees: int, **kwargs) -> 'TreeRenderingParams':
        """Normalize rendering parameters for n_trees."""
        return cls(
            highlight_branches=normalize_to_list(kwargs.get('highlight_branches'), n_trees),
            highlight_width=normalize_to_list(kwargs.get('highlight_width', 4.0), n_trees),
            highlight_colors=normalize_highlight_colors_list(kwargs.get('highlight_colors'), n_trees)
        )

def normalize_to_list(value: Any, n: int) -> List[Any]:
    """Normalize a value to a list of length n."""
    if value is None:
        return [None] * n
    if isinstance(value, (int, float)):
        return [value] * n
    if isinstance(value, list):
        if len(value) == n:
            return value
        if len(value) == 0 or not isinstance(value[0], (list, tuple)):
            return [value] * n
    return [value] * n

def normalize_highlight_colors_list(highlight_colors: Optional[Any], n: int) -> List[Dict[Any, Any]]:
    """Normalize highlight colors to a list of dicts."""
    if highlight_colors is None:
        return [{} for _ in range(n)]
    if isinstance(highlight_colors, list) and len(highlight_colors) == n:
        return [_normalize_single_highlight_color(hc) for hc in highlight_colors]
    return [_normalize_single_highlight_color(highlight_colors)] * n

def _normalize_single_highlight_color(color: Any) -> Dict[Any, Any]:
    """Normalize a single highlight color specification."""
    if color is None:
        return {}
    if isinstance(color, dict):
        normalized = {}
        for k, v in color.items():
            if isinstance(v, str):
                normalized[k] = {"highlight_color": v}
            else:
                normalized[k] = v
        return normalized
    return color

# Configuration factory functions for common use cases
def create_paper_styling() -> StylingConfig:
    """Create styling configuration optimized for scientific papers."""
    return StylingConfig(
        font_family="Arial",
        font_size="14",
        stroke_color="#333",
        general_stroke_width=1.5,
    )


def create_presentation_styling() -> StylingConfig:
    """Create styling configuration optimized for presentations."""
    return StylingConfig(
        font_family="Arial",
        font_size="20",
        stroke_color="#000",
        general_stroke_width=2.5,
    )


def create_web_styling() -> StylingConfig:
    """Create styling configuration optimized for web display."""
    return StylingConfig(
        font_family="system-ui",
        font_size="16",
        stroke_color="#444",
        general_stroke_width=2.0,
    )


def create_compact_layout() -> LayoutConfig:
    """Create layout configuration for compact displays."""
    return LayoutConfig(size=180, margin=30, label_offset=12, y_steps=5)


def create_large_layout() -> LayoutConfig:
    """Create layout configuration for large displays."""
    return LayoutConfig(size=320, margin=70, label_offset=24, y_steps=9)


# --- Section 1: Distance Computation Functions ---
def compute_rf_distances(trees: List[Any]) -> List[float]:
    from brancharchitect.distances.distances import robinson_foulds_distance

    return [
        robinson_foulds_distance(trees[i], trees[i + 1]) for i in range(len(trees) - 1)
    ]


def per_taxa_circular_distances(tree1: Any, tree2: Any) -> List[float]:
    # Handle cases where trees don't have get_current_order method
    if not hasattr(tree1, "get_current_order") or not hasattr(
        tree2, "get_current_order"
    ):
        return []

    order1 = tree1.get_current_order()
    order2 = tree2.get_current_order()

    # Handle empty orders
    if not order1 or not order2:
        return []

    n = len(order1)

    # Handle single taxon case
    if n <= 1:
        return [0.0] * n

    idx1 = {name: i for i, name in enumerate(order1)}
    idx2 = {name: i for i, name in enumerate(order2)}
    dists: List[float] = []

    for name in order1:
        if name not in idx2:
            # Taxa not present in second tree - assign max distance
            dists.append(1.0)
        else:
            diff = abs(idx1[name] - idx2[name])
            d = min(diff, n - diff) / (n // 2) if n > 1 else 0.0
            dists.append(d)
    return dists


def compute_per_pair_taxa_dists(trees: List[Any]) -> List[List[float]]:
    if len(trees) < 2:
        return []

    num_pairs = len(trees) - 1
    return [
        per_taxa_circular_distances(trees[i], trees[i + 1]) for i in range(num_pairs)
    ]


def compute_bezier_colors_and_widths(
    per_pair_taxa_dists: List[List[float]],
    norm: Any,
    subtle_color: Any,
    min_width: float,
    max_width: float,
) -> Tuple[List[List[str]], List[List[float]]]:
    bezier_colors_per_pair = [
        [subtle_color(norm(d)) for d in pair] for pair in per_pair_taxa_dists
    ]
    bezier_stroke_widths_per_pair = [
        [min_width + (max_width - min_width) * norm(d) for d in pair]
        for pair in per_pair_taxa_dists
    ]
    return bezier_colors_per_pair, bezier_stroke_widths_per_pair


# Legacy functions - now use shared utilities
def _normalize_highlight_branches(highlight_branches: Any, n: int) -> List[Any]:
    return normalize_to_list(highlight_branches, n)

def _normalize_highlight_width(
    highlight_width: Union[int, float, List[Union[int, float]]], n: int
) -> List[Union[int, float]]:
    return normalize_to_list(highlight_width, n)


# --- Section 2: Styling and Utility Functions ---
def _apply_matplotlib_styling(
    fig_or_ax: Any,
    title: Optional[str] = None,
    xlabel: Optional[str] = None,
    ylabel: Optional[str] = None,
    ylabel_color: str = "tab:blue",
) -> None:
    """Apply common matplotlib styling to figure or axes."""
    if hasattr(fig_or_ax, "subplots_adjust"):  # It's a figure
        fig = fig_or_ax
        axs = fig.get_axes()
        if title:
            fig.suptitle(title, fontsize=28, fontweight="bold", y=1.03)
        for ax in axs:
            _style_single_axis(ax)
            if xlabel and ax == axs[-1]:  # Apply xlabel to bottom axis
                ax.set_xlabel(xlabel, fontsize=22, fontweight="bold")
            if ylabel and ylabel_color:
                ax.set_ylabel(
                    ylabel,
                    fontsize=20,
                    color=ylabel_color,
                    labelpad=2,
                    fontweight="bold",
                )
    else:  # It's a single axis
        ax = fig_or_ax
        _style_single_axis(ax)
        if title:
            ax.figure.suptitle(title, fontsize=28, fontweight="bold", y=1.03)
        if xlabel:
            ax.set_xlabel(xlabel, fontsize=22, fontweight="bold")
        if ylabel:
            ax.set_ylabel(
                ylabel, fontsize=20, color=ylabel_color, labelpad=2, fontweight="bold"
            )


def _style_single_axis(ax: Any) -> None:
    """Apply common styling to a single axis."""
    ax.tick_params(axis="both", labelsize=16)
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontweight("bold")
    leg = ax.get_legend()
    if leg:
        for text in leg.get_texts():
            text.set_fontsize(18)
            text.set_fontweight("bold")


def _combine_images(tree_img: Any, dist_img: Any) -> Any:
    """Combine tree and distance plot images vertically."""
    import PIL.Image

    w = max(tree_img.width, dist_img.width)

    # Create new images with white background instead of resizing
    new_tree_img = PIL.Image.new("RGBA", (w, tree_img.height), (255, 255, 255, 255))
    new_dist_img = PIL.Image.new("RGBA", (w, dist_img.height), (255, 255, 255, 255))

    # Center the original images on the new white backgrounds
    tree_x_offset = (w - tree_img.width) // 2
    dist_x_offset = (w - dist_img.width) // 2

    new_tree_img.paste(tree_img, (tree_x_offset, 0))
    new_dist_img.paste(dist_img, (dist_x_offset, 0))

    total_height = new_tree_img.height + new_dist_img.height
    combined = PIL.Image.new("RGBA", (w, total_height), (255, 255, 255, 255))
    combined.paste(new_tree_img, (0, 0))
    combined.paste(new_dist_img, (0, new_tree_img.height))
    return combined


def _setup_common_axis_style(
    ax: Any, color: str, n: int, ylabel_text: str, show_xticks: bool = False
) -> None:
    """Apply common axis styling for distance plots."""
    import numpy as np

    ax.tick_params(axis="y", labelcolor=color, length=0, labelsize=14)
    ax.set_xlim(0, n - 1)
    if show_xticks:
        ax.set_xticks(np.arange(n))
        ax.set_xticklabels(
            [f"T{i + 1}" for i in range(n)], fontsize=16, fontweight="bold"
        )
    else:
        ax.set_xticks([])
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(color)
    ax.spines["bottom"].set_color("#888" if show_xticks else color)
    if not show_xticks:
        ax.spines["bottom"].set_visible(False)
    ax.grid(axis="y", linestyle=":", alpha=0.22)
    ax.set_ylabel(ylabel_text, fontsize=18, color=color, labelpad=2, fontweight="bold")


# --- Section 3: SVG Construction Functions ---
def _make_and_style_svg_element(
    trees: List[Any],
    size: int,
    margin: int,
    bezier_colors_per_pair: List[List[str]],
    bezier_stroke_widths_per_pair: List[List[float]],
    label_offset: int,
    highlight_branches_list: List[Any],
    highlight_width_list: List[Union[int, float]],
    highlight_colors_list: List[Dict[Any, Any]],
    y_steps: int,
    top_margin: int = 190,
    font_family: str = "Monospace",
    font_size: str = "12",
    stroke_color: str = "#000",
    leaf_font_size: Optional[str] = None,
    show_zero_length_indicators: bool = False,
    zero_length_indicator_color: str = "#ff4444",
    zero_length_indicator_size: float = 6.0,
) -> Tuple[Any, int, int]:
    from brancharchitect.plot.tree_plot import plot_circular_trees_in_a_row

    svg_element = plot_circular_trees_in_a_row(
        trees,
        size=size,
        margin=margin,
        bezier_colors=bezier_colors_per_pair,
        bezier_stroke_widths=bezier_stroke_widths_per_pair,
        label_offset=label_offset,
        highlight_branches=highlight_branches_list,
        highlight_width=highlight_width_list,
        highlight_colors=highlight_colors_list,
        font_family=font_family,
        font_size=font_size,
        stroke_color=stroke_color,
        leaf_font_size=leaf_font_size,
        show_zero_length_indicators=show_zero_length_indicators,
        zero_length_indicator_color=zero_length_indicator_color,
        zero_length_indicator_size=zero_length_indicator_size,
    )
    # Get SVG dimensions
    width = int(svg_element.attrib.get("width", size * len(trees)))
    height = int(svg_element.attrib.get("height", size))

    # Update SVG element dimensions to include top_margin
    svg_element.set("width", str(width))
    svg_element.set("height", str(height + top_margin))

    # Add background
    import xml.etree.ElementTree as ET

    background = ET.Element(
        "rect",
        {
            "x": "0",
            "y": "0",
            "width": str(width),
            "height": str(height + top_margin),
            "fill": "#fff",
        },
    )
    svg_element.insert(0, background)

    # Add gridlines
    from brancharchitect.plot.tree_plot import add_svg_gridlines

    add_svg_gridlines(svg_element, width, height, y_steps=y_steps)
    return svg_element, width, height


# --- Section 4: Distance Plotting Functions ---
def _add_distance_annotation(
    ax: Any, total_circular_distance: float, bottom_margin: int, height: int
) -> None:
    """Add total circular distance annotation to axis."""
    ax.annotate(
        f"Total circular distance: {total_circular_distance:.2f}",
        xy=(1, -0.32 - (bottom_margin / height if bottom_margin else 0)),
        xycoords="axes fraction",
        ha="right",
        va="top",
        fontsize=22,
        color="tab:blue",
        fontweight="bold",
        bbox=dict(
            boxstyle="round,pad=0.3", fc="#f8fafd", ec="#b0c4de", lw=2, alpha=0.92
        ),
    )


def _make_distance_plot(
    trees: List[Any],
    width: int,
    height: int,
    title: Optional[str] = None,
    xlabel: Optional[str] = None,
    ylabel: Optional[str] = None,
    bottom_margin: int = 0,
    distance_plot_type: str = "both",
) -> Any:
    import matplotlib.pyplot as plt
    import numpy as np

    rf_dists = compute_rf_distances(trees)
    circ_dists = [np.mean(pair) for pair in compute_per_pair_taxa_dists(trees)]
    circ_sums = [np.sum(pair) for pair in compute_per_pair_taxa_dists(trees)]
    total_circular_distance = sum(circ_sums)
    x = np.arange(0.5, len(trees) - 0.5, 1)

    if distance_plot_type == "both":
        fig, axs = plt.subplots(
            2,
            1,
            figsize=(width / 80, 3.2 + bottom_margin / 80),
            sharex=True,
            gridspec_kw={"height_ratios": [1, 1], "hspace": 0.18},
        )
        _plot_rf(axs[0], x, rf_dists, len(trees))
        _plot_circ(axs[1], x, circ_dists, len(trees))
        fig.subplots_adjust(
            bottom=0.22 + (bottom_margin / height if bottom_margin else 0)
        )
        _add_distance_annotation(axs[1], total_circular_distance, bottom_margin, height)
        _apply_matplotlib_styling(fig, title, xlabel, ylabel, "tab:blue")
        plt.tight_layout(pad=0.22)
        return fig
    elif distance_plot_type == "rf":
        fig, ax = plt.subplots(1, 1, figsize=(width / 80, 1.6 + bottom_margin / 80))
        _plot_rf(ax, x, rf_dists, len(trees))
        _apply_matplotlib_styling(ax, title, xlabel, ylabel, "tab:red")
        plt.tight_layout(pad=0.22)
        return fig
    elif distance_plot_type == "circular":
        fig, ax = plt.subplots(1, 1, figsize=(width / 80, 1.6 + bottom_margin / 80))
        _plot_circ(ax, x, circ_dists, len(trees))
        _add_distance_annotation(ax, total_circular_distance, bottom_margin, height)
        _apply_matplotlib_styling(ax, title, xlabel, ylabel, "tab:blue")
        plt.tight_layout(pad=0.22)
        return fig
    else:
        raise ValueError(
            f"Invalid distance_plot_type: {distance_plot_type}. Use 'both', 'rf', or 'circular'."
        )


def _plot_rf(ax: Any, x: Any, rf_dists: List[float], n: int) -> None:
    ax.plot(
        x,
        rf_dists,
        color="tab:red",
        lw=2.2,
        marker="o",
        markersize=9,
        label="Robinson-Foulds",
    )
    _setup_common_axis_style(ax, "tab:red", n, "RF", show_xticks=False)
    ax.legend(loc="upper right", fontsize=18, frameon=False)


def _plot_circ(ax: Any, x: Any, circ_dists: Any, n: int) -> None:
    ax.plot(
        x,
        circ_dists,
        color="tab:blue",
        lw=2.2,
        marker="o",
        markersize=9,
        label="Circular (mean)",
    )
    _setup_common_axis_style(ax, "tab:blue", n, "Circular", show_xticks=True)
    ax.legend(loc="upper right", fontsize=18, frameon=False)


# --- Section 5: Image Processing and Output ---
def _combine_and_display(
    svg_string: str, fig: Any, save_format: str, output_path: Optional[str] = None
) -> None:
    from IPython.display import Image, display
    import cairosvg  # type: ignore
    import PIL.Image

    def _save_and_combine_images(
        tmpdir: str, svg_string: str, fig: Any, output_path: str
    ) -> Any:
        """Helper to save SVG as PNG, save matplotlib fig, and combine them."""
        svg_path = os.path.join(tmpdir, "trees.svg")
        tree_png_path = os.path.join(tmpdir, "trees.png")
        dist_png_path = os.path.join(tmpdir, "dist.png")

        with open(svg_path, "w") as f:
            f.write(svg_string)
        cairosvg.svg2png(url=svg_path, write_to=tree_png_path, background_color="white")
        fig.savefig(
            dist_png_path,
            bbox_inches="tight",
            dpi=100,
            facecolor="white",
            edgecolor="none",
        )

        tree_img = PIL.Image.open(tree_png_path)
        dist_img = PIL.Image.open(dist_png_path)
        combined = _combine_images(tree_img, dist_img)
        combined.save(output_path)
        return combined

    if output_path is not None:
        tmpdir = os.path.dirname(output_path)
        os.makedirs(tmpdir, exist_ok=True)
        if output_path.lower().endswith(".pdf"):
            cairosvg.svg2pdf(
                bytestring=svg_string.encode("utf-8"), write_to=output_path
            )
        else:
            _save_and_combine_images(tmpdir, svg_string, fig, output_path)
            display(Image(filename=output_path))
    else:
        with tempfile.TemporaryDirectory() as tmpdir:
            img_path = os.path.join(tmpdir, f"combined.{save_format}")
            _save_and_combine_images(tmpdir, svg_string, fig, img_path)
            display(Image(filename=img_path))


# --- Section 6: Main API Functions ---

"""
# Before: 47 parameters
plot_tree_row_with_beziers_and_distances(
    trees, size=240, margin=50, label_offset=18, y_steps=7,
    min_width=4.0, max_width=14.0, cmap_name="viridis",
    save_format="png", highlight_branches=None, highlight_width=10.0,
    highlight_colors=None, distance_plot_title="Tree Comparison",
    distance_plot_xlabel="Tree Index", distance_plot_ylabel="Distance",
    output_path=None, svg_output_path=None, ignore_branch_lengths=False,
    font_family="Monospace", font_size="18", leaf_font_size=None,
    stroke_color="#000", bezier_colors=None, bezier_stroke_widths=None,
    glow=True, which_plot="both", general_stroke_width=2.0,
    distance_plot_type="both"
)

# After: 12 parameters with configuration objects
plot_tree_row_with_configs(
    trees=trees,
    styling=create_paper_styling(),
    layout=create_compact_layout(),
    distance_plot=PlotConfig(
        title="Tree Comparison",
        xlabel="Tree Index",
        ylabel="Distance"
    ),
    output_path="output.png"
)

# Or with custom configurations:
custom_styling = StylingConfig(
    font_family="Arial",
    font_size="16",
    stroke_color="#333"
)

custom_highlight = HighlightConfig(
    branches=["branch1", "branch2"],
    width=8.0,
    colors={"branch1": "red", "branch2": "blue"}
)

plot_tree_row_with_configs(
    trees=trees,
    styling=custom_styling,
    highlight=custom_highlight,
    output_path="highlighted_trees.png"
)
"""


def plot_tree_row_with_beziers_and_distances(
    trees: List[Any],
    size: int = 240,
    margin: int = 50,
    label_offset: int = 18,
    y_steps: int = 7,
    min_width: float = 4.0,
    max_width: float = 14.0,
    cmap_name: str = "viridis",
    save_format: str = "png",
    highlight_branches: Optional[Any] = None,
    highlight_width: float = 10.0,
    highlight_colors: Optional[Any] = None,
    distance_plot_title: Optional[str] = None,
    distance_plot_xlabel: Optional[str] = None,
    distance_plot_ylabel: Optional[str] = None,
    output_path: Optional[str] = None,
    svg_output_path: Optional[str] = None,
    ignore_branch_lengths: bool = False,
    font_family: str = "Monospace",
    font_size: str = "18",
    leaf_font_size: Optional[str] = None,
    stroke_color: str = "#000",
    bezier_colors: Optional[Any] = None,
    bezier_stroke_widths: Optional[Any] = None,
    glow: bool = True,
    which_plot: str = "both",
    general_stroke_width: float = 2.0,
    distance_plot_type: str = "both",
    show_zero_length_indicators: bool = False,
    zero_length_indicator_color: str = "#ff4444",
    zero_length_indicator_size: float = 6.0,
) -> None:
    """
    Main API to plot a row of circular trees with Bezier connections and/or distance plots.
    Args:
        which_plot: 'tree' (only tree row), 'distance' (only distance plot), 'both' (default, both combined)
        show_zero_length_indicators: Whether to show visual indicators for zero-length branches
        zero_length_indicator_color: Color for zero-length branch indicators (default: red)
        zero_length_indicator_size: Size of zero-length branch indicators in pixels
    """
    import matplotlib.pyplot as plt
    import xml.etree.ElementTree as ET
    import cairosvg  # type: ignore
    from IPython.display import Image, display

    n = len(trees)
    # Use new unified parameter normalization
    params = TreeRenderingParams.normalize(
        n, 
        highlight_branches=highlight_branches,
        highlight_width=highlight_width,
        highlight_colors=highlight_colors
    )
    highlight_branches_list = params.highlight_branches
    highlight_width_list = params.highlight_width
    highlight_colors_list = params.highlight_colors
    bezier_colors_per_pair, bezier_stroke_widths_per_pair = (
        _get_bezier_colors_and_widths(trees, min_width, max_width, cmap_name)
    )
    bottom_margin = 36
    effective_leaf_font_size = (
        str(leaf_font_size) if leaf_font_size is not None else font_size
    )
    svg_element, width, height = _make_and_style_svg_element(
        trees,
        size,
        margin,
        bezier_colors_per_pair,
        bezier_stroke_widths_per_pair,
        label_offset,
        highlight_branches_list,
        highlight_width_list,
        highlight_colors_list,
        y_steps,
        top_margin=210,
        font_family=font_family,
        font_size=effective_leaf_font_size,
        stroke_color=stroke_color,
        leaf_font_size=effective_leaf_font_size,
        show_zero_length_indicators=show_zero_length_indicators,
        zero_length_indicator_color=zero_length_indicator_color,
        zero_length_indicator_size=zero_length_indicator_size,
    )
    _set_svg_stroke_width(svg_element, general_stroke_width)
    svg_string = ET.tostring(svg_element, encoding="unicode")

    if svg_output_path is not None:
        with open(svg_output_path, "w", encoding="utf-8") as f:
            f.write(svg_string)

    if which_plot == "both":
        fig = _make_distance_plot(
            trees,
            width,
            height,
            title=distance_plot_title,
            xlabel=distance_plot_xlabel,
            ylabel=distance_plot_ylabel,
            bottom_margin=bottom_margin,
            distance_plot_type=distance_plot_type,
        )
        _combine_and_display(svg_string, fig, save_format, output_path=output_path)
        plt.close(fig)
    elif which_plot == "tree":
        if output_path is not None:
            if output_path.lower().endswith(".pdf"):
                cairosvg.svg2pdf(
                    bytestring=svg_string.encode("utf-8"), write_to=output_path
                )
            else:
                cairosvg.svg2png(
                    bytestring=svg_string.encode("utf-8"),
                    write_to=output_path,
                    background_color="white",
                )
                # Display the saved image to be consistent with other modes
                display(Image(filename=output_path))
        else:
            with tempfile.TemporaryDirectory() as tmpdir:
                png_path = os.path.join(tmpdir, "tree_row.png")
                cairosvg.svg2png(
                    bytestring=svg_string.encode("utf-8"),
                    write_to=png_path,
                    background_color="white",
                )
                display(Image(filename=png_path))
    elif which_plot == "distance":
        fig = _make_distance_plot(
            trees,
            width,
            height,
            title=distance_plot_title,
            xlabel=distance_plot_xlabel,
            ylabel=distance_plot_ylabel,
            bottom_margin=bottom_margin,
            distance_plot_type=distance_plot_type,
        )
        if output_path is not None:
            fig.savefig(
                output_path,
                bbox_inches="tight",
                dpi=100,
                facecolor="white",
                edgecolor="none",
            )
        else:
            display(fig)
        plt.close(fig)
    else:
        raise ValueError(
            f"Invalid value for which_plot: {which_plot}. Use 'tree', 'distance', or 'both'."
        )


# --- Section 7: Configuration and Helper Functions ---
# Legacy function - now uses shared utility
def _normalize_highlight_colors(highlight_colors: Optional[Any], n: int) -> List[Dict[Any, Any]]:
    return normalize_highlight_colors_list(highlight_colors, n)


def _get_bezier_colors_and_widths(
    trees: List[Any], min_width: float, max_width: float, cmap_name: str
) -> Tuple[List[List[str]], List[List[float]]]:
    import matplotlib.colors as mcolors
    import matplotlib.pyplot as plt

    per_pair_taxa_dists = compute_per_pair_taxa_dists(trees)
    all_dists = [d for pair in per_pair_taxa_dists for d in pair]

    # Handle empty distance list case
    if not all_dists:
        # Return default colors and widths for single tree case
        n_trees = len(trees)
        if n_trees == 1:
            # Single tree case - return empty lists
            return [[]], [[]]
        else:
            # Multiple trees but no distances computed - use defaults
            default_color = "#e0e0e0"
            default_width = min_width
            return [
                [default_color]
                * len(
                    trees[0].get_current_order()
                    if hasattr(trees[0], "get_current_order")
                    else []
                )
                for _ in range(n_trees - 1)
            ], [
                [default_width]
                * len(
                    trees[0].get_current_order()
                    if hasattr(trees[0], "get_current_order")
                    else []
                )
                for _ in range(n_trees - 1)
            ]

    min_d, max_d = min(all_dists), max(all_dists)

    def norm(d: float) -> float:
        return (d - min_d) / (max_d - min_d + 1e-8)

    cmap = plt.get_cmap(cmap_name)

    def subtle_color(val: float) -> str:
        return "#e0e0e0" if val < 1e-6 else mcolors.to_hex(cmap(val))

    return compute_bezier_colors_and_widths(
        per_pair_taxa_dists, norm, subtle_color, min_width, max_width
    )


def _set_svg_stroke_width(svg_element: Any, stroke_width: float) -> None:
    # Recursively set stroke-width for all lines/paths in SVG
    for elem in svg_element.iter():
        if (
            elem.tag.endswith("line")
            or elem.tag.endswith("path")
            or elem.tag.endswith("polyline")
        ):
            elem.set("stroke-width", str(stroke_width))
