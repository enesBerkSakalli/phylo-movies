"""
Data types and classes for tree interpolation.

This module contains the data structures used throughout the tree interpolation
process, including result containers and intermediate data representations.
"""

from __future__ import annotations

from typing import Dict, List, Optional
from dataclasses import dataclass, field

from brancharchitect.elements.partition import Partition
from brancharchitect.tree import Node
from brancharchitect.tree_interpolation.ordering import (
    compute_lattice_edge_depths,
)


@dataclass
class TreePairInterpolation:
    """Interpolation results for a single tree pair."""

    trees: List[Node]
    names: List[str]
    mapping_one: Dict[Partition, Partition]
    mapping_two: Dict[Partition, Partition]
    s_edge_tracking: List[Optional[Partition]] = field(default_factory=list)
    lattice_edge_solutions: Dict[Partition, List[List[Partition]]] = field(
        default_factory=dict
    )
    s_edge_distances: Dict[Partition, Dict[str, float]] = field(default_factory=dict)


class LatticeEdgeData:
    """Structured data for lattice edge processing."""

    def __init__(
        self, edges: List[Partition], solutions: Dict[Partition, List[List[Partition]]]
    ):
        self.edges: List[Partition] = edges
        self.solutions: Dict[Partition, List[List[Partition]]] = solutions
        self.target_depths: Dict[Partition, float] = {}
        self.reference_depths: Dict[Partition, float] = {}

    def compute_depths(self, target: Node, reference: Node) -> None:
        """Compute and store depth mappings for both trees."""
        # Import here to avoid circular dependency

        self.target_depths = compute_lattice_edge_depths(self.edges, target)
        self.reference_depths = compute_lattice_edge_depths(self.edges, reference)

    def get_sorted_edges(
        self, use_reference: bool = False, ascending: bool = False
    ) -> List[Partition]:
        """Get sorted edges by depth."""
        depths = self.reference_depths if use_reference else self.target_depths
        return sorted(self.edges, key=lambda p: depths[p], reverse=not ascending)


@dataclass
class TreeInterpolationSequence:
    """
    Structured result from sequential lattice interpolation processing.

    This dataclass replaces the unwieldy 8-tuple return type with a clear,
    self-documenting structure that groups related data logically.

    Attributes:
        interpolated_trees: All interpolated trees from all pairs
        interpolation_sequence_labels: Descriptive labels for each tree (IT_down, C_, IT_ref, etc.)
        mapping_one: Target tree solution-to-atom mappings for each pair
        mapping_two: Reference tree solution-to-atom mappings for each pair
        s_edge_tracking: Which s-edge was applied for each tree (None for fallbacks)
        s_edge_lengths: Number of interpolation steps per pair
        lattice_solutions_list: Raw lattice algorithm results for each pair
        s_edge_distances_list: Distance metrics for each s-edge in each pair
    """

    # Core interpolation results
    interpolated_trees: List[Node]
    interpolation_sequence_labels: List[str]

    # Per-pair mapping data
    mapping_one: List[Dict[Partition, Partition]]
    mapping_two: List[Dict[Partition, Partition]]

    # S-edge tracking and metadata
    s_edge_tracking: List[Optional[Partition]]
    s_edge_lengths: List[int]

    # Algorithm results and distance metrics
    lattice_solutions_list: List[Dict[Partition, List[List[Partition]]]]
    s_edge_distances_list: List[Dict[Partition, Dict[str, float]]]

    def get_pair_count(self) -> int:
        """Get the number of tree pairs processed."""
        return len(self.s_edge_lengths)

    def get_pair_data(self, pair_index: int) -> Dict[str, any]:
        """Get all data for a specific tree pair by index."""
        if pair_index >= self.get_pair_count():
            raise IndexError(
                f"Pair index {pair_index} out of range (0-{self.get_pair_count() - 1})"
            )

        return {
            "mapping_one": self.mapping_one[pair_index],
            "mapping_two": self.mapping_two[pair_index],
            "s_edge_length": self.s_edge_lengths[pair_index],
            "lattice_solutions": self.lattice_solutions_list[pair_index],
            "s_edge_distances": self.s_edge_distances_list[pair_index],
        }

    @property
    def total_interpolated_trees(self) -> int:
        """Total number of trees including originals and interpolated."""
        return len(self.interpolated_trees)

    @property
    def total_interpolation_steps(self) -> int:
        """Total number of interpolation steps across all pairs."""
        return sum(self.s_edge_lengths)
