# Code Organization Analysis: optimization_rooting.py

## Current State

The `optimization_rooting.py` file (522 lines) contains multiple distinct functional areas that would benefit from separation into focused modules. Currently, it mixes several different concerns:

1. **Jaccard Similarity Operations** (lines 20-120)
2. **Global Optimization Algorithms** (lines 123-350) 
3. **Root Candidate Selection** (lines 351-450)
4. **Fallback and Validation Utilities** (lines 451-522)

## Recommended Reorganization

### 1. **jaccard_similarity.py** (NEW MODULE)
**Purpose**: Dedicated to Jaccard similarity calculations and matching algorithms
**Lines to move**: 20-120 from optimization_rooting.py

**Functions to include**:
```python
# Core Jaccard operations
def _get_target_indices_and_bitmask(target_partition: Partition) -> Tuple[Optional[int], Optional[set[int]]]
def _calculate_jaccard_similarity(node_partition: Partition, target_popcount: Optional[int], target_indices: Optional[set[int]], target_partition: Partition) -> float
def find_best_matching_node_jaccard(target_partition: Partition, root: Node) -> Optional[Node]
def reroot_by_jaccard_similarity(tree1: Node, tree2: Node) -> Node
```

**Rationale**: Jaccard similarity is a specific mathematical concept with well-defined algorithms. Having it in a separate module makes it:
- Easier to test in isolation
- More reusable for other similarity-based operations
- Cleaner conceptually (single responsibility)

### 2. **global_optimization.py** (NEW MODULE)
**Purpose**: Advanced global optimization algorithms for tree comparison
**Lines to move**: 123-350 from optimization_rooting.py

**Functions to include**:
```python
# Split filtering and scoring
def _filter_and_score_split_candidates(split_a: Partition, splits_b: PartitionSet[Partition], similarity_matrix: Dict[Tuple[Partition, Partition], float], threshold: float = 0.1) -> List[Tuple[Partition, float]]

# Global correspondence mapping
def build_global_correspondence_map(splits_a: PartitionSet[Partition], splits_b: PartitionSet[Partition], similarity_matrix: Dict[Tuple[Partition, Partition], float]) -> Dict[Partition, Partition]

# Split weighting and scoring
def _calculate_split_weight(split: Partition) -> float
def _get_best_similarity_for_split(split: Partition, other_splits: PartitionSet[Partition], similarity_matrix: Dict[Tuple[Partition, Partition], float]) -> float
def _compute_global_similarity_score_splits(splits_a: PartitionSet[Partition], splits_b: PartitionSet[Partition], similarity_matrix: Dict[Tuple[Partition, Partition], float]) -> float

# Split-to-node mapping
def _get_split_to_node_mapping_for_root_search(tree: Node) -> Dict[Partition, Node]
def _evaluate_split_as_root_candidate(split: Partition, node: Node, reference_splits: PartitionSet[Partition], similarity_matrix: Dict[Tuple[Partition, Partition], float]) -> float
```

**Rationale**: Global optimization represents a complex algorithmic strategy that:
- Uses sophisticated split correspondence mapping
- Involves weighted scoring systems
- Requires multiple helper functions working together
- Is conceptually distinct from simple similarity matching

### 3. **root_selection.py** (NEW MODULE)
**Purpose**: Root candidate identification and selection strategies
**Lines to move**: 351-450 from optimization_rooting.py

**Functions to include**:
```python
# Candidate management
def _add_fallback_candidates(candidates: List[Tuple[Node, float]], tree: Node, max_candidates: int = 10) -> List[Tuple[Node, float]]
def find_optimal_root_candidates(tree: Node, reference_splits: PartitionSet[Partition], similarity_matrix: Dict[Tuple[Partition, Partition], float], max_candidates: int = 5) -> List[Tuple[Node, float]]

# Candidate selection
def _select_best_non_leaf_candidate(candidates: List[Tuple[Node, float]]) -> Optional[Node]
```

**Rationale**: Root selection is a distinct phase in the rerooting process:
- Focuses specifically on finding and ranking potential root positions
- Has its own fallback strategies
- Could be extended with additional selection criteria
- Is used by multiple optimization strategies

### 4. **optimization_utilities.py** (NEW MODULE)
**Purpose**: Common utilities and fallback strategies for optimization algorithms
**Lines to move**: 451-522 from optimization_rooting.py

**Functions to include**:
```python
# Fallback strategies
def _fallback_to_simple_rerooting(tree1: Node, tree2: Node) -> Node

# Tree validation
def _validate_and_rebuild_tree_structure(rerooted_tree: Node) -> Node
```

**Rationale**: These are cross-cutting concerns used by multiple optimization strategies:
- Fallback mechanisms when advanced methods fail
- Tree structure validation and repair
- Could be extended with additional utility functions

### 5. **optimization_rooting.py** (REFACTORED)
**Purpose**: High-level orchestration and main entry points
**Remaining content**: Main public API functions

**Functions to keep**:
```python
# Main optimization entry point
def reroot_to_compared_tree(tree1: Node, tree2: Node, splits1: Optional[PartitionSet[Partition]] = None, splits2: Optional[PartitionSet[Partition]] = None, similarity_matrix: Optional[Dict[Tuple[Partition, Partition], float]] = None) -> Node
```

**New content**: Import statements and orchestration logic that coordinates the different strategies.

## Benefits of This Reorganization

### 1. **Single Responsibility Principle**
Each module has a clear, focused purpose:
- `jaccard_similarity.py`: Mathematical similarity calculations
- `global_optimization.py`: Complex optimization algorithms  
- `root_selection.py`: Root candidate management
- `optimization_utilities.py`: Cross-cutting utilities

### 2. **Improved Testability**
- Each module can be tested independently
- Easier to write focused unit tests
- Reduced complexity in test setup

### 3. **Better Maintainability**
- Easier to locate specific functionality
- Changes to one algorithm don't affect others
- Clearer code organization

### 4. **Enhanced Reusability**
- Jaccard similarity functions could be used in other contexts
- Global optimization algorithms could be applied to other problems
- Root selection strategies could be enhanced independently

### 5. **Clearer Dependencies**
- Explicit import relationships between modules
- Easier to understand data flow
- Better separation of concerns

## Migration Strategy

### Phase 1: Create New Modules
1. Create the four new module files
2. Move functions with their dependencies
3. Add proper imports and type hints
4. Ensure all moved functions work correctly

### Phase 2: Update Imports
1. Update `optimization_rooting.py` to import from new modules
2. Update `__init__.py` to re-export from new modules
3. Update `rooting.py` if needed
4. Ensure public API remains unchanged

### Phase 3: Validation
1. Run existing tests to ensure nothing breaks
2. Add new focused tests for each module
3. Verify performance characteristics remain the same
4. Update documentation

## Files to Create

```
brancharchitect/rooting/
├── jaccard_similarity.py           # NEW - Jaccard similarity algorithms
├── global_optimization.py          # NEW - Global optimization strategies  
├── root_selection.py              # NEW - Root candidate selection
├── optimization_utilities.py       # NEW - Utilities and fallbacks
├── optimization_rooting.py         # REFACTORED - Main orchestration
├── core_rooting.py                # EXISTING - Basic operations
├── rooting.py                     # EXISTING - Unified interface
└── __init__.py                    # UPDATED - Re-export from new modules
```

This reorganization will significantly improve the codebase's maintainability while preserving all existing functionality and the public API.
