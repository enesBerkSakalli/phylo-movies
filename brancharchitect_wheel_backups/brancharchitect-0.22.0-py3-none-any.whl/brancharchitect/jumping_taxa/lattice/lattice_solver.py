"""
Updated lattice algorithm functions with proper Pydantic validation.
"""

from typing import List, Tuple
from brancharchitect.elements.partition_set import PartitionSet
from brancharchitect.tree import Node
from brancharchitect.jumping_taxa.lattice.lattice_edge import LatticeEdge
from brancharchitect.jumping_taxa.debug import jt_logger
from brancharchitect.jumping_taxa.lattice.lattice_solution import LatticeSolutions

# Import lattice modules
from brancharchitect.jumping_taxa.lattice.lattice_construction import (
    construct_sub_lattices,
    build_partition_conflict_matrix,
    are_cover_lists_equivalent,
)
from brancharchitect.jumping_taxa.lattice.matrix_ops import (
    split_matrix,
    solve_matrix_puzzle,
    generalized_meet_product,
)
from brancharchitect.elements.partition import Partition


def _handle_solutions(
    edge: LatticeEdge,
    solutions: List[PartitionSet[Partition]],
    solutions_manager: LatticeSolutions,
    case_label: str,
) -> bool:
    """
    Helper function to handle solutions with common logging and addition logic.

    Args:
        edge: The lattice edge being processed
        solutions: List of solutions found
        solutions_manager: Manager to store solutions
        case_label: Label for the case (degenerate/non-degenerate)

    Returns:
        False if solutions were found and added, True otherwise
    """
    if solutions:
        jt_logger.info(
            f"Adding solutions for {edge.split} at visit {edge.visits}, Case {case_label}"
        )
        solutions_manager.add_solutions(
            edge.split, solutions, category=case_label, visit=edge.visits
        )
        return False
    return True


def process_single_lattice_edge(
    edge: LatticeEdge,
    solutions_manager: LatticeSolutions,
) -> bool:
    """
    Analyze a single LatticeEdge and store solutions in the solutions_manager.
    """
    if are_cover_lists_equivalent(edge.t1_common_covers, edge.t2_common_covers):
        jt_logger.info(
            f"Skipping {edge.split} at visit {edge.visits} as covers are equivalent."
        )
        return True

    candidate_matrix: List[List[PartitionSet[Partition]]] | None = (
        build_partition_conflict_matrix(edge)
    )
    if not candidate_matrix:
        return True

    matrices: List[List[List[PartitionSet[Partition]]]] = split_matrix(candidate_matrix)
    jt_logger.section("Meet Result Computation")

    if len(matrices) > 1:
        solutions: List[PartitionSet[Partition]] = solve_matrix_puzzle(
            matrix1=matrices[0], matrix2=matrices[1]
        )
        case_label = "degenerate"
    else:
        solutions = generalized_meet_product(matrix=matrices[0])
        case_label = "non-degenerate"
    return _handle_solutions(edge, solutions, solutions_manager, case_label)


def process_iteration(
    sub_lattices: List[LatticeEdge], lattice_solutions: LatticeSolutions
) -> None:
    """
    Process a set of sub-lattices to find solutions.

    Args:
        sub_lattices: List of lattice edges to process
        lattice_solutions: Solution manager to store results
    """
    # Initialize the stack with all edges
    processing_stack: List[LatticeEdge] = sub_lattices.copy()

    while processing_stack:
        # Get the next edge to process
        s_edge: LatticeEdge = processing_stack.pop()
        s_edge.visits += 1

        jt_logger.info(f"s_edge {s_edge.split} updated to visit {s_edge.visits}")

        # Process the edge
        done: bool = process_single_lattice_edge(s_edge, lattice_solutions)

        if not done:
            # Get solutions for this edge and visit
            solutions: List[PartitionSet[Partition]] = (
                lattice_solutions.get_solutions_for_edge_visit(
                    s_edge.split, s_edge.visits
                )
            )
            # If solutions found, remove them from covers
            if solutions:
                s_edge.remove_solutions_from_covers(solutions)

                # Re-add to processing stack
                processing_stack.append(s_edge)
            else:
                jt_logger.info(
                    f"No minimal solutions for {s_edge.split} at visit {s_edge.visits}; skipping re-add."
                )


@jt_logger.log_execution
def lattice_algorithm(
    input_tree1: Node, input_tree2: Node
) -> Tuple[List[Partition], List[Partition]]:
    """
    Execute the lattice algorithm to find jumping taxa between two trees.

    Args:
        input_tree1: First tree
        input_tree2: Second tree

    Returns:
        Tuple of (solutions_list, s_edges_of_solutions)
    """
    try:
        jt_logger.log_newick_strings(input_tree1, input_tree2)
        lattice_solution = LatticeSolutions()
        current_s_edges = construct_sub_lattices(input_tree1, input_tree2)
        jt_logger.section("Initial Sub-Lattices")

        if current_s_edges:
            process_iteration(current_s_edges, lattice_solution)

        solutions_set: List[Partition] = []
        s_edges_of_solutions: List[Partition] = []

        for (s_edge, visit), _ in lattice_solution.solutions_for_s_edge.items():
            minimal_solutions = lattice_solution.get_minimal_by_indices_sum(
                s_edge, visit
            )
            if minimal_solutions:
                solutions_set.extend(minimal_solutions[0])
                s_edges_of_solutions.append(s_edge)

        return solutions_set, s_edges_of_solutions

    except Exception as e:
        from brancharchitect.jumping_taxa.debug import log_stacktrace

        log_stacktrace(e)
        raise Exception(f"Error in lattice_algorithm: {str(e)}")


def iterate_lattice_algorithm(
    input_tree1: Node, input_tree2: Node, leaf_order: tuple[str, ...] = ()
) -> Tuple[List[List[Partition]], List[Partition]]:
    """
    Iteratively apply the lattice algorithm to find all jumping taxa between two trees.
    Returns a list of tuples, each representing indices of jumping taxa.
    """
    solution_set: List[List[Partition]] = []
    s_edges_of_solutions: List[Partition] = []
    t1: Node = input_tree1.deep_copy()
    t2: Node = input_tree2.deep_copy()

    while t1.to_splits() != t2.to_splits():
        solutions, s_edges = lattice_algorithm(t1, t2)
        # Check if no solutions found - break to prevent infinite loop
        if not solutions:
            break
        solution_set.append(solutions)
        s_edges_of_solutions.extend(s_edges)
        for solution in solutions:
            try:
                indices_to_delete: List[int] = list(solution.indices)
                if indices_to_delete:
                    t1.delete_taxa(indices_to_delete=indices_to_delete)
                    t2.delete_taxa(indices_to_delete=indices_to_delete)
            except Exception as e:
                raise Exception(f"Error deleting taxa {solution} from trees: {str(e)}")
        # After deletion, update trees for next iteration
        t1 = t1.deep_copy()
        t2 = t2.deep_copy()

    return solution_set, s_edges_of_solutions


def adapter_iterate_lattice_algorithm(
    input_tree1: Node, input_tree2: Node, leaf_order: tuple[str, ...]
) -> List[Tuple[int, ...]]:
    """
    Adapter function for the lattice algorithm.
    This function is a wrapper around the lattice_algorithm function.
    """
    solutions, _ = iterate_lattice_algorithm(input_tree1, input_tree2, leaf_order)
    translated_solutions: List[Tuple[int, ...]] = []
    for solution_list in solutions:
        for solution in solution_list:
            indices = tuple(solution.indices)
            translated_solutions.append(indices)
    return translated_solutions
