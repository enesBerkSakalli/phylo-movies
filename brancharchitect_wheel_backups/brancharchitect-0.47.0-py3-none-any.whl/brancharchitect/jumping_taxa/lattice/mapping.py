from typing import List, Tuple, Dict, Optional, Set, FrozenSet
import logging

# Assuming these imports point to valid modules in your project structure
from brancharchitect.tree import Node
from brancharchitect.elements.partition_set import PartitionSet
from brancharchitect.elements.partition import Partition

# It's good practice to use the logging module
jt_logger = logging.getLogger(__name__)

# --- Caching Helpers for Performance ---
# These would typically be defined in a utility module.
# Using a simple dictionary for demonstration.
_indices_cache: Dict[int, Tuple[int, ...]] = {}
_set_cache: Dict[Tuple[int, ...], FrozenSet[int]] = {}


def _cached_resolve_to_indices(partition: Partition) -> Tuple[int, ...]:
    """Resolves partition to indices, with caching."""
    # Use partition's hash or another unique identifier if available
    cache_key = hash(partition)
    if cache_key not in _indices_cache:
        _indices_cache[cache_key] = partition.resolve_to_indices()
    return _indices_cache[cache_key]


def _cached_set_from_indices(indices: Tuple[int, ...]) -> FrozenSet[int]:
    """Converts a tuple of indices to a frozenset, with caching."""
    if indices not in _set_cache:
        _set_cache[indices] = frozenset(indices)
    return _set_cache[indices]


# --- Main Mapping Logic ---


def _get_mapping_context(
    s_edge: Partition,
    t1: Node,
    t2: Node,
    t1_splits: PartitionSet,
    t2_splits: PartitionSet,
) -> Optional[Node]:
    """
    Determines which tree (t1 or t2) the s_edge belongs to in the current iteration.
    """
    if s_edge in t1_splits:
        return t1
    elif s_edge in t2_splits:
        return t2
    return None


def _find_original_partition_match(
    s_edge_indices: FrozenSet[int],
    context_leaf_indices: FrozenSet[int],
    common_original_partitions: PartitionSet[Partition],
) -> Optional[Partition]:
    """
    Finds the original common partition that matches the s_edge within the given context.
    """
    for original_p in common_original_partitions:
        original_indices_set = _cached_set_from_indices(
            _cached_resolve_to_indices(original_p)
        )
        # Check if the intersection of the original partition with the current
        # tree's leaves equals the s_edge from the current iteration.
        if s_edge_indices == (original_indices_set & context_leaf_indices):
            return original_p
    return None


def map_s_edges_to_original_by_index(
    s_edges_from_iteration: List[Partition],
    original_t1: Node,
    original_t2: Node,
    current_t1: Node,
    current_t2: Node,
    iteration_count: int,
) -> List[Partition]:
    """
    [CORRECTED] Maps s-edge partitions found in a specific iteration back to their
    corresponding partitions from the set of splits *common* to the original trees.

    This ensures that an s-edge is only mapped back to a valid, common ancestral partition.

    Args:
        s_edges_from_iteration: The list of s-edge Partitions from the lattice algorithm.
        original_t1: The initial, unmodified first tree.
        original_t2: The initial, unmodified second tree.
        current_t1: The first tree in the current iteration (potentially pruned).
        current_t2: The second tree in the current iteration (potentially pruned).
        iteration_count: The current iteration number, for logging.

    Returns:
        A list of original Partitions that correspond to the s-edges found
        in the current iteration.
    """
    mapped_partitions: List[Partition] = []

    # Pre-compute sets once per call for performance.
    t1_splits = current_t1.to_splits(with_leaves=True)
    t2_splits = current_t2.to_splits(with_leaves=True)
    t1_leaf_indices = _cached_set_from_indices(
        _cached_resolve_to_indices(current_t1.split_indices)
    )
    t2_leaf_indices = _cached_set_from_indices(
        _cached_resolve_to_indices(current_t2.split_indices)
    )

    # CORRECTED LOGIC: The search space for original partitions must only be
    # the splits that were common to both original trees.
    common_original_partitions = original_t1.to_splits() & original_t2.to_splits()

    for s_edge in s_edges_from_iteration:
        context_tree = _get_mapping_context(
            s_edge, current_t1, current_t2, t1_splits, t2_splits
        )

        if not context_tree:
            jt_logger.warning(
                f"Iter {iteration_count}: s_edge {s_edge} not in current t1 or t2 splits. Cannot map."
            )
            continue

        # Determine the correct leaf context based on which tree the s_edge was found in.
        context_leaf_indices = (
            t1_leaf_indices if context_tree is current_t1 else t2_leaf_indices
        )
        s_edge_indices_set = _cached_set_from_indices(
            _cached_resolve_to_indices(s_edge)
        )

        # Find the matching original partition within the set of common splits.
        original_match = _find_original_partition_match(
            s_edge_indices_set, context_leaf_indices, common_original_partitions
        )

        if original_match and original_match not in mapped_partitions:
            mapped_partitions.append(original_match)

    return mapped_partitions
