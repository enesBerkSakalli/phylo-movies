from brancharchitect.elements.partition_set import PartitionSet
from brancharchitect.elements.partition import Partition

PMatrix = list[list[PartitionSet[Partition]]]
