from brancharchitect.tree import Node
from brancharchitect.partition_set import Partition, PartitionSet
from collections import Counter
from typing import List


class ComponentTranslator:
    def __init__(self, tree):
        self.tree = tree
        self.r_cache = {}

    def to_idx(self, c):
        idx = self.tree._index(c)
        self.r_cache[idx] = c
        return idx

    def to_str(self, c):
        return self.r_cache[c]


def component_distance(
    tree1: Node, tree2: Node, components: List[tuple[str, ...]], weighted: bool = False
) -> List[float]:
    translator = ComponentTranslator(tree1)
    # Convert tuple[str, ...] to Partition (which is likely tuple[int, ...])
    components_idx: List[Partition] = [translator.to_idx(c) for c in components]
    distances: List[float] = []

    for component in components_idx:
        d1 = jump_distance(tree1, tree2.to_splits(), component, weighted=weighted)
        d2 = jump_distance(tree2, tree1.to_splits(), component, weighted=weighted)
        distances.append(d1 + d2)
    return distances


def jump_distance(
    node: Node, reference: PartitionSet, component: Partition, weighted: bool = False
) -> float:
    path: List[Node] = jump_path(node, reference, component)
    if weighted:
        return sum(n.length for n in path if n.length is not None)
    else:
        return float(len(path))


def jump_path(node: Node, reference: PartitionSet, component: Partition) -> List[Node]:
    path: List[Node] = []
    while set(node.split_indices) != set(component):
        if node.split_indices in reference:
            path = []
        else:
            path.append(node)
        for child in node.children:
            if set(component) <= set(child.split_indices):
                node = child
                break
        else:
            break
            # Component is actually not a component
    return path


def jump_path_distance(
    tree1: Node, tree2: Node, components: List[tuple[str, ...]], weighted: bool = False
) -> List[float]:
    translator = ComponentTranslator(tree1)
    components_idx: List[Partition] = [translator.to_idx(c) for c in components]

    paths1 = [
        jump_path(tree1, tree2.to_splits(), component) for component in components_idx
    ]
    paths2 = [
        jump_path(tree2, tree1.to_splits(), component) for component in components_idx
    ]

    counter = Counter(node.split_indices for path in paths1 + paths2 for node in path)

    distances: List[float] = []
    for p1, p2 in zip(paths1, paths2):
        if weighted:
            d = sum(
                (n.length if n.length is not None else 0.0) / counter[n.split_indices]
                for n in p1 + p2
            )
        else:
            d = sum(1.0 / counter[n.split_indices] for n in p1 + p2)
        distances.append(d)
    return distances