from typing import Dict, Set, List
from brancharchitect.elements.partition import Partition
from brancharchitect.tree import Node


__all__ = [
    "interpolate_tree",
    "interpolate_adjacent_tree_pairs",
    "interpolate_tree_with_progressive_s_edge_block_ordering",
]

### public API ###


def interpolate_tree(tree_one: Node, tree_two: Node) -> tuple[Node, Node, Node, Node]:
    split_dict1: Dict[Partition, float] = tree_one.to_weighted_splits()
    split_dict2: Dict[Partition, float] = tree_two.to_weighted_splits()

    it1: Node = calculate_intermediate_tree(tree_one, split_dict2)
    it2: Node = calculate_intermediate_tree(tree_two, split_dict1)

    c1: Node = calculate_consensus_tree(it1, split_dict2)
    c2: Node = calculate_consensus_tree(it2, split_dict1)

    return (it1, c1, c2, it2)


def interpolate_adjacent_tree_pairs(tree_list: list[Node]) -> list[Node]:
    results: list[Node] = []
    for i in range(len(tree_list) - 1):
        tree_one: Node = tree_list[i]
        tree_two: Node = tree_list[i + 1]

        # Interpolate trees and get intermediate and consensus trees
        trees: tuple[Node, Node, Node, Node] = interpolate_tree(tree_one, tree_two)

        results.append(tree_one)
        results.extend(trees)

    results.append(tree_list[-1])
    return results


### Private API ###
def calculate_intermediate_tree(tree: Node, split_dict: Dict[Partition, float]) -> Node:
    it = tree.deep_copy()
    _calculate_intermediate_tree(it, split_dict)
    return it


def _calculate_intermediate_tree(node: Node, split_dict: Dict[Partition, float]):
    if node.split_indices not in split_dict:
        node.length = 0
    else:
        node_length = node.length if node.length is not None else 0.0
        node.length = (split_dict[node.split_indices] + node_length) / 2
    for child in node.children:
        _calculate_intermediate_tree(child, split_dict)


def calculate_consensus_tree(tree: Node, split_dict: Dict[Partition, float]) -> Node:
    consensus_tree: Node = tree.deep_copy()
    return _calculate_consensus_tree(consensus_tree, split_dict)


def _calculate_consensus_tree(node: Node, split_dict: Dict[Partition, float]) -> Node:
    # If the node is a leaf, return it unchanged.
    if not node.children:
        return node

    new_children: list[Node] = []
    for child in node.children:
        # Recursively process the child
        processed_child: Node = _calculate_consensus_tree(child, split_dict)
        # If the processed child is internal (has children)
        if processed_child.children:
            # If its split is in the consensus splits, keep the whole node.
            if processed_child.split_indices in split_dict:
                new_children.append(processed_child)
            else:
                # Otherwise, collapse it by promoting its children.
                for grandchild in processed_child.children:
                    new_children.append(grandchild)
        else:
            # Leaf nodes are always kept.
            new_children.append(processed_child)
    node.children = new_children
    return node


def interpolate_tree_with_progressive_s_edge_block_ordering(
    tree_one: Node, tree_two: Node
) -> List[Node]:
    """
    Create fine-grained interpolation with progressive ordering of consensus subtrees
    based on individual s_edge_blocks (Partitions).

    Each step in the generated sequence cumulatively adds ordering based on a
    specific s_edge_block. S_edge_blocks are processed in order from largest
    (most taxa) to smallest. Ordering is triggered for a subtree if its parent
    node's s_edge_block is among the s_edge_blocks active for the current step.
    Children are sorted by the length of their own s_edge_block.indices.

    Args:
        tree_one: First input tree. Nodes are expected to have s_edge_block populated.
        tree_two: Second input tree. Nodes are expected to have s_edge_block populated.

    Returns:
        A list of trees showing a smooth progression:
        [tree_one, it1, c1_0, c2_0, c1_1, c2_1, ..., c1_n, c2_n, it2, tree_two]
    """
    split_dict1: Dict[Partition, float] = tree_one.to_weighted_splits()
    split_dict2: Dict[Partition, float] = tree_two.to_weighted_splits()

    it1: Node = calculate_intermediate_tree(tree_one, split_dict2)
    it2: Node = calculate_intermediate_tree(tree_two, split_dict1)

    # Collect all unique s_edge_block Partition objects from the intermediate trees.
    all_s_edge_blocks_set: Set[Partition] = set()
    _collect_s_edge_blocks_recursive(it1, all_s_edge_blocks_set)
    _collect_s_edge_blocks_recursive(it2, all_s_edge_blocks_set)

    # Sort unique s_edge_blocks: primary key is len(indices) descending.
    # Filter out None or Partitions without indices if they somehow appear.
    sorted_unique_s_edge_blocks = sorted(
        [
            p
            for p in all_s_edge_blocks_set
            if p and p.indices is not None and len(p.indices) > 0
        ],
        key=lambda p: len(p.indices),
        reverse=True,
    )

    interpolated_trees_sequence: List[Node] = []

    interpolated_trees_sequence.append(tree_one.deep_copy())
    interpolated_trees_sequence.append(it1)  # it1 is already a deep copy

    # Iterate N+1 times, where N is the number of unique, valid s_edge_blocks.
    # The first iteration (i=0) uses an empty set for the criterion (no s_edge_block based ordering).
    for i in range(len(sorted_unique_s_edge_blocks) + 1):
        # The criterion is the set of s_edge_blocks to consider for ordering in this step.
        current_s_edge_block_criterion = set(sorted_unique_s_edge_blocks[:i])

        c1_incremental_base = it1.deep_copy()
        c1_incremental = (
            _calculate_consensus_tree_with_progressive_s_edge_block_ordering(
                c1_incremental_base, split_dict2, current_s_edge_block_criterion
            )
        )
        interpolated_trees_sequence.append(c1_incremental)

        c2_incremental_base = it2.deep_copy()
        c2_incremental = (
            _calculate_consensus_tree_with_progressive_s_edge_block_ordering(
                c2_incremental_base, split_dict1, current_s_edge_block_criterion
            )
        )
        interpolated_trees_sequence.append(c2_incremental)

    interpolated_trees_sequence.append(it2)  # it2 is already a deep copy
    interpolated_trees_sequence.append(tree_two.deep_copy())

    return interpolated_trees_sequence


def _calculate_consensus_tree_with_progressive_s_edge_block_ordering(
    node: Node,
    consensus_split_dict: Dict[Partition, float],
    s_edge_blocks_for_ordering_criterion: Set[Partition],
) -> Node:
    """
    Recursively calculates a consensus tree and applies progressive ordering to children
    based on whether the node's s_edge_block is in the current criterion set.

    Consensus logic: Nodes are kept if their split_indices are in consensus_split_dict.
    Ordering logic: If an internal node is kept and its s_edge_block (Partition object)
                    is in s_edge_blocks_for_ordering_criterion, its children
                    are sorted by the length of their own s_edge_block.indices (descending).
    """
    if not node.children:
        return node

    new_children: list[Node] = []
    for child in node.children:
        processed_child: Node = (
            _calculate_consensus_tree_with_progressive_s_edge_block_ordering(
                child,
                consensus_split_dict,
                s_edge_blocks_for_ordering_criterion,
            )
        )
        if processed_child.children:
            if processed_child.split_indices in consensus_split_dict:
                new_children.append(processed_child)
            else:
                new_children.extend(
                    grandchild for grandchild in processed_child.children
                )
        else:
            new_children.append(processed_child)

    # Ordering logic for the current node's children:
    if node.split_indices in consensus_split_dict:  # Node is part of consensus
        # Check if this node's s_edge_block itself triggers ordering
        node_s_edge_block = getattr(node, "s_edge_block", None)

        if (
            node_s_edge_block is not None
            and node_s_edge_block in s_edge_blocks_for_ordering_criterion
            and new_children
        ):
            new_children.sort(
                key=lambda n: len(n.s_edge_block.indices)
                if hasattr(n, "s_edge_block")
                and n.s_edge_block
                and n.s_edge_block.indices is not None
                else -1,  # Place nodes with no/empty/invalid s_edge_block last
                reverse=True,
            )

    node.children = new_children
    return node


def _collect_s_edge_blocks_recursive(node: Node, s_blocks_set: Set[Partition]):
    """Helper to recursively collect s_edge_block Partition objects."""
    if (
        hasattr(node, "s_edge_block")
        and isinstance(node.s_edge_block, Partition)  # Ensure it's a Partition
        and node.s_edge_block.indices is not None  # Ensure it has indices
    ):
        s_blocks_set.add(node.s_edge_block)
    for child in node.children:
        _collect_s_edge_blocks_recursive(child, s_blocks_set)
