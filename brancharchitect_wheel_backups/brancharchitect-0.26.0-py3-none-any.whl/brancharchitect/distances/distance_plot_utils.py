# Cell 1: Imports and Initial Setup
import umap
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.axes import Axes
import seaborn as sns
import plotly.graph_objs as go
from sklearn.cluster import SpectralClustering
from numpy.typing import NDArray
from typing import List, Optional, Union, Tuple, Literal


def plot_consecutive_distances(
    df: pd.DataFrame, distance_metric: str, ax: Axes, title: Optional[str] = None
) -> None:
    """
    Plot distances between consecutive trees as a line plot.
    """
    df_consecutive: pd.DataFrame = df[df["Tree2"] == df["Tree1"] + 1]
    df_consecutive = df_consecutive.sort_values(by="Tree1")  # type: ignore[assignment]

    ax.plot(
        df_consecutive["Tree1"].to_numpy(),
        df_consecutive[distance_metric].to_numpy(dtype=float),
        marker="o",
        linestyle="-",
    )
    if not title:
        title = f"Consecutive Distances ({distance_metric})"
    ax.set_title(title)
    ax.set_xlabel("Tree Index")
    ax.set_ylabel(f"{distance_metric} Distance")
    ax.grid(True)


def plot_distance_matrix(
    distance_matrix: Union[NDArray[np.float64], pd.DataFrame],
    ax: Axes,
    title: str = "Distance Matrix",
) -> None:
    """
    Plot the distance matrix as a heatmap.
    """
    sns.heatmap(np.asarray(distance_matrix), cmap="viridis", ax=ax)
    ax.set_title(title)
    ax.set_xlabel("Tree Index")
    ax.set_ylabel("Tree Index")


def perform_clustering(
    distance_matrix: NDArray[np.float64], n_clusters: int = 3
) -> NDArray[np.int64]:
    """
    Perform spectral clustering on the distance matrix.
    Handles NaN values by imputation or removal.
    """
    # Check for NaN values and handle them
    if np.isnan(distance_matrix).any():
        print(
            f"Warning: Found {np.sum(np.isnan(distance_matrix))} NaN values in distance matrix. Applying imputation..."
        )

        # Strategy 1: Replace NaN with median of non-NaN values
        # This preserves the matrix dimensions while providing reasonable estimates
        distance_matrix = np.copy(distance_matrix)  # Don't modify original

        # Calculate median of non-NaN values
        non_nan_values: NDArray[np.float64] = distance_matrix[
            ~np.isnan(distance_matrix)
        ]
        if len(non_nan_values) == 0:
            raise ValueError("All values in distance matrix are NaN")

        median_distance: np.float64 = np.median(non_nan_values)

        # Replace NaN values with median
        distance_matrix[np.isnan(distance_matrix)] = median_distance

        print(f"Replaced NaN values with median distance: {median_distance:.4f}")

    # Ensure matrix is symmetric (required for spectral clustering)
    distance_matrix = (distance_matrix + distance_matrix.T) / 2

    clustering: SpectralClustering = SpectralClustering(
        n_clusters=n_clusters,
        affinity="precomputed",
        assign_labels="kmeans",
        random_state=42,
    )

    # For precomputed affinity, we need to convert the distance matrix to a similarity matrix
    # Add small epsilon to avoid division by zero
    std_dev: np.float64 = np.std(distance_matrix)
    if std_dev == 0:
        print(
            "Warning: Distance matrix has zero standard deviation. Using uniform similarity."
        )
        similarity_matrix: NDArray[np.float64] = np.ones_like(distance_matrix)
    else:
        similarity_matrix = np.exp(-distance_matrix / std_dev)

    cluster_labels: np.ndarray = clustering.fit_predict(similarity_matrix)
    return cluster_labels


def perform_umap(
    distance_matrix: NDArray[np.float64],
    n_components: int = 3,
    n_neighbors: int = 15,
    min_dist: float = 0.1,
) -> NDArray[np.float64]:
    """
    Perform UMAP dimensionality reduction on the distance matrix.
    Handles NaN values by imputation.
    """
    # Check for NaN values and handle them
    if np.isnan(distance_matrix).any():
        print(
            f"Warning: Found {np.sum(np.isnan(distance_matrix))} NaN values in distance matrix for UMAP. Applying imputation..."
        )

        # Create a copy to avoid modifying the original matrix
        distance_matrix = np.copy(distance_matrix)

        # Calculate median of non-NaN values
        non_nan_values: NDArray[np.float64] = distance_matrix[
            ~np.isnan(distance_matrix)
        ]
        if len(non_nan_values) == 0:
            raise ValueError("All values in distance matrix are NaN")

        median_distance: np.float64 = np.median(non_nan_values)

        # Replace NaN values with median
        distance_matrix[np.isnan(distance_matrix)] = median_distance
        print(f"Replaced NaN values with median distance: {median_distance:.4f}")

    # Ensure matrix is symmetric
    distance_matrix = (distance_matrix + distance_matrix.T) / 2

    umap_model = umap.UMAP(
        n_components=n_components,
        n_neighbors=n_neighbors,
        min_dist=min_dist,
        metric="precomputed",
        random_state=42,
        spread=1.0,
    )
    embedding: NDArray[np.float64] = umap_model.fit_transform(distance_matrix)
    return embedding


def create_3d_scatter_plot(
    embedding: NDArray[np.float64],
    tree_indices: List[int],
    labels: NDArray[np.int64],
    title: str,
    method_name: str,
) -> None:
    """
    Create a 3D scatter plot for the embedding.
    """
    # Use Plotly for interactive 3D plotting
    fig: go.Figure = go.Figure(
        data=[
            go.Scatter3d(
                x=embedding[:, 0],
                y=embedding[:, 1],
                z=embedding[:, 2],
                mode="markers",
                marker=dict(
                    size=5,
                    color=labels,
                    colorscale="Viridis",
                    opacity=0.8,
                    colorbar=dict(title="Cluster"),
                ),
                text=[f"Tree Index: {idx}" for idx in tree_indices],
                hoverinfo="text",
            )
        ]
    )

    fig.update_layout(
        title=title,
        scene=dict(
            xaxis_title=f"{method_name} Dimension 1",
            yaxis_title=f"{method_name} Dimension 2",
            zaxis_title=f"{method_name} Dimension 3",
        ),
        width=800,
        height=600,
    )

    fig.show()


def plot_component_distance_matrix(
    distance_matrix: Union[NDArray[np.float64], pd.DataFrame],
    title: str = "Component Distance Matrix",
) -> None:
    """
    Plot the component distance matrix as a heatmap.
    """
    plt.figure(figsize=(8, 6))
    sns.heatmap(distance_matrix, cmap="viridis")
    plt.title(title)
    plt.xlabel("Tree Index")
    plt.ylabel("Tree Index")
    plt.show()


def plot_component_consecutive_distances(
    df_distances: pd.DataFrame, ax: Optional[Axes] = None, title: Optional[str] = None
) -> None:
    """
    Plot distances between consecutive trees as a line plot.
    """
    created_axes: bool = False
    if ax is None:
        _, ax = plt.subplots(figsize=(8, 4))
        created_axes = True
    df_consecutive: pd.DataFrame = df_distances[
        df_distances["Tree2"] == df_distances["Tree1"] + 1
    ]
    df_consecutive = df_consecutive.sort_values(by="Tree1")
    ax.plot(
        df_consecutive["Tree1"],
        df_consecutive["ComponentDistance"],
        marker="o",
        linestyle="-",
    )
    if not title:
        title = "Consecutive Component Distances"
    ax.set_title(title)
    ax.set_xlabel("Tree Index")
    ax.set_ylabel("Component Distance")
    ax.grid(True)
    if created_axes:
        plt.show()


def plot_component_umap_3d(
    embedding: NDArray[np.float64],
    cluster_labels: NDArray[np.int64],
    title: str = "UMAP Embedding (Component Distance)",
) -> None:
    """
    Create a 3D scatter plot for the UMAP embedding of component distances.
    """
    fig: go.Figure = go.Figure(
        data=[
            go.Scatter3d(
                x=embedding[:, 0],
                y=embedding[:, 1],
                z=embedding[:, 2],
                mode="markers",
                marker=dict(
                    size=5,
                    color=cluster_labels,
                    colorscale="Viridis",
                    opacity=0.8,
                    colorbar=dict(title="Cluster"),
                ),
                text=[f"Tree {i + 1}" for i in range(embedding.shape[0])],
                hoverinfo="text",
            )
        ]
    )
    fig.update_layout(
        title=title,
        scene=dict(
            xaxis_title="UMAP Dimension 1",
            yaxis_title="UMAP Dimension 2",
            zaxis_title="UMAP Dimension 3",
        ),
        width=800,
        height=600,
    )
    fig.show()


def perform_clustering_robust(
    distance_matrix: NDArray[np.float64],
    n_clusters: int = 3,
    nan_strategy: Literal["median", "mean", "remove", "knn_impute"] = "median",
    min_valid_ratio: float = 0.5,
) -> Tuple[NDArray[np.int64], NDArray[np.int64]]:
    """
    Enhanced clustering with robust NaN handling strategies.

    Parameters:
    -----------
    distance_matrix : NDArray[np.floating]
        Input distance matrix
    n_clusters : int
        Number of clusters
    nan_strategy : Literal["median", "mean", "remove", "knn_impute"]
        Strategy for handling NaN values:
        - "median": Replace with median distance
        - "mean": Replace with mean distance
        - "remove": Remove rows/columns with NaN values
        - "knn_impute": Use KNN imputation
    min_valid_ratio : float
        Minimum ratio of non-NaN values required per row/column

    Returns:
    --------
    cluster_labels : NDArray[np.integer]
        Cluster assignments
    valid_indices : NDArray[np.integer]
        Indices of trees included in clustering (useful when rows are removed)
    """
    from sklearn.impute import KNNImputer

    print(f"Original matrix shape: {distance_matrix.shape}")
    print(f"NaN count: {np.sum(np.isnan(distance_matrix))}")

    original_indices: NDArray[np.int64] = np.arange(distance_matrix.shape[0])

    if not np.isnan(distance_matrix).any():
        print("No NaN values found - proceeding with standard clustering")
        return perform_clustering(distance_matrix, n_clusters), original_indices

    if nan_strategy == "remove":
        # Remove rows/columns with too many NaN values
        nan_counts_per_row: NDArray[np.int64] = np.sum(
            np.isnan(distance_matrix), axis=1
        )
        valid_ratio_per_row: NDArray[np.float64] = 1 - (
            nan_counts_per_row / distance_matrix.shape[1]
        )
        valid_rows: NDArray[np.bool_] = valid_ratio_per_row >= min_valid_ratio

        if np.sum(valid_rows) < n_clusters:
            print(
                f"Warning: Only {np.sum(valid_rows)} valid rows remain, but {n_clusters} clusters requested."
            )
            print("Falling back to median imputation strategy.")
            nan_strategy = "median"
        else:
            distance_matrix = distance_matrix[valid_rows][:, valid_rows]
            original_indices = original_indices[valid_rows]
            print(
                f"Removed {np.sum(~valid_rows)} rows/columns. New shape: {distance_matrix.shape}"
            )

    if nan_strategy in ["median", "mean", "knn_impute"]:
        distance_matrix = np.copy(distance_matrix)

        if nan_strategy == "median":
            non_nan_values: NDArray[np.float64] = distance_matrix[
                ~np.isnan(distance_matrix)
            ]
            if len(non_nan_values) == 0:
                raise ValueError("All values in distance matrix are NaN")
            fill_value: np.float64 = np.median(non_nan_values)
            distance_matrix[np.isnan(distance_matrix)] = fill_value
            print(f"Replaced NaN with median: {fill_value:.4f}")

        elif nan_strategy == "mean":
            non_nan_values = distance_matrix[~np.isnan(distance_matrix)]
            if len(non_nan_values) == 0:
                raise ValueError("All values in distance matrix are NaN")
            fill_value = np.mean(non_nan_values)
            distance_matrix[np.isnan(distance_matrix)] = fill_value
            print(f"Replaced NaN with mean: {fill_value:.4f}")

        elif nan_strategy == "knn_impute":
            imputer: KNNImputer = KNNImputer(
                n_neighbors=min(5, distance_matrix.shape[0] - 1)
            )
            imputed_matrix: np.ndarray = imputer.fit_transform(
                np.asarray(distance_matrix, dtype=np.float64)
            )
            distance_matrix = imputed_matrix
            print("Applied KNN imputation for NaN values")

    # Ensure matrix is symmetric and run clustering
    distance_matrix = (distance_matrix + distance_matrix.T) / 2
    cluster_labels: NDArray[np.int64] = perform_clustering(distance_matrix, n_clusters)

    return cluster_labels, original_indices
